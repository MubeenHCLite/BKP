/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : contmonsectionoverview.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : The CDP OPSW Continous Monitoring Page implementation. This implementation
 *                provides Navigation to all LRU Status Pages (Control Panels, PDUs,
 *                Access Zones).It also provides navigation options to Maintenance window.
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "contmonsectionoverview.h"
#include "ui_contmonsectionoverview.h"
#include "iconmap.h"
#include <QPalette>
#include <QDebug>

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the continos monitoring window of application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
ContMonSectionOverview::ContMonSectionOverview(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ContMonSectionOverview)
{
    ui->setupUi(this);

    QPixmap Background(BaseFolder + "ContMonitringPageBkg.png");
    Background = Background.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette Palette;
    Palette.setBrush(QPalette::Window, Background);
    this->setPalette(Palette);
    qDebug() << "SWMaint Page";


    BackButton = new QPushButton("", this);
    BackButton->setGeometry(QRect(QPoint(CON_BK_BTN_X, CON_BK_BTN_Y), QSize(CON_BK_BTN_WT, CON_BK_BTN_HT)));
    QPixmap BackButtonBkg(BaseFolder +  "BackButton.png");
    QIcon BackButtonIcon(BackButtonBkg.scaled(CON_BK_BTN_WT, CON_BK_BTN_HT,Qt::KeepAspectRatio));
    BackButton->setIcon(BackButtonIcon);
    BackButton->setIconSize(BackButtonBkg.rect().size());
    connect(BackButton, &QPushButton::released, this, &ContMonSectionOverview::HandleBackButton);

    // SW Maintenance button
    Zone1Button = new QPushButton("", this);
    Zone1Button->setGeometry(QRect(QPoint(ZN1_BTN_X, ZN1_BTN_Y), QSize(ZN1_BTN_WT, ZN1_BTN_HT)));
    QPixmap Zone1ButtonBkg(BaseFolder + "SecButton1.png");
    QIcon Zone1ButtonIcon(Zone1ButtonBkg);
    Zone1Button->setIcon(Zone1ButtonIcon);
    Zone1Button->setIconSize(Zone1ButtonBkg.rect().size());
    connect(Zone1Button, &QPushButton::released, this, &ContMonSectionOverview::HandleZone1MonButton);


    Zone3Button = new QPushButton("", this);
    Zone3Button->setGeometry(QRect(QPoint(ZN3_BTN_X, ZN3_BTN_Y), QSize(ZN3_BTN_WT, ZN3_BTN_HT)));
    QPixmap Zone3ButtonBkg(BaseFolder + "SecButton3.png");
    QIcon Zone3ButtonIcon(Zone3ButtonBkg);
    Zone3Button->setIcon(Zone3ButtonIcon);
    Zone3Button->setIconSize(Zone3ButtonBkg.rect().size());
    connect(Zone3Button, &QPushButton::released, this, &ContMonSectionOverview::HandleZone3MonButton);

    Zone5Button = new QPushButton("", this);
    Zone5Button->setGeometry(QRect(QPoint(ZN5_BTN_X, ZN5_BTN_Y), QSize(ZN5_BTN_WT, ZN5_BTN_HT)));
    QPixmap Zone5ButtonBkg(BaseFolder + "SecButton5.png");
    QIcon Zone5ButtonIcon(Zone5ButtonBkg);
    Zone5Button->setIcon(Zone5ButtonIcon);
    Zone5Button->setIconSize(Zone5ButtonBkg.rect().size());
    connect(Zone5Button, &QPushButton::released, this, &ContMonSectionOverview::HandleZone5MonButton);

    Zone2Button = new QPushButton("", this);
    Zone2Button->setGeometry(QRect(QPoint(ZN2_BTN_X, ZN2_BTN_Y), QSize(ZN2_BTN_WT, ZN2_BTN_HT)));
    QPixmap Zone2ButtonBkg(BaseFolder + "SecButton2.png");
    QIcon Zone2ButtonIcon(Zone2ButtonBkg);
    Zone2Button->setIcon(Zone2ButtonIcon);
    Zone2Button->setIconSize(Zone2ButtonBkg.rect().size());
    connect(Zone2Button, &QPushButton::released, this, &ContMonSectionOverview::HandleZone2MonButton);

    Zone4Button = new QPushButton("", this);
    Zone4Button->setGeometry(QRect(QPoint(ZN4_BTN_X, ZN4_BTN_Y), QSize(ZN4_BTN_WT, ZN4_BTN_HT)));
    QPixmap Zone4ButtonBkg(BaseFolder + "SecButton4.png");
    QIcon Zone4ButtonIcon(Zone4ButtonBkg);
    Zone4Button->setIcon(Zone4ButtonIcon);
    Zone4Button->setIconSize(Zone4ButtonBkg.rect().size());
    connect(Zone4Button, &QPushButton::released, this, &ContMonSectionOverview::HandleZone4MonButton);

    Zone6Button = new QPushButton("", this);
    Zone6Button->setGeometry(QRect(QPoint(ZN6_BTN_X, ZN6_BTN_Y), QSize(ZN6_BTN_WT, ZN6_BTN_HT)));
    QPixmap Zone6ButtonBkg(BaseFolder + "SecButton6.png");
    QIcon Zone6ButtonIcon(Zone6ButtonBkg);
    Zone6Button->setIcon(Zone6ButtonIcon);
    Zone6Button->setIconSize(Zone6ButtonBkg.rect().size());
    connect(Zone6Button, &QPushButton::released, this, &ContMonSectionOverview::HandleZone6MonButton);

	  qDebug() << "SWMaint Page Mid";
    //Section1 = new Section1Page(this);
    ui->stackedWidget->addWidget(&Section1);
    ui->stackedWidget->addWidget(&Section2);
    ui->stackedWidget->addWidget(&Section3);
    ui->stackedWidget->addWidget(&Section4);
    ui->stackedWidget->addWidget(&Section5);
    ui->stackedWidget->addWidget(&Section6);
    qDebug() << "SWMaint Page End";
}

/*-----------------------------------------------------------------------------
 *  Description : This is the Reset functionality of all section button Icons
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void ContMonSectionOverview::ResetButtonsIcons() {
    QPixmap Zone1ButtonBkg(BaseFolder + "SecButton1.png");
    QIcon Zone1ButtonIcon(Zone1ButtonBkg);
    Zone1Button->setIcon(Zone1ButtonIcon);
    Zone1Button->setIconSize(Zone1ButtonBkg.rect().size());

    QPixmap Zone3ButtonBkg(BaseFolder + "SecButton3.png");
    QIcon Zone3ButtonIcon(Zone3ButtonBkg);
    Zone3Button->setIcon(Zone3ButtonIcon);
    Zone3Button->setIconSize(Zone3ButtonBkg.rect().size());

    QPixmap Zone5ButtonBkg(BaseFolder + "SecButton5.png");
    QIcon Zone5ButtonIcon(Zone5ButtonBkg);
    Zone5Button->setIcon(Zone5ButtonIcon);
    Zone5Button->setIconSize(Zone5ButtonBkg.rect().size());

    QPixmap Zone2ButtonBkg(BaseFolder + "SecButton2.png");
    QIcon Zone2ButtonIcon(Zone2ButtonBkg);
    Zone2Button->setIcon(Zone2ButtonIcon);
    Zone2Button->setIconSize(Zone2ButtonBkg.rect().size());

    QPixmap Zone4ButtonBkg(BaseFolder + "SecButton4.png");
    QIcon Zone4ButtonIcon(Zone4ButtonBkg);
    Zone4Button->setIcon(Zone4ButtonIcon);
    Zone4Button->setIconSize(Zone4ButtonBkg.rect().size());

    QPixmap Zone6ButtonBkg(BaseFolder + "SecButton6.png");
    QIcon Zone6ButtonIcon(Zone6ButtonBkg);
    Zone6Button->setIcon(Zone6ButtonIcon);
    Zone6Button->setIconSize(Zone6ButtonBkg.rect().size());

}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to the Section 1 Page
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void ContMonSectionOverview::HandleZone1MonButton(){

    ResetButtonsIcons();

    QPixmap Zone1ButtonBkg(BaseFolder + "SecButton1G.png");
    QIcon Zone1ButtonIcon(Zone1ButtonBkg);
    Zone1Button->setIcon(Zone1ButtonIcon);
    Zone1Button->setIconSize(Zone1ButtonBkg.rect().size());

    ui->stackedWidget->setCurrentIndex(INDEX2);
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to the Section 2 Page
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void ContMonSectionOverview::HandleZone2MonButton(){

    ResetButtonsIcons();

    QPixmap Zone2ButtonBkg(BaseFolder + "SecButton2G.png");
    QIcon Zone2ButtonIcon(Zone2ButtonBkg);
    Zone2Button->setIcon(Zone2ButtonIcon);
    Zone2Button->setIconSize(Zone2ButtonBkg.rect().size());
    ui->stackedWidget->setCurrentIndex(INDEX3);
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to the Section 3 Page
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void ContMonSectionOverview::HandleZone3MonButton(){

    ResetButtonsIcons();

    QPixmap Zone3ButtonBkg(BaseFolder + "SecButton3G.png");
    QIcon Zone3ButtonIcon(Zone3ButtonBkg);
    Zone3Button->setIcon(Zone3ButtonIcon);
    Zone3Button->setIconSize(Zone3ButtonBkg.rect().size());

    ui->stackedWidget->setCurrentIndex(INDEX4);
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to the Section 4 Page
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void ContMonSectionOverview::HandleZone4MonButton(){

    ResetButtonsIcons();

    QPixmap Zone4ButtonBkg(BaseFolder + "SecButton4G.png");
    QIcon Zone4ButtonIcon(Zone4ButtonBkg);
    Zone4Button->setIcon(Zone4ButtonIcon);
    Zone4Button->setIconSize(Zone4ButtonBkg.rect().size());

    ui->stackedWidget->setCurrentIndex(INDEX5);
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to the Section 5 Page
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void ContMonSectionOverview::HandleZone5MonButton(){

    ResetButtonsIcons();

    QPixmap Zone5ButtonBkg(BaseFolder + "SecButton5G.png");
    QIcon Zone5ButtonIcon(Zone5ButtonBkg);
    Zone5Button->setIcon(Zone5ButtonIcon);
    Zone5Button->setIconSize(Zone5ButtonBkg.rect().size());

    ui->stackedWidget->setCurrentIndex(INDEX6);
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to the Section 6 Page
 *QPoint(1120, 240), QSize(320, 165)
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void ContMonSectionOverview::HandleZone6MonButton(){

    ResetButtonsIcons();

    QPixmap Zone6ButtonBkg(BaseFolder + "SecButton6G.png");
    QIcon Zone6ButtonIcon(Zone6ButtonBkg);
    Zone6Button->setIcon(Zone6ButtonIcon);
    Zone6Button->setIconSize(Zone6ButtonBkg.rect().size());

    ui->stackedWidget->setCurrentIndex(INDEX7);
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to SW Maintenance screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void ContMonSectionOverview::HandleBackButton(){
    PrevPage = CON_MON;
    CurrPage = MAINT;
    ui->stackedWidget->setCurrentIndex(INDEX1);
    hide();
}

ContMonSectionOverview::~ContMonSectionOverview()
{
    delete ui;
}


