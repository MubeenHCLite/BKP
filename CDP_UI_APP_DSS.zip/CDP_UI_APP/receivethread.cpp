#include <QList>
#include "common.h"


QList<CAN_DATA>		canData;

void receiveThread(){

}
