
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : ocptstatuspage.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef OCPSTATUSPAGE_H
#define OCPSTATUSPAGE_H

#include <QDialog>
#include <QTimer>
#include <QPushButton>
#include <QDebug>

/********************* PREPROCESSOR DIRECTIVES  *****************************/

#define OCP_BK_BTN_WT       80
#define OCP_BK_BTN_HT       80
#define OCP_BK_BTN_X        60
#define OCP_BK_BTN_Y        40

namespace Ui {
class OCPStatusPage;
}

class OCPStatusPage : public QDialog
{
    Q_OBJECT

public:
    explicit OCPStatusPage(QWidget *parent = 0);
    ~OCPStatusPage();

private slots:
    void UpdateUI();
    void HandleBackButton();

private:
    Ui::OCPStatusPage *ui;
    QTimer *timer;
    QPushButton             *BackButton;
};

#endif // OCPSTATUSPAGE_H
