

/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : iconmap.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef ICONMAP_H
#define ICONMAP_H

#define     MCP_GREEN_PIX   QPixmap(MCPGreenP).scaled(MCPWt,MCPHt, Qt::KeepAspectRatio)
#define     MCP_GREY_PIX   QPixmap(MCPGreyP).scaled(MCPWt,MCPHt, Qt::KeepAspectRatio)
#define     MCP_AMBER_PIX   QPixmap(MCPAmberP).scaled(MCPWt,MCPHt, Qt::KeepAspectRatio)
#define     MCP_RDAM_PIX   QPixmap(MCPRdAmP).scaled(MCPWt,MCPHt, Qt::KeepAspectRatio)
#define     MCP_RDGN_PIX   QPixmap(MCPRdGnP).scaled(MCPWt,MCPHt, Qt::KeepAspectRatio)

#define     ICP_GREEN_PIX   QPixmap(ICPGreenP).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)
#define     ICP_GREY_PIX   QPixmap(ICPGreyP).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)
#define     ICP_AMBER_PIX   QPixmap(ICPAmberP).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)
#define     ICP_RDAM_PIX   QPixmap(ICPRdAmP).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)
#define     ICP_RDGN_PIX   QPixmap(ICPRdGnP).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)

#define     OCP_GREEN_PIX   QPixmap(OCPGreenP).scaled(OCPWt,OCPHt, Qt::KeepAspectRatio)
#define     OCP_GREY_PIX   QPixmap(OCPGreyP).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)
#define     OCP_AMBER_PIX   QPixmap(OCPAmberP).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)
#define     OCP_RDAM_PIX   QPixmap(OCPRdAmP).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)
#define     OCP_RDGN_PIX   QPixmap(OCPRdGnP).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)


#define     PDU_GREY_PIX   QPixmap(PDUGreyP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_AMBAF_PIX   QPixmap(PDUAmberAFP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_AMBFW_PIX   QPixmap(PDUAmberFWP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_AMBIN_PIX   QPixmap(PDUAmberINP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_AMBOU_PIX   QPixmap(PDUAmberOUP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_GRNAF_PIX   QPixmap(PDUGreenAFP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_GRNFW_PIX   QPixmap(PDUGreenFWP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_GRNIN_PIX   QPixmap(PDUGreenINP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_GRNOU_PIX   QPixmap(PDUGreenOUP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_AMBER_PIX   QPixmap(PDUAmberP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_GREEN_PIX   QPixmap(PDUGreenP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_RED_PIX   QPixmap(PDURedP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_WHAMB_PIX   QPixmap(PDUWhAmbP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_WHITE_PIX   QPixmap(PDUWhiteP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)
#define     PDU_WHRED_PIX   QPixmap(PDUWhRedP).scaled(PDUWt, PDUHt, Qt::KeepAspectRatio)

#define     LCP_GREEN_PIX(Pos)   QPixmap(LCPGreenP[Pos]).scaled(LCPWt,LCPHt, Qt::KeepAspectRatio)
#define     LCP_GREY_PIX(Pos)   QPixmap(LCPGreyP[Pos]).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)
#define     LCP_AMBER_PIX(Pos)   QPixmap(LCPAmberP[Pos]).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)
#define     LCP_RDAM_PIX(Pos)   QPixmap(LCPRdAmP[Pos]).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)
#define     LCP_RDGN_PIX(Pos)   QPixmap(LCPRdGnP[Pos]).scaled(ICPWt,ICPHt, Qt::KeepAspectRatio)


#endif // ICONMAP_H
