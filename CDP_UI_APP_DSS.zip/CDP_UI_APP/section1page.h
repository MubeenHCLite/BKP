
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : section1page.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef SECTION1PAGE_H
#define SECTION1PAGE_H

#include <QWidget>
#include <QPushButton>
#include "common.h"
#include "pdustatpg.h"
#include "mcpstatuspage.h"
#include "ocpstatuspage.h"

namespace Ui {
class Section1Page;
}

class Section1Page : public QWidget
{
    Q_OBJECT

public:
    explicit Section1Page(QWidget *parent = 0);
    ~Section1Page();

private slots:
    void on_L50_clicked();

    void on_L49_clicked();

    void on_L48_clicked();

    void on_L47_clicked();

    void on_L46_clicked();

    void on_L45_clicked();

    void on_L44_clicked();

    void on_L43_clicked();

    void on_L42_clicked();

    void on_L41_clicked();

    void on_L40_clicked();

    void on_L39_clicked();

    void on_L38_clicked();

    void on_L37_clicked();

    void on_L36_clicked();

    void on_L35_clicked();

    void on_L34_clicked();

    void on_TL01_clicked();

    void on_TL02_clicked();

    void on_TL03_clicked();

    void on_TL04_clicked();

    void on_TL05_clicked();

    void on_TL07_clicked();

    void on_TL08_clicked();

    void on_TL09_clicked();

    void on_TL10_clicked();

    void on_TL10_3_clicked();

    void on_OCPB_clicked();

private:
    Ui::Section1Page *ui;
    QPushButton Sec1PDUs[17];
    PDUStatPg *PduStatP;
    MCPStatusPage   *MCPStatP;
     OCPStatusPage   *OCPStatP;
};

#endif // SECTION1PAGE_H
