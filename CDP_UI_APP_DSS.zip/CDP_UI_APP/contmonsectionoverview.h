
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : contmonsectionoverview.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef CONTMONSECTIONOVERVIEW_H
#define CONTMONSECTIONOVERVIEW_H

#include <QDialog>
#include <QPushButton>
#include "common.h"
#include "section1page.h"
#include "section2page.h"
#include "section3page.h"
#include "section4page.h"
#include "section5page.h"
#include "section6page.h"

/********************* PREPROCESSOR DIRECTIVES  *****************************/
#define CON_BK_BTN_WT       80
#define CON_BK_BTN_HT       80
#define CON_BK_BTN_X        60
#define CON_BK_BTN_Y        40

#define ZN1_BTN_WT       320
#define ZN1_BTN_HT       165
#define ZN1_BTN_X        500
#define ZN1_BTN_Y        50

#define ZN2_BTN_WT       320
#define ZN2_BTN_HT       165
#define ZN2_BTN_X        500
#define ZN2_BTN_Y        240

#define ZN3_BTN_WT       280
#define ZN3_BTN_HT       170
#define ZN3_BTN_X        830
#define ZN3_BTN_Y        50

#define ZN4_BTN_WT       280
#define ZN4_BTN_HT       170
#define ZN4_BTN_X        830
#define ZN4_BTN_Y        240

#define ZN5_BTN_WT       320
#define ZN5_BTN_HT       165
#define ZN5_BTN_X        1120
#define ZN5_BTN_Y        50

#define ZN6_BTN_WT       320
#define ZN6_BTN_HT       165
#define ZN6_BTN_X        1120
#define ZN6_BTN_Y        240

#define INDEX1          1
#define INDEX2          2
#define INDEX3          3
#define INDEX4          4
#define INDEX5          5
#define INDEX6          6
#define INDEX7          7



namespace Ui {
class ContMonSectionOverview;
}

class ContMonSectionOverview : public QDialog
{
    Q_OBJECT

public:
    explicit ContMonSectionOverview(QWidget *parent = 0);
    ~ContMonSectionOverview();
    void ResetButtonsIcons();

private slots:
    void HandleZone1MonButton();
    void HandleZone2MonButton();
    void HandleZone3MonButton();
    void HandleZone4MonButton();
    void HandleZone5MonButton();
    void HandleZone6MonButton();
    void HandleBackButton();

private:
    Ui::ContMonSectionOverview *ui;
    QPushButton             *Zone1Button;
    QPushButton             *Zone2Button;
    QPushButton             *Zone3Button;
    QPushButton             *Zone4Button;
    QPushButton             *Zone5Button;
    QPushButton             *Zone6Button;
    QPushButton             *BackButton;
    Section1Page            Section1;
    Section2Page            Section2;
    Section3Page            Section3;
    Section4Page            Section4;
    Section5Page            Section5;
    Section6Page            Section6;
};

#endif // CONTMONSECTIONOVERVIEW_H
