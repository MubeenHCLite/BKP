/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : lcp20ftstatuspage.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : The CDP OPSW to manage all fields in the LCP 20Ft status display
 *                Provides tabular information on the status of the CP Signals
 *
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "lcp20ftstatuspage.h"
#include "ui_lcp20ftstatuspage.h"

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the LCP Status application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
LCP20FTStatusPage::LCP20FTStatusPage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LCP20FTStatusPage)
{
    ui->setupUi(this);
}

LCP20FTStatusPage::~LCP20FTStatusPage()
{
    delete ui;
}
