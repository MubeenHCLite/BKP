/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : section3page.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : Provides implementation of Access sections, listing all the LRUs
 *                (CPs and PDUs). Implementation of Navigation to Status page of
 *                the LRUs listed in the section.
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "section3page.h"
#include "ui_section3page.h"

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the Section Page application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
Section3Page::Section3Page(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Section3Page)
{
    ui->setupUi(this);
    qDebug() << "Section 3 Page";

    LCPStatusP = new LCPStatusPage(this);
    PduStatP = new PDUStatPg(this);
}

Section3Page::~Section3Page()
{
    delete ui;
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Respective LRU Status screens
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void Section3Page::on_LH4_clicked()
{
    LCPStatusP->LCPName = "LCP 4LH";
    LCPStatusP->LCPNum = LCP4LH;
    CurrPage = OCP_STATUS;
    PrevPage = ACC_ZONE;
    LCPStatusP->show();

}

void Section3Page::on_L18_clicked()
{
    PduStatP->PDUNum = 17;
    PduStatP->PDUName = "PDU L 18";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L19_clicked()
{
    PduStatP->PDUNum = 18;
    PduStatP->PDUName = "PDU L 19";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L20_clicked()
{
    PduStatP->PDUNum = 19;
    PduStatP->PDUName = "PDU L 20";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L21_clicked()
{
    PduStatP->PDUNum = 20;
    PduStatP->PDUName = "PDU L 21";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L22_clicked()
{
    PduStatP->PDUNum = 21;
    PduStatP->PDUName = "PDU L 22";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L23_clicked()
{
    PduStatP->PDUNum = 22;
    PduStatP->PDUName = "PDU L 23";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L24_clicked()
{
    PduStatP->PDUNum = 23;
    PduStatP->PDUName = "PDU L 24";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L25_clicked()
{
    PduStatP->PDUNum = 24;
    PduStatP->PDUName = "PDU L 25";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L26_clicked()
{
    PduStatP->PDUNum = 25;
    PduStatP->PDUName = "PDU L 26";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L27_clicked()
{
    PduStatP->PDUNum = 26;
    PduStatP->PDUName = "PDU L 27";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L28_clicked()
{
    PduStatP->PDUNum = 27;
    PduStatP->PDUName = "PDU L 28";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L29_clicked()
{
    PduStatP->PDUNum = 28;
    PduStatP->PDUName = "PDU L 29";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L30_clicked()
{
    PduStatP->PDUNum = 29;
    PduStatP->PDUName = "PDU L 30";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L31_clicked()
{
    PduStatP->PDUNum = 30;
    PduStatP->PDUName = "PDU L 31";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L32_clicked()
{
    PduStatP->PDUNum = 31;
    PduStatP->PDUName = "PDU L 32";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_L33_clicked()
{
    PduStatP->PDUNum = 32;
    PduStatP->PDUName = "PDU L 33";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section3Page::on_LH3_clicked()
{
    LCPStatusP->LCPName = "LCP 3LH";
    LCPStatusP->LCPNum = LCP3LH;
    CurrPage = OCP_STATUS;
    PrevPage = ACC_ZONE;
    LCPStatusP->show();
}
