#ifndef NVMSTORGAE_H
#define NVMSTORGAE_H

#include "common.h"

typedef struct{
    uint8_t  ConfRecordCount;
    uint8_t  FaultRecordCount;
    uint8_t  Spare[3];
    uint8_t  HeaderCheckSum;
}NVM_Header_Layout;

typedef struct{
    uint8_t RecordNumber;
    uint64_t HWFIN;
    uint8_t SWFIN[12];
    uint32_t MSN;
    uint32_t CityCode;
    uint8_t  NodeID;
}Config_Record_Layout;

typedef struct{
    uint8_t HeaderStart;
    uint8_t DLRequestFlag;
    uint8_t DLALRUID;
    uint8_t InformationChecksum;
}DL_Information_Layout;

typedef struct{
    uint8_t RecordNumber;
    uint8_t FSID;
    uint64_t UTC;
    uint32_t CityCode;
}Fault_Record_Layout;

typedef struct{
    NVM_Header_Layout       NVMHeader;
    Config_Record_Layout    ConfigRecord[5];
    DL_Information_Layout   DLInfo;
    Fault_Record_Layout     FaultRecord[50];
}NVM_Layout;

bool NVMUpdate();

#endif // NVMSTORGAE_H
