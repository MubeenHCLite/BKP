#ifndef POWERSUPPLY_H
#define POWERSUPPLY_H

#include <QThread>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <err.h>
#include <errno.h>
#include <unistd.h>

#include <linux/types.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>

#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


#define     POWER_SUPPLY_SLAVE_ADD  0x44
#define     POWER_SUPPLY_DEV_PATH   "/dev/i2c-101"
#define     BUS_VOLTAGE_REG_ADD     (void *)(0x00000005U)
#define     CURRENT_REG_ADD         (void *)(0x00000007U)
#define     POWER_REG_ADD           (void *)(0x00000008U)

class PowerSupply : public QThread
{
public:
    PowerSupply(QObject *parent=0);
    void run();

private:
    bool InitPowerSupply();
    int  PowerSupplyFileDesc;
    float BusVoltage;
    float CurrentDrawn;
    float PowerConsumed;

};

#endif // POWERSUPPLY_H
