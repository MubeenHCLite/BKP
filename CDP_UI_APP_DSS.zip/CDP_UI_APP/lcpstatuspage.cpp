/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : lcptstatuspage.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : The CDP OPSW to manage all fields in the LCP status display
 *                Provides tabular information on the status of the CP Signals
 *
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "lcpstatuspage.h"
#include "ui_lcpstatuspage.h"
#include "common.h"
#include "commondata.h"
#include <QDebug>

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the LCP Status application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
LCPStatusPage::LCPStatusPage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LCPStatusPage)
{
    ui->setupUi(this);

    //set the page background
    qDebug() << "LCP Status Page";

    QPixmap Background(BaseFolder + "LCPStatusPgBkg.png");
    Background = Background.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette Palette;
    Palette.setBrush(QPalette::Window, Background);
    this->setPalette(Palette);

    LCPNum = 0;

    BackButton = new QPushButton("", this);
    BackButton->setGeometry(QRect(QPoint(LCP_BK_BTN_X, LCP_BK_BTN_Y), QSize(LCP_BK_BTN_WT, LCP_BK_BTN_HT)));
    QPixmap BackButtonBkg(BaseFolder + "BackButton.png");
    QIcon BackButtonIcon(BackButtonBkg.scaled(LCP_BK_BTN_WT, LCP_BK_BTN_HT,Qt::KeepAspectRatio));
    BackButton->setIcon(BackButtonIcon);
    BackButton->setIconSize(BackButtonBkg.rect().size());
    connect(BackButton, &QPushButton::released, this, &LCPStatusPage::HandleBackButton);


    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(UpdateUI()));
    timer->setInterval(ONE_MS);
    timer->start();
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Cont Monitoring screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void LCPStatusPage::HandleBackButton(){
    CurrPage = PrevPage;
    PrevPage = LCP_STATUS;
    hide();
}

/*-----------------------------------------------------------------------------
 *  Description : Implementation of continous indicators update on the screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void LCPStatusPage::UpdateUI()
{
    ui->LCPTable1->setItem(0, 1, new QTableWidgetItem(LCPName));
    uint8_t LCPNum = 0;
    if(CurrPage == LCP_STATUS){
        //Drive [FWD/AFT] Indicator
        if(_LCP[LCPNum].Command.Signal.LCP_TGLS_Drive_Fault == TRUE){
            //Set to Invalid
            ui->LCPTable1->setItem(ROW1, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_LCP[LCPNum].Command.Signal.LCP_TGLS_Drive_AFT == TRUE){
            //Set to AFT
            ui->LCPTable1->setItem(ROW1, COLUMN1, new QTableWidgetItem("AFT"));
        }
        else if(_LCP[LCPNum].Command.Signal.LCP_TGLS_Drive_FWD  == TRUE){
            //Set to OFF
            ui->LCPTable1->setItem(ROW1, COLUMN1, new QTableWidgetItem("FWD"));
        }

        //Panel Enabled Indicator
 /*       if(_LCP[LCPNum].Command.Signal.LCP_LED_Panel_Enabled_Fault == TRUE){
            //Set to Invalid
            ui->LCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_LCP[LCPNum].Status.Signal.LCP_LED_Panel_Enabled == TRUE){
            //Set to Enabled
            ui->LCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Enabled"));
        }
        else if(_LCP[LCPNum].Status.Signal.LCP_LED_Panel_Enabled  == FALSE){
            //Set to Disabled
            ui->LCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Disabled"));
        }
*/
        //PDU Stop Indicator
        if(_LCP[LCPNum].Command.Signal.LCP_PB_PDU_Stop_Fault== TRUE){
            //Set to Invalid
            ui->LCPTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_LCP[LCPNum].Command.Signal.LCP_PB_PDU_Stop == TRUE){
            //Set to ON
            ui->LCPTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("ON"));
        }
        else if(_LCP[LCPNum].Command.Signal.LCP_PB_PDU_Stop  == FALSE){
            //Set to OFF
            ui->LCPTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("OFF"));
        }

        //Dual Lane Indicator
        if(_LCP[LCPNum].Command.Signal.LCP_PB_Dual_Lane == TRUE){
            //Set to Invalid
            ui->LCPTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_LCP[LCPNum].Status.Signal.LCP_PB_Dual_Lane_LED == TRUE){
            //Set to Enabled
            ui->LCPTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("Enabled"));
        }
        else if(_LCP[LCPNum].Status.Signal.LCP_PB_Dual_Lane_LED  == FALSE){
            //Set to Disabled
            ui->LCPTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("Disabled"));
        }

        //Unlock Next Indicator
        if(_LCP[LCPNum].Command.Signal.LCP_PB_Unlock_Next == TRUE){
            //Set to Invalid
            ui->LCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_LCP[LCPNum].Status.Signal.LCP_PB_Unlock_Next_LED == TRUE){
            //Set to Enabled
            ui->LCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("Enabled"));
        }
        else if(_LCP[LCPNum].Status.Signal.LCP_PB_Unlock_Next_LED  == FALSE){
            //Set to Disabled
            ui->LCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("Disabled"));
        }

        ui->LCPTable1->setItem(ROW7,COLUMN1, new QTableWidgetItem(QString::number(_LCP[LCPNum].Command.Signal.LCP_Mux_Current_Voltage)));
        ui->LCPTable1->setItem(ROW8,COLUMN1, new QTableWidgetItem(QString::number(_LCP[LCPNum].Command.Signal.LCP_Measured_Current_Voltage)));

    }

    //OCP Switch Fault
    if(_LCP[LCPNum].Command.Signal.LCP_Switch_Fault_Status == TRUE){
        ui->LCPTable2->setItem(ROW0,COLUMN1, new QTableWidgetItem("True"));
    }
    else {
        ui->LCPTable2->setItem(ROW0,COLUMN1, new QTableWidgetItem("False"));
    }

    //PDU Stop Fault
    if(_LCP[LCPNum].Command.Signal.LCP_PB_PDU_Stop_Fault == TRUE){
        ui->LCPTable2->setItem(ROW1,COLUMN1, new QTableWidgetItem("True"));
    }
    else {
        ui->LCPTable2->setItem(ROW1,COLUMN1, new QTableWidgetItem("False"));
    }

    //TGL Switch Drive Fault
    if(_LCP[LCPNum].Command.Signal.LCP_TGLS_Drive_Fault == TRUE){
        ui->LCPTable2->setItem(ROW2,COLUMN1, new QTableWidgetItem("True"));
    }
    else {
        ui->LCPTable2->setItem(ROW2,COLUMN1, new QTableWidgetItem("False"));
    }

    //Dual Lane Fault
    if(_LCP[LCPNum].Command.Signal.LCP_PB_Dual_Lane_Fault == TRUE){
        ui->LCPTable2->setItem(ROW3,COLUMN1, new QTableWidgetItem("True"));
    }
    else {
        ui->LCPTable2->setItem(ROW3,COLUMN1, new QTableWidgetItem("False"));
    }

    //Unlock Next Fault
    if(_LCP[LCPNum].Command.Signal.LCP_PB_Unlock_Next_Fault == TRUE){
        ui->LCPTable2->setItem(ROW4,COLUMN1, new QTableWidgetItem("True"));
    }
    else {
        ui->LCPTable2->setItem(ROW4,COLUMN1, new QTableWidgetItem("False"));
    }

    //Lamp Test Fault
    if(_LCP[LCPNum].Command.Signal.LCP_PB_Lamp_Test_Fault == TRUE){
        ui->LCPTable2->setItem(ROW5,COLUMN1, new QTableWidgetItem("True"));
    }
    else {
        ui->LCPTable2->setItem(ROW5,COLUMN1, new QTableWidgetItem("False"));
    }

    //LED Panel Enabled Fault
/*    if(_LCP[LCPNum].Command.Signal.LCP_LED_Panel_Enabled_Fault == TRUE){
        ui->LCPTable2->setItem(ROW6,COLUMN1, new QTableWidgetItem("True"));
    }
    else {
        ui->LCPTable2->setItem(ROW6,COLUMN1, new QTableWidgetItem("False"));
    }
*/

    timer->setInterval(ONE_SEC);

}

LCPStatusPage::~LCPStatusPage()
{
    delete ui;
}
