/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : canreadwrite.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : Implementation of CAN RX/TX Thread to recieve signals of all
 *                LRUs. Implementation of CAN Message queue.
 *
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */


/****************************** HEADER FILES *********************************/
#include "canreadwrite.h"
#include <string.h>
#include<QDebug>
#include<QString>
#include <QQueue>

/********************************* GLOBAL DATA ELEMENTS ***********************/
extern QQueue<CAN_DATA>     canBuffer;

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the CAN thread
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
CANReadWrite::CANReadWrite(QObject *parent) : QThread(parent)
{

}

bool CANReadWrite::OpenCANPort(){
    struct sockaddr_can Addr;
    struct ifreq ifr;

    if ((sock = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) {
            perror("Socket");
            return 1;
    }

    strcpy(ifr.ifr_name, "can0" );
    ioctl(sock, SIOCGIFINDEX, &ifr);

    memset(&Addr, 0, sizeof(Addr));
    Addr.can_family = AF_CAN;
    Addr.can_ifindex = ifr.ifr_ifindex;

    if (bind(sock, (struct sockaddr *)&Addr, sizeof(Addr)) < 0) {
            perror("Bind");
            return 0;
    }
    return 1;
}

/*-----------------------------------------------------------------------------
 *  Description : This is the main thread funcationlity of CAN thread
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void CANReadWrite::run(){
    uint8_t BytesRead,Pos;
    struct can_frame Frame;
    CAN_DATA RxData;
    RxData.arbitration.Data = 0;
    RxData.DLC = 0;
    RxData.Payload = 0;
    bool Res = OpenCANPort();
    if(Res){
        while(1){
            qDebug() << "CAN Thread";
            BytesRead = read(sock, &Frame, sizeof(struct can_frame));
            //QThread::sleep(1);
            if(BytesRead){
                RxData.arbitration.Data = Frame.can_id;
                RxData.DLC = Frame.can_dlc;
                //memcpy(&RxData.Payload, &Frame.data, Frame.can_dlc);

                RxData.Payload = ((RxData.Payload & 0x00000000000000FF)<<56)|
                                 ((RxData.Payload & 0x000000000000FF)<<40)|
                                 ((RxData.Payload & 0x0000000000FF)<<24)|
                                 ((RxData.Payload & 0x00000000FF)<<8)|
                                 ((RxData.Payload & 0x000000FF)>>8)|
                                 ((RxData.Payload & 0x0000FF)>>24)|
                                 ((RxData.Payload & 0x00FF)>>40)|
                                 ((RxData.Payload & 0xFF)>>56);
                                 \


                for(Pos = Frame.can_dlc-1 ; Pos >= 0 ; Pos--){
                    RxData.Payload = RxData.Payload << 8;
                    RxData.Payload |= Frame.data[Pos];
                }

                qDebug() << "Input Arb : " << RxData.arbitration.Data;
                qDebug() << "Input Payload : " << QString("%1").arg(RxData.Payload,0,16);
                canBuffer.enqueue(RxData);
                ParserThread();
            }
        }
    }

}
