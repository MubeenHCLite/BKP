/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : detailedsystemstatusw.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : The CDP OPSW main display page implementation. This implementation
 *                provides Display indications for all LRUs (Control Panels, PDUs,
 *                Access Zones ).It also provides navigation options to Maintenance window.
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "detailedsystemstatusw.h"
#include "ui_detailedsystemstatusw.h"
#include <QDebug>

/********************* PREPROCESSOR DIRECTIVES  *****************************/
#define PDU_POS_START_DS    1800

/********************* PREPROCESSOR DIRECTIVES  *****************************/
static QLabel*             PDUIndication[PDU_MAX_COUNT];
static QLabel*             MCPIndicator;
static QLabel*             ICPIndicator;
static QLabel*             OCPIndicator;
static QLabel*             LCPIndicator[8];

static int MCPHt = 100;
static int MCPWt = 100;
static int ICPHt = 80;
static int ICPWt = 100;
static int OCPHt = 50;
static int OCPWt = 110;
static int LCPHt = 50;
static int LCPWt = 120;
static int PDUHt = 30;
static int PDUWt = 20;

int YCord[116] = {210,210,210,210,210,210,210,210,210,210,210,
                     210,210,210,210,210,210,210,210,210,210,210,210,
                     210,210,210,210,210,210,210,210,210,210,210,210,
                     210,210,210,210,210,210,210,210,210,210,210,210,210,
                     210,210,260,260,260,260,260,260,170,170,170,340,340,
                     340,340,340,340,340,340,340,340,340,
                     340,340,340,340,340,340,340,340,340,340,340,340,340,
                     340,340,340,340,340,340,340,340,340,340,340,340,340,
                     340,340,340,340,340,340,340,340,340,340,340,340,340,
                     300,300,300,300,300,300,300};


/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the detail system status of application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
DetailedSystemStatusW::DetailedSystemStatusW(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DetailedSystemStatusW)
{
    ui->setupUi(this);
    ui->setupUi(this);
     qDebug() << "DSS Page";

    QPixmap Background(BaseFolder + "DetailedSysStatusBkg.png");
    Background = Background.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette Palette;
    Palette.setBrush(QPalette::Window, Background);
    this->setPalette(Palette);

    BackButton = new QPushButton("", this);
    BackButton->setGeometry(QRect(QPoint(DSS_BK_BTN_X, DSS_BK_BTN_Y), QSize(DSS_BK_BTN_WT, DSS_BK_BTN_HT)));
    QPixmap BackButtonBkg(BaseFolder + "BackButton.png");
    QIcon BackButtonIcon(BackButtonBkg.scaled(DSS_BK_BTN_WT, DSS_BK_BTN_HT,Qt::KeepAspectRatio));
    BackButton->setIcon(BackButtonIcon);
    BackButton->setIconSize(BackButtonBkg.rect().size());
    connect(BackButton, &QPushButton::released, this, &DetailedSystemStatusW::HandleBackButton);

    qDebug() << "DSS PDUs";
    int Pos;

    for(Pos = 0; Pos < PDU_MAX_COUNT  ; Pos++){
            PDUIndication[Pos] = new QLabel(this);
            PDUIndication[Pos]->setFrameStyle(QFrame::Panel | QFrame::Sunken);

            PDUIndication[Pos]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
            PDUIndication[Pos]->setGeometry(QRect(PDUXCord[Pos] + 70,YCord[Pos] + 20,DSS_PDU_IND_WT,DSS_PDU_IND_HT));
            PDUIndication[Pos]->setPixmap(PDU_GREY_PIX);
    }
       qDebug() << "DSS CPs";

    MCPIndicator = new QLabel(this);
    MCPIndicator->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    MCPIndicator->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    MCPIndicator->setGeometry(QRect(DSS_MCP_IND_X,DSS_MCP_IND_Y,DSS_MCP_IND_WT,DSS_MCP_IND_HT));
    //MCPIndicator->setPixmap(Background.scaled(50,50, Qt::KeepAspectRatio));
    MCPIndicator->setPixmap(MCP_GREY_PIX);

    //ICP
    ICPIndicator = new QLabel(this);
    ICPIndicator->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    ICPIndicator->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    ICPIndicator->setGeometry(QRect(DSS_ICP_IND_X,DSS_ICP_IND_Y,DSS_ICP_IND_WT,DSS_ICP_IND_HT));
    ICPIndicator->setPixmap(ICP_GREY_PIX);

    //OCP
    OCPIndicator = new QLabel(this);
    OCPIndicator->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    OCPIndicator->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    OCPIndicator->setGeometry(QRect(DSS_OCP_IND_X,DSS_OCP_IND_Y,DSS_OCP_IND_WT,DSS_OCP_IND_HT));
    OCPIndicator->setPixmap(OCP_GREY_PIX);

    //LCPs
    LCPIndicator[LCP4LH] = new QLabel(this);
    LCPIndicator[LCP4LH]->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    LCPIndicator[LCP4LH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP4LH]->setGeometry(QRect(DSS_LCP4_IND_X,DSS_LCPH_IND_Y,DSS_LCP_IND_WT,DSS_LCP_IND_HT));
    LCPIndicator[LCP4LH]->setPixmap(LCP_GREY_PIX(LCP4LH));

    LCPIndicator[LCP3LH] = new QLabel(this);
    LCPIndicator[LCP3LH]->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    LCPIndicator[LCP3LH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP3LH]->setGeometry(QRect(DSS_LCP3_IND_X,DSS_LCPH_IND_Y,DSS_LCP_IND_WT,DSS_LCP_IND_HT));
    LCPIndicator[LCP3LH]->setPixmap(LCP_GREY_PIX(LCP3LH));

    LCPIndicator[LCP2LH] = new QLabel(this);
    LCPIndicator[LCP2LH]->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    LCPIndicator[LCP2LH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP2LH]->setGeometry(QRect(DSS_LCP2_IND_X,DSS_LCPH_IND_Y,DSS_LCP_IND_WT,DSS_LCP_IND_HT));
    LCPIndicator[LCP2LH]->setPixmap(LCP_GREY_PIX(LCP2LH));


    LCPIndicator[LCP1LH] = new QLabel(this);
    LCPIndicator[LCP1LH]->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    LCPIndicator[LCP1LH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP1LH]->setGeometry(QRect(DSS_LCP1_IND_X,DSS_LCPH_IND_Y,DSS_LCP_IND_WT,DSS_LCP_IND_HT));
    LCPIndicator[LCP1LH]->setPixmap(LCP_GREY_PIX(LCP1LH));

    LCPIndicator[LCP4RH] = new QLabel(this);
    LCPIndicator[LCP4RH]->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    LCPIndicator[LCP4RH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP4RH]->setGeometry(QRect(DSS_LCP4_IND_X,DSS_LCPR_IND_Y,DSS_LCP_IND_WT,DSS_LCP_IND_HT));
    LCPIndicator[LCP4RH]->setPixmap(LCP_GREY_PIX(LCP4RH));

    LCPIndicator[LCP3RH] = new QLabel(this);
    LCPIndicator[LCP3RH]->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    LCPIndicator[LCP3RH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP3RH]->setGeometry(QRect(DSS_LCP3_IND_X,DSS_LCPR_IND_Y,DSS_LCP_IND_WT,DSS_LCP_IND_HT));
    LCPIndicator[LCP3RH]->setPixmap(LCP_GREY_PIX(LCP3RH));

    LCPIndicator[LCP2RH] = new QLabel(this);
    LCPIndicator[LCP2RH]->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    LCPIndicator[LCP2RH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP2RH]->setGeometry(QRect(DSS_LCP2_IND_X,DSS_LCPR_IND_Y,DSS_LCP_IND_WT,DSS_LCP_IND_HT));
    LCPIndicator[LCP2RH]->setPixmap(LCP_GREY_PIX(LCP2RH));

    LCPIndicator[LCP1RH] = new QLabel(this);
    LCPIndicator[LCP1RH]->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    LCPIndicator[LCP1RH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP1RH]->setGeometry(QRect(DSS_LCP1_IND_X,DSS_LCPR_IND_Y,DSS_LCP_IND_WT,DSS_LCP_IND_HT));
    LCPIndicator[LCP1RH]->setPixmap(LCP_GREY_PIX(LCP1RH));

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(UpdateUI()));
    timer->setInterval(ONE_MS);
    timer->start();
    qDebug() << "DSS Page End";

    timerIsr = new QTimer(this);
    connect(timerIsr, SIGNAL(timeout()), this, SLOT(UpdateUItable()));
    timerIsr->setInterval(ONE_MS);
    timerIsr->start();
    qDebug() << "DSS Page End1";

    timerIsrOCP = new QTimer(this);
    connect(timerIsrOCP, SIGNAL(timeout()), this, SLOT(UpdateUItableOCP()));
    timerIsrOCP->setInterval(ONE_MS);
    timerIsrOCP->start();
    qDebug() << "DSS Page End2";

    timerIsrLCP = new QTimer(this);
    connect(timerIsrLCP, SIGNAL(timeout()), this, SLOT(UpdateUItableLCP()));
    timerIsrLCP->setInterval(ONE_MS);
    timerIsrLCP->start();
    qDebug() << "DSS Page End2";

}





void DetailedSystemStatusW::UpdateUItableLCP(){

    uint8_t LCPNum = 0;
   // ui->LCPtable->setItem(ROW0, COLUMN1, new QTableWidgetItem("CP NAME"));
    uint8_t Column =0;

    for (LCPNum =0; LCPNum < 8 ; LCPNum++){
        Column = 1 + LCPNum;
        if(_LCP[LCPNum].Command.Signal.LCP_TGLS_Drive_Fault == TRUE){
            //Set to Invalid
            ui->LCPtable->setItem(ROW1, Column, new QTableWidgetItem("Invalid"));
        }
        else if(_LCP[LCPNum].Command.Signal.LCP_TGLS_Drive_AFT == TRUE){
            //Set to AFT
            ui->LCPtable->setItem(ROW1, Column, new QTableWidgetItem("AFT"));
        }
        else if(_LCP[LCPNum].Command.Signal.LCP_TGLS_Drive_FWD  == TRUE){
            //Set to OFF
            ui->LCPtable->setItem(ROW1, Column, new QTableWidgetItem("FWD"));
        }

        //Panel Enabled Indicator
 /*       if(_LCP[LCPNum].Command.Signal.LCP_LED_Panel_Enabled_Fault == TRUE){
            //Set to Invalid
            ui->LCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_LCP[LCPNum].Status.Signal.LCP_LED_Panel_Enabled == TRUE){
            //Set to Enabled
            ui->LCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Enabled"));
        }
        else if(_LCP[LCPNum].Status.Signal.LCP_LED_Panel_Enabled  == FALSE){
            //Set to Disabled
            ui->LCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Disabled"));
        }
*/

        //PDU Stop Indicator
        if(_LCP[LCPNum].Command.Signal.LCP_PB_PDU_Stop_Fault== TRUE){
            //Set to Invalid
            ui->LCPtable->setItem(ROW3, Column, new QTableWidgetItem("Invalid"));
        }
        else if(_LCP[LCPNum].Command.Signal.LCP_PB_PDU_Stop == TRUE){
            //Set to ON
            ui->LCPtable->setItem(ROW3, Column, new QTableWidgetItem("ON"));
        }
        else if(_LCP[LCPNum].Command.Signal.LCP_PB_PDU_Stop  == FALSE){
            //Set to OFF
            ui->LCPtable->setItem(ROW3, Column, new QTableWidgetItem("OFF"));
        }

        //Dual Lane Indicator
        if(_LCP[LCPNum].Command.Signal.LCP_PB_Dual_Lane == TRUE){
            //Set to Invalid
            ui->LCPtable->setItem(ROW4, Column, new QTableWidgetItem("Invalid"));
        }
        else if(_LCP[LCPNum].Status.Signal.LCP_PB_Dual_Lane_LED == TRUE){
            //Set to Enabled
            ui->LCPtable->setItem(ROW4, Column, new QTableWidgetItem("Enabled"));
        }
        else if(_LCP[LCPNum].Status.Signal.LCP_PB_Dual_Lane_LED  == FALSE){
            //Set to Disabled
            ui->LCPtable->setItem(ROW4, Column, new QTableWidgetItem("Disabled"));
        }

        //Unlock Next Indicator
        if(_LCP[LCPNum].Command.Signal.LCP_PB_Unlock_Next == TRUE){
            //Set to Invalid
            ui->LCPtable->setItem(ROW5, Column, new QTableWidgetItem("Invalid"));
        }
        else if(_LCP[LCPNum].Status.Signal.LCP_PB_Unlock_Next_LED == TRUE){
            //Set to Enabled
            ui->LCPtable->setItem(ROW5, Column, new QTableWidgetItem("Enabled"));
        }
        else if(_LCP[LCPNum].Status.Signal.LCP_PB_Unlock_Next_LED  == FALSE){
            //Set to Disabled
            ui->LCPtable->setItem(ROW5, Column, new QTableWidgetItem("Disabled"));
        }

        //TGL Switch Drive Fault
        if(_LCP[LCPNum].Command.Signal.LCP_TGLS_Drive_Fault == TRUE){
            ui->LCPtable->setItem(ROW6, Column, new QTableWidgetItem("True"));
        }
        else {
            ui->LCPtable->setItem(ROW6, Column, new QTableWidgetItem("False"));
        }


    }

     timerIsrLCP->setInterval(ONE_SEC);
}


void DetailedSystemStatusW::UpdateUItableOCP(){

    ui->OCPtable->setItem(ROW0, COLUMN1, new QTableWidgetItem("OCP"));

    //ON/OFF Indicator
   if(_OCP.Command.Signal.OCP_PB_Power_On_Off == TRUE){
       //Set to Invalid
       ui->OCPtable->setItem(ROW1, COLUMN1, new QTableWidgetItem("Invalid"));
   }
   else if(_OCP.Status.Signal.PB_On_Off_LED == TRUE){
       //Set to ON
       ui->OCPtable->setItem(ROW1, COLUMN1, new QTableWidgetItem("ON"));
   }
   else if(_OCP.Status.Signal.PB_On_Off_LED == FALSE){
       //Set to OFF
       ui->OCPtable->setItem(ROW1, COLUMN1, new QTableWidgetItem("OFF"));
   }


   //System Active Indicator
//   if(_OCP.Command.Signal.OCP_LED_System_Active_Fault == TRUE){
//       //Set to Invalid
//       ui->OCPtable->setItem(ROW2, COLUMN1, new QTableWidgetItem("ON"));
//   }
//   else if(_OCP.Status.Signal.LED_System_Active == TRUE){
//       //Set to ON
//       ui->OCPtable->setItem(ROW2, COLUMN1, new QTableWidgetItem("Active"));
//   }
//   else if(_OCP.Status.Signal.LED_System_Active == FALSE){
//       //Set to OFF
//       ui->OCPtable->setItem(ROW2, COLUMN1, new QTableWidgetItem("Inactive"));
//   }


   //Zone Indicator
   if((_OCP.Command.Signal.OCP_PB_Zone_Select_AFT == TRUE &&
        _OCP.Command.Signal.OCP_PB_Zone_Select_AFT_Fault == TRUE) ||
       (_OCP.Command.Signal.OCP_PB_Zone_Select_FWD== TRUE &&
        _OCP.Command.Signal.OCP_PB_Zone_Select_FWD_Fault == TRUE) ||
       (_OCP.Command.Signal.OCP_PB_Zone_Select_AFT == TRUE &&
        _OCP.Command.Signal.OCP_PB_Zone_Select_FWD== TRUE )){
           //Set to Invalid
       ui->OCPtable->setItem(ROW3, COLUMN1, new QTableWidgetItem("Invalid"));
   }
   if(_OCP.Command.Signal.OCP_PB_Zone_Select_AFT == TRUE){
       //Set to AFT
       ui->OCPtable->setItem(ROW3, COLUMN1, new QTableWidgetItem("AF"));
   }
   else if(_OCP.Command.Signal.OCP_PB_Zone_Select_FWD == TRUE){
       //Set to FWD
       ui->OCPtable->setItem(ROW3, COLUMN1, new QTableWidgetItem("FWD"));
   }




   //20Ft Indicator
   if(_OCP.Command.Signal.OCP_PB_20FT_Fault == TRUE){
               //Set to Invlaid
       ui->OCPtable->setItem(ROW5, COLUMN1, new QTableWidgetItem("ON"));
   }
   else if(_OCP.Command.Signal.OCP_PB_20FT == TRUE){
       //Set to Enabled
       ui->OCPtable->setItem(ROW5, COLUMN1, new QTableWidgetItem("Enabled"));
   }
   else if(_OCP.Command.Signal.OCP_PB_20FT == FALSE){
       //Set to Disabled
       ui->OCPtable->setItem(ROW5, COLUMN1, new QTableWidgetItem("Disabled"));
   }


   //Dual OPerator Indicator
   if(_OCP.Command.Signal.OCP_PB_Dual_Operator_Fault== TRUE){
               //Set to Invlaid
       ui->OCPtable->setItem(ROW6, COLUMN1, new QTableWidgetItem("ON"));
   }
   else if(_OCP.Command.Signal.OCP_PB_Dual_Operator == TRUE){
       //Set to Enabled
       ui->OCPtable->setItem(ROW6, COLUMN1, new QTableWidgetItem("Enabled"));
   }
   else if(_OCP.Command.Signal.OCP_PB_Dual_Operator == FALSE){
       //Set to Disabled
       ui->OCPtable->setItem(ROW6, COLUMN1, new QTableWidgetItem("Disabled"));
   }

   //20FT IN OUT Indicator
   if(_OCP.Command.Signal.OCP_TGLS_20FT_Fault== TRUE){
               //Set to Invlaid
       ui->OCPtable->setItem(ROW7, COLUMN1, new QTableWidgetItem("Invalid"));
   }
   else if(_OCP.Command.Signal.OCP_TGLS_20FT_IN == TRUE){
       //Set to IN
       ui->OCPtable->setItem(ROW7, COLUMN1, new QTableWidgetItem("IN"));
   }
   else if(_OCP.Command.Signal.OCP_TGLS_20FT_OUT == TRUE){
       //Set to Out
       ui->OCPtable->setItem(ROW7, COLUMN1, new QTableWidgetItem("OUT"));
   }

   //PDU STOP indicator
/*        if(_OCP.Command.Signal.OCP_PB_PDU_Stop_Fault == TRUE){
       //Set to Invlaid
       ui->OCPtable->setItem(ROW10, COLUMN1, new QTableWidgetItem("Invalid"));
   }
   else if(_OCP.Command.Signal.OCP_PB_PDU_Stop == TRUE){
       //Set to ON
       ui->OCPtable->setItem(ROW10, COLUMN1, new QTableWidgetItem("ON"));
   }
   else if(_OCP.Command.Signal.OCP_PB_PDU_Stop == FALSE){
       //Set to OFF
       ui->OCPtable->setItem(ROW10, COLUMN1, new QTableWidgetItem("OFF"));
   }

   */
    timerIsrOCP->setInterval(ONE_SEC);
}


void DetailedSystemStatusW::UpdateUItable(){

    //ui->MCPICTtable->setItem(ROW0, COLUMN1, new QTableWidgetItem("CPName"));
    // ui->MCPICTtable->setItem(ROW0, COLUMN2, new QTableWidgetItem("MCP"));
   // ui->MCPICTtable->setItem(ROW0, COLUMN1, new QTableWidgetItem("CPName"));
    ui->MCPICTtable->setItem(ROW0, COLUMN1, new QTableWidgetItem("MCP"));
   // ui->MCPICTtable->setItem(ROW0, COLUMN1, new QTableWidgetItem("ICP"));

    //Power On off Fault
    if(_MCP.Command.Signal.MCP_PB_Power_On_Off_Fault == TRUE){
        ui->MCPICTtable->setItem(ROW1, COLUMN1, new QTableWidgetItem("True"));
    }
    else {
        ui->MCPICTtable->setItem(ROW1, COLUMN1, new QTableWidgetItem("False"));
    }

    //System Active Indicator
    //if(_MCP.Command.Signal.MCP_LED_System_Active_Fault == TRUE){
        //Set to Invalid
    //    ui->MCPICTtable->setItem(ROW2, COLUMN1, new QTableWidgetItem("Invalid"));
    //}
    //else
    if(_MCP.Status.Signal.LED_System_Active == TRUE){
        //Set to ON
        ui->MCPICTtable->setItem(ROW2, COLUMN1, new QTableWidgetItem("Active"));
    }
    else if(_MCP.Status.Signal.LED_System_Active == FALSE){
        //Set to OFF
        ui->MCPICTtable->setItem(ROW2, COLUMN1, new QTableWidgetItem("Inactive"));
    }
    else{
        ui->MCPICTtable->setItem(ROW2, COLUMN1, new QTableWidgetItem("xxxxxx"));
    }

    //Zone Indicator
    if((_MCP.Command.Signal.MCP_PB_Zone_Select_AFT == TRUE &&
         _MCP.Command.Signal.MCP_PB_Zone_Select_AFT_Fault == TRUE) ||
        (_MCP.Command.Signal.MCP_PB_Zone_Select_FWD== TRUE &&
         _MCP.Command.Signal.MCP_PB_Zone_Select_FWD_Fault == TRUE) ||
        (_MCP.Command.Signal.MCP_PB_Zone_Select_AFT == TRUE &&
         _MCP.Command.Signal.MCP_PB_Zone_Select_FWD== TRUE )){
            //Set to Invalid
        ui->MCPICTtable->setItem(ROW3, COLUMN1, new QTableWidgetItem("Invalid"));
    }
    if(_MCP.Command.Signal.MCP_PB_Zone_Select_AFT == TRUE){
        //Set to AFT
        ui->MCPICTtable->setItem(ROW3, COLUMN1, new QTableWidgetItem("AFT"));
    }
    else if(_MCP.Command.Signal.MCP_PB_Zone_Select_FWD == TRUE){
        //Set to FWD
        ui->MCPICTtable->setItem(ROW3, COLUMN1, new QTableWidgetItem("FWD"));
    }
    else{
        ui->MCPICTtable->setItem(ROW3, COLUMN1, new QTableWidgetItem("xxxxxx"));
    }


    //SIDE Select Indicator
    if((_MCP.Command.Signal.MCP_PB_Side_Select_Left == TRUE &&
         _MCP.Command.Signal.MCP_PB_Side_Select_Left_Fault  == TRUE) ||
        (_MCP.Command.Signal.MCP_PB_Side_Select_Right == TRUE &&
         _MCP.Command.Signal.MCP_PB_Side_Select_Right_Fault  == TRUE)){
        //Set to Invalid
        ui->MCPICTtable->setItem(ROW4, COLUMN1, new QTableWidgetItem("Invalid"));

    }
    else if(_MCP.Command.Signal.MCP_PB_Side_Select_Left == TRUE &&
            _MCP.Command.Signal.MCP_PB_Side_Select_Right == TRUE){
        //Set to Both
        ui->MCPICTtable->setItem(ROW4, COLUMN1, new QTableWidgetItem("BOTH"));
    }
    else if(_MCP.Command.Signal.MCP_PB_Side_Select_Right == TRUE){
        //Set to Right
        ui->MCPICTtable->setItem(ROW4, COLUMN1, new QTableWidgetItem("RIGHT"));
    }
    else if(_MCP.Command.Signal.MCP_PB_Side_Select_Left == TRUE ){
        //Set to Left
        ui->MCPICTtable->setItem(ROW4, COLUMN1, new QTableWidgetItem("LEFT"));
    }
    else{
        ui->MCPICTtable->setItem(ROW4, COLUMN1, new QTableWidgetItem("xxxxxx"));
    }

    //Joystick Indicator
    if(_MCP.Command.Signal.MCP_Joystick_Fault == TRUE){
        //Set to Invalid
        ui->MCPICTtable->setItem(ROW5, COLUMN1, new QTableWidgetItem("Invalid"));
    }
    else if(_MCP.Command.Signal.MCP_Joystick_AFT == TRUE){
        //Set to AFT
        ui->MCPICTtable->setItem(ROW5, COLUMN1, new QTableWidgetItem("AFT"));
    }
    else if(_MCP.Command.Signal.MCP_Joystick_FWD == TRUE){
        //Set to FWD
        ui->MCPICTtable->setItem(ROW5, COLUMN1, new QTableWidgetItem("FWD"));
    }
    else if(_MCP.Command.Signal.MCP_Joystick_IN == TRUE){
        //Set to IN
        ui->MCPICTtable->setItem(ROW5, COLUMN1, new QTableWidgetItem("IN"));
    }
    else if(_MCP.Command.Signal.MCP_Joystick_OUT == TRUE){
        //Set to OUT
        ui->MCPICTtable->setItem(ROW5, COLUMN1, new QTableWidgetItem("OUT"));
    }
    else if(_MCP.Command.Signal.MCP_Joystick_NEUTRAL == TRUE){
        //Set to NEUTRAL
        ui->MCPICTtable->setItem(ROW5, COLUMN1, new QTableWidgetItem("NEUTRAL"));
    }
    else{
        ui->MCPICTtable->setItem(ROW5, COLUMN1, new QTableWidgetItem("xxxxxx"));
    }


    //Spin Indicator
    if(_MCP.Command.Signal.MCP_PB_Spin_Fault == TRUE){
        //Set to Invlaid
        ui->MCPICTtable->setItem(ROW6, COLUMN1, new QTableWidgetItem("Invalid"));
    }
    else if(_MCP.Command.Signal.MCP_PB_Spin == TRUE){
        //Set to Enabled
        ui->MCPICTtable->setItem(ROW6, COLUMN1, new QTableWidgetItem("Enabled"));
    }
    else if(_MCP.Command.Signal.MCP_PB_Spin == FALSE){
        //Set to Disabled
        ui->MCPICTtable->setItem(ROW6, COLUMN1, new QTableWidgetItem("Disabled"));
    }
    else{
        ui->MCPICTtable->setItem(ROW6, COLUMN1, new QTableWidgetItem("xxxxxx"));
    }

    //20Ft Indicator
    if(_MCP.Command.Signal.MCP_PB_20FT_Fault == TRUE){
                //Set to Invlaid
        ui->MCPICTtable->setItem(ROW7, COLUMN1, new QTableWidgetItem("Invalid"));
    }
    else if(_MCP.Command.Signal.MCP_PB_20FT == TRUE){
        //Set to Enabled
        ui->MCPICTtable->setItem(ROW7, COLUMN1, new QTableWidgetItem("Enabled"));
    }
    else if(_MCP.Command.Signal.MCP_PB_20FT == FALSE){
        //Set to Disabled
        ui->MCPICTtable->setItem(ROW7, COLUMN1, new QTableWidgetItem("Disabled"));
    }
    else{
        ui->MCPICTtable->setItem(ROW7, COLUMN1, new QTableWidgetItem("xxxxxx"));
    }

    //Dual OPerator Indicator
    if(_MCP.Command.Signal.MCP_PB_Dual_Operator_Fault== TRUE){
                //Set to Invlaid
        ui->MCPICTtable->setItem(ROW8, COLUMN1, new QTableWidgetItem("Invalid"));
    }
    else if(_MCP.Command.Signal.MCP_PB_Dual_Operator == TRUE){
        //Set to Enabled
        ui->MCPICTtable->setItem(ROW8, COLUMN1, new QTableWidgetItem("Enabled"));
    }
    else if(_MCP.Command.Signal.MCP_PB_Dual_Operator == FALSE){
        //Set to Disabled
        ui->MCPICTtable->setItem(ROW8, COLUMN1, new QTableWidgetItem("Disabled"));
    }
    else{
        ui->MCPICTtable->setItem(ROW8, COLUMN1, new QTableWidgetItem("xxxxxx"));
    }
    //20FT IN OUT Indicator
    if(_MCP.Command.Signal.MCP_TGLS_20FT_Fault== TRUE){
                //Set to Invlaid
        ui->MCPICTtable->setItem(ROW9, COLUMN1, new QTableWidgetItem("Invalid"));
    }
    else if(_MCP.Command.Signal.MCP_TGLS_20FT_IN == TRUE){
        //Set to IN
        ui->MCPICTtable->setItem(ROW9, COLUMN1, new QTableWidgetItem("Enabled"));
    }
    else if(_MCP.Command.Signal.MCP_TGLS_20FT_OUT == TRUE){
        //Set to Out
        ui->MCPICTtable->setItem(ROW9, COLUMN1, new QTableWidgetItem("Disabled"));
    }
    else{
        ui->MCPICTtable->setItem(ROW9, COLUMN1, new QTableWidgetItem("xxxxxx"));
    }
    //LCP ACTIVE LH2_1 IndicatoDrive_Motor_Moder
    if(_MCP.Command.Signal.MCP_PB_LCP_LH2_1_Enable_Fault == TRUE){
                //Set to Invlaid
        ui->MCPICTtable->setItem(ROW11, COLUMN1, new QTableWidgetItem("Invalid"));
    }
    else if(_MCP.Command.Signal.MCP_PB_LCP_LH2_1_Enable == TRUE){
        //Set to Active
         ui->MCPICTtable->setItem(ROW11, COLUMN1, new QTableWidgetItem("Active"));
    }
    else if(_MCP.Command.Signal.MCP_PB_LCP_LH2_1_Enable == FALSE){
        //Set to Inactive
         ui->MCPICTtable->setItem(ROW11, COLUMN1, new QTableWidgetItem("Inactive"));
    }

    //LCP ACTIVE LH4_3 Indicator
    if(_MCP.Command.Signal.MCP_PB_LCP_LH4_3_Enable_Fault == TRUE){
                //Set to Invlaid
        ui->MCPICTtable->setItem(ROW12, COLUMN1, new QTableWidgetItem("Invalid"));
    }
    else if(_MCP.Command.Signal.MCP_PB_LCP_LH4_3_Enable == TRUE){
        //Set to Active
        ui->MCPICTtable->setItem(ROW12, COLUMN1, new QTableWidgetItem("Active"));
    }
    else if(_MCP.Command.Signal.MCP_PB_LCP_LH4_3_Enable == FALSE){
        //Set to Inactive
        ui->MCPICTtable->setItem(ROW12, COLUMN1, new QTableWidgetItem("Inactive"));
    }


    //LCP ACTIVE RH2_1 Indicator
    if(_MCP.Command.Signal.MCP_PB_LCP_RH2_1_Enable_Fault == TRUE){
                //Set to Invlaid
        ui->MCPICTtable->setItem(ROW13, COLUMN1, new QTableWidgetItem("Invalid"));
    }
    else if(_MCP.Command.Signal.MCP_PB_LCP_RH2_1_Enable == TRUE){
        //Set to Active
        ui->MCPICTtable->setItem(ROW13, COLUMN1, new QTableWidgetItem("Active"));
    }
    else if(_MCP.Command.Signal.MCP_PB_LCP_RH2_1_Enable == FALSE){
        //Set to Inactive
        ui->MCPICTtable->setItem(ROW13, COLUMN1, new QTableWidgetItem("Inactive"));
    }

    //LCP ACTIVE RH4_3 Indicator
    if(_MCP.Command.Signal.MCP_PB_LCP_RH4_3_Enable_Fault == TRUE){
                //Set to Invlaid
        ui->MCPICTtable->setItem(ROW14, COLUMN1, new QTableWidgetItem("Invalid"));
    }
    else if(_MCP.Command.Signal.MCP_PB_LCP_RH4_3_Enable == TRUE){
        //Set to Active
         ui->MCPICTtable->setItem(ROW14, COLUMN1, new QTableWidgetItem("Active"));
    }
    else if(_MCP.Command.Signal.MCP_PB_LCP_RH4_3_Enable == FALSE){
        //Set to Inactive
        ui->MCPICTtable->setItem(ROW14, COLUMN1, new QTableWidgetItem("Inactive"));
    }

     timerIsr->setInterval(ONE_SEC);

}

/*-----------------------------------------------------------------------------
 *  Description : Implementation of continous indicators update on the DSS screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void DetailedSystemStatusW::UpdateUI()
{
    uint8_t Pos;

    // Update Panel Statu
    if(CurrPage == DSS){
        qDebug() << "updating DSS Page";

        if(_MCP.Status.Signal.PB_On_Off_LED == DISABLED){
            //SET MCP To GREY
            MCPIndicator->setPixmap(MCP_GREY_PIX);

        }
        else if(_MCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _MCP.Status.Signal.LED_System_Active == TRUE &&
                _MCP.Command.Signal.MCP_Panel_Status == CP_STATE::OP){// &&
                //_MCP.Command.Signal.MCP_Switch_Fault_Status == FALSE){
            //Set Green HAT + Green ICON
            MCPIndicator->setPixmap(MCP_GREEN_PIX);
        }

        else if(_MCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _MCP.Status.Signal.LED_System_Active == TRUE &&
                _MCP.Command.Signal.MCP_Panel_Status == CP_STATE::FAIL){// &&
                //_MCP.Command.Signal.MCP_Switch_Fault_Status == FALSE){
            //Set AMber HAT + Amber ICON
            MCPIndicator->setPixmap(MCP_AMBER_PIX);
        }

        else if(_MCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _MCP.Status.Signal.LED_System_Active == TRUE &&
                _MCP.Command.Signal.MCP_Panel_Status == CP_STATE::OP &&
                //_MCP.Command.Signal.MCP_Switch_Fault_Status == FALSE &&
                _MCP.Command.Signal.MCP_PB_PDU_Stop == TRUE){
            //Set Red HAT + Green ICON
            MCPIndicator->setPixmap(MCP_RDGN_PIX);
        }

        else if(_MCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _MCP.Status.Signal.LED_System_Active == TRUE &&
                _MCP.Command.Signal.MCP_Panel_Status == CP_STATE::FAIL &&
                //_MCP.Command.Signal.MCP_Switch_Fault_Status == TRUE &&
                _MCP.Command.Signal.MCP_PB_PDU_Stop == TRUE){
            //Set Red HAT + AMBER ICON
            MCPIndicator->setPixmap(MCP_RDAM_PIX);
        }

        if(_ICP.Status.Signal.PB_On_Off_LED == DISABLED){
            //SET ICP To GREY
            ICPIndicator->setPixmap(ICP_GREY_PIX);
        }
        else if(_ICP.Status.Signal.PB_On_Off_LED == TRUE &&
                _ICP.Status.Signal.LED_System_Active == TRUE &&
                _ICP.Command.Signal.ICP_Panel_Status == CP_STATE::OP &&
                _ICP.Command.Signal.ICP_Switch_Fault_Status == FALSE){
            //Set Green HAT + Green ICON
            ICPIndicator->setPixmap(ICP_GREEN_PIX);
        }

        else if(_ICP.Status.Signal.PB_On_Off_LED == TRUE &&
                _ICP.Status.Signal.LED_System_Active == TRUE &&
                _ICP.Command.Signal.ICP_Panel_Status == CP_STATE::FAIL &&
                _ICP.Command.Signal.ICP_Switch_Fault_Status == TRUE){
            //Set AMber HAT + Amber ICON
            ICPIndicator->setPixmap(ICP_AMBER_PIX);
        }

        else if(_ICP.Status.Signal.PB_On_Off_LED == TRUE &&
                _ICP.Status.Signal.LED_System_Active == TRUE &&
                _ICP.Command.Signal.ICP_Panel_Status == CP_STATE::OP &&
                _ICP.Command.Signal.ICP_Switch_Fault_Status == FALSE &&
                _ICP.Command.Signal.ICP_PB_PDU_Stop == TRUE){
            //Set Red HAT + Green ICON
            ICPIndicator->setPixmap(ICP_RDGN_PIX);
        }

        else if(_ICP.Status.Signal.PB_On_Off_LED == TRUE &&
                _ICP.Status.Signal.LED_System_Active == TRUE &&
                _ICP.Command.Signal.ICP_Panel_Status == CP_STATE::FAIL &&
                _ICP.Command.Signal.ICP_Switch_Fault_Status == TRUE &&
                _ICP.Command.Signal.ICP_PB_PDU_Stop == TRUE){
            //Set Red HAT + AMBER ICON
            ICPIndicator->setPixmap(ICP_RDAM_PIX);
        }

        if(_OCP.Status.Signal.PB_On_Off_LED == DISABLED){
            //SET OCP To GREY
            OCPIndicator->setPixmap(OCP_GREY_PIX);
        }
        else if(_OCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _OCP.Status.Signal.LED_System_Active == TRUE &&
                _OCP.Command.Signal.OCP_Panel_Status == CP_STATE::OP){// &&
                //_OCP.Command.Signal.OCP_Switch_Fault_Status == FALSE){
            //Set Green HAT + Green ICON
            OCPIndicator->setPixmap(OCP_GREEN_PIX);
        }

        else if(_OCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _OCP.Status.Signal.LED_System_Active == TRUE &&
                _OCP.Command.Signal.OCP_Panel_Status == CP_STATE::FAIL){// &&
            //_OCP.Command.Signal.OCP_Switch_Fault_Status == FALSE){
            //Set AMber HAT + Amber ICON
            OCPIndicator->setPixmap(OCP_AMBER_PIX);
        }

        else if(_OCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _OCP.Status.Signal.LED_System_Active == TRUE &&
                _OCP.Command.Signal.OCP_Panel_Status == CP_STATE::OP &&
                //_OCP.Command.Signal.OCP_Switch_Fault_Status == FALSE &&
                _OCP.Command.Signal.OCP_PB_PDU_Stop == TRUE){
            //Set Red HAT + Green ICON
            OCPIndicator->setPixmap(OCP_RDGN_PIX);
        }

        else if(_OCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _OCP.Status.Signal.LED_System_Active == TRUE &&
                _OCP.Command.Signal.OCP_Panel_Status == CP_STATE::FAIL &&
                //_OCP.Command.Signal.OCP_Switch_Fault_Status == TRUE &&
                _OCP.Command.Signal.OCP_PB_PDU_Stop == TRUE){
            //Set Red HAT + AMBER ICON
            OCPIndicator->setPixmap(OCP_RDAM_PIX);
        }

        for( Pos=LCP1LH ; Pos < 8 ; Pos++){
            if(_LCP[Pos].Status.Signal.LCP_LED_Panel_Enabled == FALSE &&
                    (_LCP[Pos].Command.Signal.LCP_Panel_Status != CP_STATE::OP ||
                     _LCP[Pos].Command.Signal.LCP_Panel_Status != CP_STATE::FAIL)){
                //SET LCP To GREY
                LCPIndicator[Pos]->setPixmap(LCP_GREY_PIX(Pos));
            }
            else if(_LCP[Pos].Status.Signal.LCP_LED_Panel_Enabled == TRUE &&
                    (_LCP[Pos].Command.Signal.LCP_Switch_Fault_Status == FALSE &&
                     _LCP[Pos].Command.Signal.LCP_Panel_Status == CP_STATE::OP)){
                //Set Green HAT + Green ICON
                LCPIndicator[Pos]->setPixmap(LCP_GREEN_PIX(Pos));
            }
            else if(_LCP[Pos].Status.Signal.LCP_LED_Panel_Enabled == TRUE &&
                    (_LCP[Pos].Command.Signal.LCP_Switch_Fault_Status == TRUE &&
                     _LCP[Pos].Command.Signal.LCP_Panel_Status == CP_STATE::FAIL)){
                //Set Amber HAT + Amber ICON
                LCPIndicator[Pos]->setPixmap(LCP_AMBER_PIX(Pos));
            }

            else if(_LCP[Pos].Status.Signal.LCP_LED_Panel_Enabled == TRUE &&
                    (_LCP[Pos].Command.Signal.LCP_Switch_Fault_Status == FALSE &&
                     _LCP[Pos].Command.Signal.LCP_Panel_Status == CP_STATE::OP) &&
                    _LCP[Pos].Command.Signal.LCP_PB_PDU_Stop == TRUE){
                //Set Red HAT + Green ICON
                LCPIndicator[Pos]->setPixmap(LCP_RDGN_PIX(Pos));
            }

            else if(_LCP[Pos].Status.Signal.LCP_LED_Panel_Enabled == TRUE &&
                    (_LCP[Pos].Command.Signal.LCP_Switch_Fault_Status == TRUE ||
                     _LCP[Pos].Command.Signal.LCP_Panel_Status == CP_STATE::FAIL) &&
                    _LCP[Pos].Command.Signal.LCP_PB_PDU_Stop == TRUE){
                //Set Red HAT + Amber ICON
                LCPIndicator[Pos]->setPixmap(LCP_RDAM_PIX(Pos));
            }
        }

        //Update the PDU Status
        bool Blink = FALSE;
        for(Pos = 0; Pos < 100 ; Pos++){
            //Set Blink State
            if(Blink){
                Blink = FALSE;
            }
            else {
                Blink = TRUE;
            }

            if(_PDU[Pos].StatusMSG1.Signal.PDU_Mode == PDU_MODE::OFF_MODE){
                // Grey Rectangle
                PDUIndication[Pos]->setPixmap(PDU_GREY_PIX);

            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::HOLD_ACTIVE){
                // white rectangle
                PDUIndication[Pos]->setPixmap(PDU_WHITE_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE){
                // Green rectangle
                PDUIndication[Pos]->setPixmap(PDU_GREEN_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE &&
                    _PDU[Pos].StatusMSG1.Signal.Active_Drive_Command_Direction == PDU_DRIVE_COMMAND_DIR::DIR_A){
                // Green Right Triangle Blink
                if(Blink)
                    PDUIndication[Pos]->setPixmap(PDU_GRNFW_PIX);
                else
                    PDUIndication[Pos]->setPixmap(PDU_GREY_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE &&
                    _PDU[Pos].StatusMSG1.Signal.Active_Drive_Command_Direction == PDU_DRIVE_COMMAND_DIR::DIR_B){
                // GReenLEFT Triangle Blink
                if(Blink)
                    PDUIndication[Pos]->setPixmap(PDU_GRNAF_PIX);
                else
                    PDUIndication[Pos]->setPixmap(PDU_GREY_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::NOT_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::HOLD_ACTIVE){
                // WHite and amber rectangle
                    PDUIndication[Pos]->setPixmap(PDU_WHAMB_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE){
                // amber rectangle
                PDUIndication[Pos]->setPixmap(PDU_AMBER_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE &&
                    _PDU[Pos].StatusMSG1.Signal.Active_Drive_Command_Direction == PDU_DRIVE_COMMAND_DIR::DIR_A){
                // Amber Right Triangle Blink
                if(Blink)
                    PDUIndication[Pos]->setPixmap(PDU_AMBFW_PIX);
                else
                    PDUIndication[Pos]->setPixmap(PDU_GREY_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE &&
                    _PDU[Pos].StatusMSG1.Signal.Active_Drive_Command_Direction == PDU_DRIVE_COMMAND_DIR::DIR_B){
                // Amber LEFT Triangle Blink
                if(Blink)
                    PDUIndication[Pos]->setPixmap(PDU_AMBAF_PIX);
                else
                    PDUIndication[Pos]->setPixmap(PDU_GREY_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_State == PDU_STATE::ST_FAULTY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::HOLD_ACTIVE){
                // WHite and Red rectangle
                PDUIndication[Pos]->setPixmap(PDU_WHRED_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_State == PDU_STATE::ST_FAULTY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE){
                // Red rectangle
                PDUIndication[Pos]->setPixmap(PDU_RED_PIX);
            }
        }
    }
    timer->setInterval(ONE_SEC);

}


/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to SW Maintenance screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void DetailedSystemStatusW::HandleBackButton(){
    PrevPage = DSS;
    CurrPage = MAINT;
    hide();
}

DetailedSystemStatusW::~DetailedSystemStatusW()
{
    delete ui;
}
