
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : swmaintenancew.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef SWMAINTENANCEW_H
#define SWMAINTENANCEW_H

#include <QDialog>
#include <QPushButton>
#include "contmonsectionoverview.h"
#include "detailedsystemstatusw.h"
#include "uldstatuspage.h"
#include "swversionw.h"
#include "commondata.h"

/********************* PREPROCESSOR DIRECTIVES  *****************************/
#define SWM_BK_BTN_WT       300
#define SWM_BK_BTN_HT       300
#define SWM_BK_BTN_X        80
#define SWM_BK_BTN_Y        50

#define SWM_CM_BTN_WT       330
#define SWM_CM_BTN_HT       330
#define SWM_CM_BTN_X        440
#define SWM_CM_BTN_Y        400

#define SWM_DS_BTN_WT       330
#define SWM_DS_BTN_HT       330
#define SWM_DS_BTN_X        80
#define SWM_DS_BTN_Y        400


#define ULD_ST_BTN_WT       330
#define ULD_ST_BTN_HT       330
#define ULD_ST_BTN_X        790
#define ULD_ST_BTN_Y        400

namespace Ui {
class SWMaintenanceW;
}

class SWMaintenanceW : public QDialog
{
    Q_OBJECT

public:
    explicit SWMaintenanceW(QWidget *parent = 0);
    ~SWMaintenanceW();

private slots:
    void HandleContMonButton();
    void HandleDetailedStatButton();
    void HandleULDStatusButton();
    void HandleBackButton();

private:
    Ui::SWMaintenanceW      *ui;
    ContMonSectionOverview  *ContMonitoringScreen;
    DetailedSystemStatusW   *DetailedStatusScreen;
    ULDStatusPage           *ULDStatusScreen;
    SWVersionW              *SWVersionScreen;
    QPushButton             *ContMonButton;
    QPushButton             *DetailedStatButton;
    QPushButton             *BackButton;
    QPushButton             *ULDStatusButton;
};

#endif // SWMAINTENANCEW_H
