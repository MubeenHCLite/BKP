/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : mcptstatuspage.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : The CDP OPSW to manage all fields in the MCP status display
 *                Provides tabular information on the status of the CP Signals
 *
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "mcpstatuspage.h"
#include "ui_mcpstatuspage.h"
#include "common.h"


/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the MCP Status application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
MCPStatusPage::MCPStatusPage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MCPStatusPage)
{
    ui->setupUi(this);

    BackButton = new QPushButton("", this);
    BackButton->setGeometry(QRect(QPoint(MCP_BK_BTN_X, MCP_BK_BTN_Y), QSize(MCP_BK_BTN_WT, MCP_BK_BTN_HT)));
    QPixmap BackButtonBkg(BaseFolder + "BackButton.png");
    QIcon BackButtonIcon(BackButtonBkg.scaled(MCP_BK_BTN_WT, MCP_BK_BTN_HT,Qt::KeepAspectRatio));
    BackButton->setIcon(BackButtonIcon);
    BackButton->setIconSize(BackButtonBkg.rect().size());
    connect(BackButton, &QPushButton::released, this, &MCPStatusPage::HandleBackButton);


    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(UpdateUI()));
    timer->setInterval(ONE_MS);
    timer->start();

}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Cont Monitoring screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void MCPStatusPage::HandleBackButton(){
    CurrPage = PrevPage;
    PrevPage = MCP_STATUS;
    hide();
}

/*-----------------------------------------------------------------------------
 *  Description : Implementation of continous indicators update on the screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void MCPStatusPage::UpdateUI()
{
    ui->MCPTable1->setItem(ROW0, COLUMN1, new QTableWidgetItem(CPName));
    if(CurrPage == MCP_STATUS){
        //ON/OFF Indicator
        if(_MCP.Command.Signal.MCP_PB_Power_On_Off == TRUE){
            //Set to Invalid
            ui->MCPTable1->setItem(ROW1, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_MCP.Status.Signal.PB_On_Off_LED == TRUE){
            //Set to ON
            ui->MCPTable1->setItem(ROW1, COLUMN1, new QTableWidgetItem("ON"));
        }
        else if(_MCP.Status.Signal.PB_On_Off_LED == FALSE){
            //Set to OFF
            ui->MCPTable1->setItem(ROW1, COLUMN1, new QTableWidgetItem("OFF"));
        }
        else{
            ui->MCPTable1->setItem(ROW1, COLUMN1, new QTableWidgetItem("xxxxxx"));
        }


        //Joystick Indicator
        if(_MCP.Command.Signal.MCP_Joystick_Fault == TRUE){
            //Set to Invalid
            ui->MCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_MCP.Command.Signal.MCP_Joystick_AFT == TRUE){
            //Set to AFT
            ui->MCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("AFT"));
        }
        else if(_MCP.Command.Signal.MCP_Joystick_FWD == TRUE){
            //Set to FWD
            ui->MCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("FWD"));
        }
        else if(_MCP.Command.Signal.MCP_Joystick_IN == TRUE){
            //Set to IN
            ui->MCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("IN"));
        }
        else if(_MCP.Command.Signal.MCP_Joystick_OUT == TRUE){
            //Set to OUT
            ui->MCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("OUT"));
        }
        else if(_MCP.Command.Signal.MCP_Joystick_NEUTRAL == TRUE){
            //Set to NEUTRAL
            ui->MCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("NEUTRAL"));
        }
        else{
            ui->MCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("xxxxxx"));
        }

        //Zone Indicator
        if((_MCP.Command.Signal.MCP_PB_Zone_Select_AFT == TRUE &&
             _MCP.Command.Signal.MCP_PB_Zone_Select_AFT_Fault == TRUE) ||
            (_MCP.Command.Signal.MCP_PB_Zone_Select_FWD== TRUE &&
             _MCP.Command.Signal.MCP_PB_Zone_Select_FWD_Fault == TRUE) ||
            (_MCP.Command.Signal.MCP_PB_Zone_Select_AFT == TRUE &&
             _MCP.Command.Signal.MCP_PB_Zone_Select_FWD== TRUE )){
                //Set to Invalid
            ui->MCPTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        if(_MCP.Command.Signal.MCP_PB_Zone_Select_AFT == TRUE){
            //Set to AFT
            ui->MCPTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("AFT"));
        }
        else if(_MCP.Command.Signal.MCP_PB_Zone_Select_FWD == TRUE){
            //Set to FWD
            ui->MCPTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("FWD"));
        }
        else{
            ui->MCPTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("xxxxxx"));
        }

        //PDU STOP indicator
/*        if(_MCP.Command.Signal.MCP_PB_PDU_Stop_Fault == TRUE){
            //Set to Invlaid
            ui->MCPTable1->setItem(ROW10, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_MCP.Command.Signal.MCP_PB_PDU_Stop == TRUE){
            //Set to ON
            ui->MCPTable1->setItem(ROW10, COLUMN1, new QTableWidgetItem("ON"));
        }
        else if(_MCP.Command.Signal.MCP_PB_PDU_Stop == FALSE){
            //Set to OFF
            ui->MCPTable1->setItem(ROW10, COLUMN1, new QTableWidgetItem("OFF"));
        }
        else{
            ui->MCPTable1->setItem(ROW10, COLUMN1, new QTableWidgetItem("xxxxxx"));
        }


        //System Active Indicator
        if(_MCP.Command.Signal.MCP_LED_System_Active_Fault == TRUE){
            //Set to Invalid
            ui->MCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_MCP.Status.Signal.LED_System_Active == TRUE){
            //Set to ON
            ui->MCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Active"));
        }
        else if(_MCP.Status.Signal.LED_System_Active == FALSE){
            //Set to OFF
            ui->MCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Inactive"));
        }
        else{
            ui->MCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("xxxxxx"));
        }
*/

        //Spin Indicator
        if(_MCP.Command.Signal.MCP_PB_Spin_Fault == TRUE){
            //Set to Invlaid
            ui->MCPTable1->setItem(ROW6, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_MCP.Command.Signal.MCP_PB_Spin == TRUE){
            //Set to Enabled
            ui->MCPTable1->setItem(ROW6, COLUMN1, new QTableWidgetItem("Enabled"));
        }
        else if(_MCP.Command.Signal.MCP_PB_Spin == FALSE){
            //Set to Disabled
            ui->MCPTable1->setItem(ROW6, COLUMN1, new QTableWidgetItem("Disabled"));
        }
        else{
            ui->MCPTable1->setItem(ROW6, COLUMN1, new QTableWidgetItem("xxxxxx"));
        }


        //SIDE Select Indicator
        if((_MCP.Command.Signal.MCP_PB_Side_Select_Left == TRUE &&
             _MCP.Command.Signal.MCP_PB_Side_Select_Left_Fault  == TRUE) ||
            (_MCP.Command.Signal.MCP_PB_Side_Select_Right == TRUE &&
             _MCP.Command.Signal.MCP_PB_Side_Select_Right_Fault  == TRUE)){
            //Set to Invalid
            ui->MCPTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("Invalid"));

        }
        else if(_MCP.Command.Signal.MCP_PB_Side_Select_Left == TRUE &&
                _MCP.Command.Signal.MCP_PB_Side_Select_Right == TRUE){
            //Set to Both
            ui->MCPTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("BOTH"));
        }
        else if(_MCP.Command.Signal.MCP_PB_Side_Select_Right == TRUE){
            //Set to Right
            ui->MCPTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("RIGHT"));
        }
        else if(_MCP.Command.Signal.MCP_PB_Side_Select_Left == TRUE ){
            //Set to Left
            ui->MCPTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("LEFT"));
        }
        else{
            ui->MCPTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("xxxxxx"));
        }

        //20Ft Indicator
        if(_MCP.Command.Signal.MCP_PB_20FT_Fault == TRUE){
                    //Set to Invlaid
            ui->MCPTable1->setItem(ROW7, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_MCP.Command.Signal.MCP_PB_20FT == TRUE){
            //Set to Enabled
            ui->MCPTable1->setItem(ROW7, COLUMN1, new QTableWidgetItem("Enabled"));
        }
        else if(_MCP.Command.Signal.MCP_PB_20FT == FALSE){
            //Set to Disabled
            ui->MCPTable1->setItem(ROW7, COLUMN1, new QTableWidgetItem("Disabled"));
        }
        else{
            ui->MCPTable1->setItem(ROW7, COLUMN1, new QTableWidgetItem("xxxxxx"));
        }

        //Dual OPerator Indicator
        if(_MCP.Command.Signal.MCP_PB_Dual_Operator_Fault== TRUE){
                    //Set to Invlaid
            ui->MCPTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_MCP.Command.Signal.MCP_PB_Dual_Operator == TRUE){
            //Set to Enabled
            ui->MCPTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("Enabled"));
        }
        else if(_MCP.Command.Signal.MCP_PB_Dual_Operator == FALSE){
            //Set to Disabled
            ui->MCPTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("Disabled"));
        }
        else{
            ui->MCPTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("xxxxxx"));
        }

        //20FT IN OUT Indicator
        if(_MCP.Command.Signal.MCP_TGLS_20FT_Fault== TRUE){
                    //Set to Invlaid
            ui->MCPTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_MCP.Command.Signal.MCP_TGLS_20FT_IN == TRUE){
            //Set to IN
            ui->MCPTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("Enabled"));
        }
        else if(_MCP.Command.Signal.MCP_TGLS_20FT_OUT == TRUE){
            //Set to Out
            ui->MCPTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("Disabled"));
        }
        else{
            ui->MCPTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("xxxxxx"));
        }

        //LCP ACTIVE LH2_1 IndicatoDrive_Motor_Moder
        if(_MCP.Command.Signal.MCP_PB_LCP_LH2_1_Enable_Fault == TRUE){
                    //Set to Invlaid
            ui->MCPTable1->setItem(ROW11, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_MCP.Command.Signal.MCP_PB_LCP_LH2_1_Enable == TRUE){
            //Set to Active
             ui->MCPTable1->setItem(ROW11, COLUMN1, new QTableWidgetItem("Active"));
        }
        else if(_MCP.Command.Signal.MCP_PB_LCP_LH2_1_Enable == FALSE){
            //Set to Inactive
             ui->MCPTable1->setItem(ROW11, COLUMN1, new QTableWidgetItem("Inactive"));
        }

        //LCP ACTIVE LH4_3 Indicator
        if(_MCP.Command.Signal.MCP_PB_LCP_LH4_3_Enable_Fault == TRUE){
                    //Set to Invlaid
            ui->MCPTable1->setItem(ROW12, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_MCP.Command.Signal.MCP_PB_LCP_LH4_3_Enable == TRUE){
            //Set to Active
            ui->MCPTable1->setItem(ROW12, COLUMN1, new QTableWidgetItem("Active"));
        }
        else if(_MCP.Command.Signal.MCP_PB_LCP_LH4_3_Enable == FALSE){
            //Set to Inactive
            ui->MCPTable1->setItem(ROW12, COLUMN1, new QTableWidgetItem("Inactive"));
        }

        //LCP ACTIVE RH2_1 Indicator
        if(_MCP.Command.Signal.MCP_PB_LCP_RH2_1_Enable_Fault == TRUE){
                    //Set to Invlaid
            ui->MCPTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_MCP.Command.Signal.MCP_PB_LCP_RH2_1_Enable == TRUE){
            //Set to Active
            ui->MCPTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("Active"));
        }
        else if(_MCP.Command.Signal.MCP_PB_LCP_RH2_1_Enable == FALSE){
            //Set to Inactive
            ui->MCPTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("Inactive"));
        }

        //LCP ACTIVE RH4_3 Indicator
        if(_MCP.Command.Signal.MCP_PB_LCP_RH4_3_Enable_Fault == TRUE){
                    //Set to Invlaid
            ui->MCPTable1->setItem(ROW14, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_MCP.Command.Signal.MCP_PB_LCP_RH4_3_Enable == TRUE){
            //Set to Active
             ui->MCPTable1->setItem(ROW14, COLUMN1, new QTableWidgetItem("Active"));
        }
        else if(_MCP.Command.Signal.MCP_PB_LCP_RH4_3_Enable == FALSE){
            //Set to Inactive
            ui->MCPTable1->setItem(ROW14, COLUMN1, new QTableWidgetItem("Inactive"));
        }

        ui->MCPTable1->setItem(ROW16, COLUMN1, new QTableWidgetItem(QString::number(_MCP.Command.Signal.MCP_Mux_Current_Voltage)));
        ui->MCPTable1->setItem(ROW16, COLUMN1, new QTableWidgetItem(QString::number(_MCP.Command.Signal.MCP_Measured_Current_Voltage)));

        //MCP Switch Fault
/*        if(_MCP.Command.Signal.MCP_Switch_Fault_Status == TRUE){
            ui->MCPTable2->setItem(ROW0, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW0, COLUMN1, new QTableWidgetItem("False"));
        }

*/
        //Power On off Fault
        if(_MCP.Command.Signal.MCP_PB_Power_On_Off_Fault == TRUE){
            ui->MCPTable2->setItem(ROW1, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW1, COLUMN1, new QTableWidgetItem("False"));
        }
/*
        //PDU Stop Fault
        if(_MCP.Command.Signal.MCP_PB_PDU_Stop_Fault == TRUE){
            ui->MCPTable2->setItem(ROW2, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW2, COLUMN1, new QTableWidgetItem("False"));
        }
*/
        //Side Select Left
        if(_MCP.Command.Signal.MCP_PB_Side_Select_Left_Fault == TRUE){
            ui->MCPTable2->setItem(ROW3, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW3, COLUMN1, new QTableWidgetItem("False"));
        }

        //Side Select Right
        if(_MCP.Command.Signal.MCP_PB_Side_Select_Right_Fault == TRUE){
            ui->MCPTable2->setItem(ROW4, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW4, COLUMN1, new QTableWidgetItem("False"));
        }

        //Zone Select AFT
        if(_MCP.Command.Signal.MCP_PB_Zone_Select_AFT_Fault == TRUE){
            ui->MCPTable2->setItem(ROW5, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW5, COLUMN1, new QTableWidgetItem("False"));
        }

        //Zone Select FWD
        if(_MCP.Command.Signal.MCP_PB_Zone_Select_FWD_Fault == TRUE){
            ui->MCPTable2->setItem(ROW6, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW6, COLUMN1, new QTableWidgetItem("False"));
        }

        //LCP LH21
        if(_MCP.Command.Signal.MCP_PB_LCP_LH2_1_Enable_Fault == TRUE){
            ui->MCPTable2->setItem(ROW7, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW7, COLUMN1, new QTableWidgetItem("False"));
        }

        //LCP LH43
        if(_MCP.Command.Signal.MCP_PB_LCP_LH4_3_Enable_Fault == TRUE){
            ui->MCPTable2->setItem(ROW8, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW8, COLUMN1, new QTableWidgetItem("False"));
        }

        //LCP RH21
        if(_MCP.Command.Signal.MCP_PB_LCP_RH2_1_Enable_Fault == TRUE){
            ui->MCPTable2->setItem(ROW9, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW9, COLUMN1, new QTableWidgetItem("False"));
        }

        //LCP RH43
        if(_MCP.Command.Signal.MCP_PB_LCP_RH4_3_Enable_Fault == TRUE){
            ui->MCPTable2->setItem(ROW10, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW10, COLUMN1, new QTableWidgetItem("False"));
        }

        //Dual Operator
        if(_MCP.Command.Signal.MCP_PB_Dual_Operator_Fault == TRUE){
            ui->MCPTable2->setItem(ROW11, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW11, COLUMN1, new QTableWidgetItem("False"));
        }

        //20FT
        if(_MCP.Command.Signal.MCP_PB_20FT_Fault == TRUE){
            ui->MCPTable2->setItem(ROW12, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW12, COLUMN1, new QTableWidgetItem("False"));
        }

        //Spin
        if(_MCP.Command.Signal.MCP_PB_Spin_Fault == TRUE){
            ui->MCPTable2->setItem(ROW13, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW13, COLUMN1, new QTableWidgetItem("False"));
        }

        //Lamp Test
        if(_MCP.Command.Signal.MCP_PB_Lamp_Test_Fault == TRUE){
            ui->MCPTable2->setItem(ROW14, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW14, COLUMN1, new QTableWidgetItem("False"));
        }

        // Joystick
        if(_MCP.Command.Signal.MCP_Joystick_Fault == TRUE){
            ui->MCPTable2->setItem(ROW15, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW15, COLUMN1, new QTableWidgetItem("False"));
        }

        //Toggle Switch - 20FT
        if(_MCP.Command.Signal.MCP_TGLS_20FT_Fault == TRUE){
            ui->MCPTable2->setItem(ROW16, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW16, COLUMN1, new QTableWidgetItem("False"));
        }

        //LED System Active
/*        if(_MCP.Command.Signal.MCP_LED_System_Active_Fault == TRUE){
            ui->MCPTable2->setItem(ROW17, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->MCPTable2->setItem(ROW17, COLUMN1, new QTableWidgetItem("False"));
        }
*/
    }

    timer->setInterval(ONE_SEC);

}

MCPStatusPage::~MCPStatusPage()
{
    delete ui;
}
