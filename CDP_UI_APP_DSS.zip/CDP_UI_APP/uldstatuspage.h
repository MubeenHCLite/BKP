#ifndef ULDSTATUSPAGE_H
#define ULDSTATUSPAGE_H

#include <QDialog>
#include <QPixmap>
#include <QPushButton>
#include <QTimer>
#include "commondata.h"
#include "iconmap.h"

#define ULD_BK_BTN_WT       80
#define ULD_BK_BTN_HT       80
#define ULD_BK_BTN_X        20
#define ULD_BK_BTN_Y        20


namespace Ui {
class ULDStatusPage;
}

class ULDStatusPage : public QDialog
{
    Q_OBJECT

public:
    explicit ULDStatusPage(QWidget *parent = 0);
    ~ULDStatusPage();

private slots:
    void UpdateUI();
    void HandleBackButton();

private:
    Ui::ULDStatusPage *ui;
    QTimer *timer;
    QPushButton             *BackButton;
};

#endif // ULDSTATUSPAGE_H
