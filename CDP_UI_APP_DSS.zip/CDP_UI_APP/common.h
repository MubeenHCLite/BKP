/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : common.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef COMMON_H
#define COMMON_H

/****************************** HEADER FILES *********************************/
#include <QString>
#include <QTimer>
#include "commondata.h"

/********************* PREPROCESSOR DIRECTIVES  *****************************/
//FUNCTION ID MAPPING

#define		FID_CARGO_ZONE              36
#define		FID_PANEL_STATUS			24
#define		FID_PANEL_CMD				4
#define		FID_STATUS_MSG_1            8
#define		FID_STATUS_MSG_2            9
#define		FID_STATUS_MSG_3            10
#define     FID_PREPARE_CMD             12
#define     FID_MOVE_CMD                16
#define     FID_RETRACT_CMD             20
#define     FID_READOUT_CMD             51
#define     FID_READOUT_RESPONSE        52

#define     NID_MCP                     60
#define     NID_OCP                     61
#define     NID_ICP                     188

#define     NID_LCP1LH                  62
#define     NID_LCP2LH                  63
#define     NID_LCP3LH                  64
#define     NID_LCP4LH                  65

#define     NID_LCP1RH                  189
#define     NID_LCP2RH                  190
#define     NID_LCP3RH                  191
#define     NID_LCP4RH                  192

#define     PDU_POS_START                   1700
#define     PDUT_POS_START                  650

#define     SET                         0x01
#define     UNSET                       0x00
#define     ENABLED                     0x01
#define     DISABLED                    0x00
#define     HEALTHY                     0x00
#define     FAULTY                      0x01
#define     TRUE                        0x01
#define     FALSE                       0x00

#define     PDUL_MAX_COUNT           59
#define     PDUR_MAX_COUNT           57
#define     PDUR_COUNT_START          70
#define     PDU_MAX_COUNT            116

#define     ROW0            0
#define     ROW1            1
#define     ROW2            2
#define     ROW3            3
#define     ROW4            4
#define     ROW5            5
#define     ROW6            6
#define     ROW7            7
#define     ROW8            8
#define     ROW9            9
#define     ROW10           10
#define     ROW11           11
#define     ROW12           12
#define     ROW13           13
#define     ROW14           14
#define     ROW15           15
#define     ROW16           16
#define     ROW17           17
#define     ROW18           18
#define     ROW19           19
#define     ROW20           20

#define     COLUMN1         1
#define     COLUMN2         2
#define     COLUMN3         3
#define     COLUMN4         4


#define     ONE_SEC         1000
#define     ONE_MS          1

/********************* ENUMS  *****************************/
enum class CP_STATE {DEFAULT = 0x00,
                    OFF,
                    INIT,
                    DL,
                    OP,
                    FAIL};

enum LCP_NUM {LCP1LH = 0, LCP2LH, LCP3LH, LCP4LH,
             LCP1RH, LCP2RH, LCP3RH, LCP4RH};

//enum LCP20FT_NUM {LCP4LH = 7, LCP4RH};


enum class MUX_CUR_VOL    {DEFAULT = 0, CURRENT, VOLTAGE};
enum class CMD_ID_CODE    {MOVE_EN = 0x11,
                    MOVE_DIS = 0x22,
                    RETRACT_EN = 0x33,
                    MOVE_START = 0x44,
                    RETRACT_DIS = 0x66,
                    MOVE_STOP = 0x88,
                    RETRACT_START = 0xCC,
                    RETRACT_STOP = 0x99};

enum class DIRECTION_VELOCITY {FWD = 0x05,
                        AFT = 0x0A,
                        FULL_SPEED = 0x01,
                        SPEED = 0x02,
                        HALF_SPEED = 0x04,
                        LOW_SPEED = 0x08,
                        UNUSED = 0x00};

enum class EXPIRY_TIME {MS_50 = 0x01,
                 MS_100 = 0x02,
                 FOREVER = 0x00,
                 UNUSED = 0x00};

enum class PDU_TYPE {DEFAULT = 0,
                     SPRING_LOADED = 1,
                     SELF_LIFT = 3};
enum class PDU_HEALTH_STATUS {DEFAULT = 0,
                             OVERALL_HEALTHY = 1,
                             NOT_HEALTHY = 3};


enum class PDU_COVER_STATUS {DEFAULT = 0,
                             NOT_COVERED = 1,
                             COVERED = 3};

enum class PDU_ROLLER_POSITION {DEFAULT = 0,
                             HOME = 1,
                             PARTITAL_LIFT = 2,
                             FULLY_LIFT = 3};

enum class PDU_MODE {OFF_MODE = 0,
                     INIT_MODE = 1,
                     OP_MODE = 2,
                    DL_MODE = 3,
                    BIT_MODE = 4};

enum class PDU_STATE {POWERUP = 1,
                     STANDBY = 2,
                     LIFT_HOLD = 3,
                    LIFT_DRIVE = 4,
                    LIFT_BRAKE = 5,
                     RETRACT_HOLD = 6,
                     ST_FAULTY = 7,
                     REGENERATIVE = 8};

enum class PDU_HOLD_STATUS {HOLD_ACTIVE = 0,
                           RELEASE_ACTIVE};

enum class PDU_DRIVE_COMMAND_DIR {DEFAULT = 0,
                                 DIR_A,
                                 DIR_B};

enum class DRIVE_MOTOR_MODE {DMM_STANDBY =0,
                                  DMM_MOTOR,
                                 DMM_HOLD};


enum class LIFT_MOTOR_MODE {LMM_IDLE = 1,
                           LMM_MOVE};

enum class DRIVE_MOTOR_STATE {DM_ST_POWERUP = 0,
                             DM_ST_SC,
                             DM_ST_FIX,
                             DM_ST_POS,
                             DM_ST_IDLE,
                             DM_ST_CHARGE,
                             DM_ST_SPEED};

enum class LM_CTRL_SEQ_STATE {CTRL_SEQ_POWERUP = 0,
                             CTRL_SEQ_GOHOME,
                              CTLSEQ_RETRACTED,
                              CTLSEQ_RAISE_FAST,
                              CTLSEQ_RAISE_SLOW,
                              CTLSEQ_AWAIT_CONTAINER,
                              CTLSEQ_HOLD_UP_LOW_FORCE,
                              CTLSEQ_RETRACTING_FAST,
                              CTLSEQ_HOLD_UP_HI_FORCE,
                              CTLSEQ_HOLD_UP_MED_FORCE,
                              CTLSEQ_RETRACTING_SLOW,
                              CTLSEQ_BW_DRV_CTRL,
                              CTLSEQ_BW_DRV_DONE,
                              CTLSEQ_FLT_STATE};

enum class LIFT_MOTOR_STATE {LMM_ST_IDLE = 0,
                            LMM_ST_CHARGE,
                            LMM_MOVING};


enum Current_Page  {SWMAIN, MAINT, DSS, CON_MON, ACC_ZONE, OCP_STATUS, MCP_STATUS, LCP_STATUS, PDU_STATUS};

/********************* Structures  *****************************/

/*-----------------------------------------------------------------------------
 *  Description : CAN Message Structure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef struct{
    uint32_t RCI               :2;
    uint32_t NodeIdentifier    :5;
    uint32_t UNUSED1           :3;
	uint32_t FuntionIdentifier :6;
    uint32_t PVT               :1;
    uint32_t LCL               :1;
    uint32_t FSB               :1;
    uint32_t SOURCE_FID        :7;
    uint32_t LCC               :3;
    uint32_t UNUSED2           :3;
}ARBITRATION_FORMAT;

typedef union
{
    ARBITRATION_FORMAT      Bits;
    uint32_t                Data;
} ARBITRATION_FIELD;

typedef struct{
    ARBITRATION_FIELD  arbitration;
    uint8_t             DLC;
    uint64_t            Payload;
}CAN_DATA;


/*-----------------------------------------------------------------------------
 *  Description : Access Zones Structure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef struct
    {
        uint32_t    Access_Zone_Enabled     :1;
}Access_Zone_Signal;

typedef union{
        Access_Zone_Signal Signal[29];
        uint32_t Data;
}Cargo_Zone_Data;

/*-----------------------------------------------------------------------------
 *  Description : MCP/ICP Panel StatusStructure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef struct
{
    uint64_t    PB_20FT_LED                     :1;
    uint64_t    PB_Dual_Operator_LED            :1;
    uint64_t    PB_Side_Select_Right_LED        :1;
    uint64_t    PB_Side_Select_Left_LED         :1;
    uint64_t    PB_Zone_Select_FWD_LED          :1;
    uint64_t    PB_Zone_Select_AFT_LED          :1;
    uint64_t    PB_On_Off_LED                   :1;
    uint64_t    LED_System_Active               :1;

    uint64_t    PB_LCP_RH4_3_Enable_BOTTOM_LED         :1;
    uint64_t    PB_LCP_RH4_3_Enable_TOP_LED         :1;
    uint64_t    PB_LCP_RH2_1_Enable_BOTTOM_LED         :1;
    uint64_t    PB_LCP_RH2_1_Enable_TOP_LED         :1;
    uint64_t    PB_LCP_LH4_3_Enable_BOTTOM_LED         :1;
    uint64_t    PB_LCP_LH4_3_Enable_TOP_LED         :1;
    uint64_t    PB_LCP_LH2_1_Enable_BOTTOM_LED         :1;
    uint64_t    PB_LCP_LH2_1_Enable_TOP_LED         :1;

    uint64_t    Engineering_Data_1                  :6;
    uint64_t    PB_PDU_Stop                     :1;
    uint64_t    PB_Spin_LED                     :1;

    uint64_t    Engineering_Data_2                :8;
    uint64_t    Engineering_Data_3                :32;
}Panel_Status_Signals;

typedef union{
        Panel_Status_Signals Signal;
        uint64_t Data;
}Panel_Status_Data;


/*-----------------------------------------------------------------------------
 *  Description : OCP Panel StatusStructure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef struct
{
    uint64_t    PB_20FT_LED                         :1;
    uint64_t    PB_Dual_Operator_LED                :1;
    uint64_t    PB_Zone_Select_FWD_LED              :1;
    uint64_t    PB_Zone_Select_AFT_LED              :1;
    uint64_t    PB_Side_Select_Right_LED            :1;
    uint64_t    PB_Side_Select_Left_LED             :1;
    uint64_t    PB_On_Off_LED                       :1;
    uint64_t    LED_System_Active                   :1;

    uint64_t    Engineering_Data_1                  :7;
    uint64_t    PB_PDU_Stop                     :1;

    uint64_t    Engineering_Data_2                :16;
    uint64_t    Engineering_Data_3                :32;

}OCP_Panel_Status_Signals;

typedef union{
    OCP_Panel_Status_Signals Signal;
    uint64_t Data;
}OCP_Panel_Status_Data;


/*-----------------------------------------------------------------------------
 *  Description : LCP Panel StatusStructure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef struct
{
    uint64_t    Engineering_Data_1                :3;
    uint64_t    PB_Zone_Stop_LED                         :1;
    uint64_t    PB_PDU_Stop                         :1;
    uint64_t    LCP_PB_Unlock_Next_LED          :1;
    uint64_t    LCP_PB_Dual_Lane_LED            :1;
    uint64_t    LCP_LED_Panel_Enabled           :1;

    uint64_t    Engineering_Data_2                :8;
    uint64_t    Engineering_Data_3                :16;
    uint64_t    Engineering_Data_4                :32;


}LCP_Panel_Status_Signals;

typedef union{
    LCP_Panel_Status_Signals Signal;
    uint64_t Data;
}LCP_Panel_Status_Data;

/*-----------------------------------------------------------------------------
 *  Description : MCP/ICP Panel Command Structure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef struct
{
    uint64_t    MCP_PB_LCP_LH4_3_Enable                 :1;
    uint64_t    MCP_PB_LCP_LH2_1_Enable                 :1;
    uint64_t    MCP_PB_Zone_Select_FWD                  :1;
    uint64_t    MCP_PB_Zone_Select_AFT                  :1;
    uint64_t    MCP_PB_Side_Select_Right                :1;
    uint64_t    MCP_PB_Side_Select_Left                 :1;
    uint64_t    MCP_PB_PDU_Stop                         :1;
    uint64_t    MCP_PB_Power_On_Off                     :1;

    uint64_t    MCP_Joystick_OUT                        :1;
    uint64_t    MCP_Joystick_IN                         :1;
    uint64_t    MCP_Joystick_FWD                        :1;
    uint64_t    MCP_Joystick_AFT                        :1;
    uint64_t    MCP_PB_20FT                             :1;
    uint64_t    MCP_PB_Dual_Operator                    :1;
    uint64_t    MCP_PB_LCP_RH4_3_Enable                 :1;
    uint64_t    MCP_PB_LCP_RH2_1_Enable                 :1;

    uint64_t    NVM_Integrity_Check_Fault               :1;
    uint64_t    NVM_Checksum_Fault                      :1;
    uint64_t    Engineering_Data_1                      :1;
    uint64_t    OPSW_CRC_Fault                          :1;
    uint64_t    MCP_PB_Spin                             :1;
    uint64_t    MCP_TGLS_20FT_IN                        :1;
    uint64_t    MCP_TGLS_20FT_OUT                       :1;
    uint64_t    MCP_Joystick_NEUTRAL                    :1;

    uint64_t    MCP_PB_LCP_RH2_1_Enable_Fault           :1;
    uint64_t    MCP_PB_LCP_LH4_3_Enable_Fault           :1;
    uint64_t    MCP_PB_LCP_LH2_1_Enable_Fault           :1;
    uint64_t    MCP_PB_Zone_Select_FWD_Fault            :1;
    uint64_t    MCP_PB_Zone_Select_AFT_Fault            :1;
    uint64_t    MCP_PB_Side_Select_Right_Fault          :1;
    uint64_t    MCP_PB_Side_Select_Left_Fault           :1;
    uint64_t    MCP_PB_Power_On_Off_Fault               :1;

    CP_STATE    MCP_Panel_Status                        :3;
    uint64_t    MCP_PB_Lamp_Test_Fault                  :1;
    uint64_t    MCP_PB_Spin_Fault                       :1;
    uint64_t    MCP_PB_20FT_Fault                       :1;
    uint64_t    MCP_PB_Dual_Operator_Fault              :1;
    uint64_t    MCP_PB_LCP_RH4_3_Enable_Fault           :1;

    uint64_t    Engineering_Data_2                      :2;
    uint64_t    MCP_Mux_Current_Voltage                 :2;
    uint64_t    MCP_TGLS_20FT_Fault                     :2;
    uint64_t    MCP_Joystick_Fault                      :2;

    uint64_t    MCP_Measured_Current_Voltage            :16;
 /*
        uint64_t    MCP_Switch_Fault_Status                 :1;       
        uint64_t    MCP_PB_PDU_Stop_Fault                   :1;      
        uint64_t    MCP_LED_System_Active_Fault             :1;
*/
}MCP_Panel_CMD_Signals;

typedef union{
    MCP_Panel_CMD_Signals Signal;
    uint64_t Data;
}MCP_Panel_CMD_Data;


/*-----------------------------------------------------------------------------
 *  Description : OCP Panel Command Structure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef struct
{
    uint64_t    OCP_TGLS_20FT_OUT               :1;
    uint64_t    OCP_TGLS_20FT_IN               :1;
    uint64_t    OCP_PB_Zone_Select_FWD          :1;
    uint64_t    OCP_PB_Zone_Select_AFT          :1;
    uint64_t    OCP_PB_Side_Select_Right        :1;
    uint64_t    OCP_PB_Side_Select_Left         :1;
    uint64_t    OCP_PB_PDU_Stop                 :1;
    uint64_t    OCP_PB_Power_On_Off             :1;

    uint64_t    Engineering_Data_1              :1;
    uint64_t    Engineering_Data_2              :1;
    uint64_t    OCP_TGLS_L_R_AFT                :1;
    uint64_t    OCP_TGLS_L_R_FWD                :1;
    uint64_t    OCP_TGLS_IN_OUT_OUT             :1;
    uint64_t    OCP_TGLS_IN_OUT_IN              :1;
    uint64_t    OCP_PB_20FT                     :1;
    uint64_t    OCP_PB_Dual_Operator            :1;

    uint64_t    OCP_PB_Zone_Select_AFT_Fault    :1;
    uint64_t    OCP_PB_Side_Select_Right_Fault  :1;
    uint64_t    OCP_PB_Side_Select_Left_Fault   :1;
    uint64_t    OCP_PB_Power_On_Off_Fault       :1;
    uint64_t    NVM_Integrity_Check_Fault       :1;
    uint64_t    NVM_Checksum_Fault              :1;
    uint64_t    Engineering_Data_3              :1;
    uint64_t    OPSW_CRC_Fault                  :1;

    uint64_t    OCP_TGLS_IN_OUT_Fault           :2;
    uint64_t    OCP_TGLS_20FT_Fault             :2;
    uint64_t    OCP_PB_Lamp_Test_Fault          :1;
    uint64_t    OCP_PB_20FT_Fault               :1;
    uint64_t    OCP_PB_Dual_Operator_Fault      :1;
    uint64_t    OCP_PB_Zone_Select_FWD_Fault    :1;

    uint64_t    Engineering_Data_4              :1;
    uint64_t    OCP_Mux_Current_Voltage         :2;
    CP_STATE    OCP_Panel_Status                :3;
    uint64_t    OCP_TGLS_L_R_Fault              :2;

    uint64_t    Engineering_Data_5              :8;

    uint64_t    OCP_Measured_Current_Voltage    :16;
/*
    uint64_t    OCP_Switch_Fault_Status         :1;
    uint64_t    OCP_PB_PDU_Stop_Fault           :1;
    uint64_t    OCP_LED_System_Active_Fault     :1;
*/
}OCP_Panel_CMD_Signals;

typedef union{
    OCP_Panel_CMD_Signals Signal;
    uint64_t Data;
}OCP_Panel_CMD_Data;


/*-----------------------------------------------------------------------------
 *  Description : ICP Panel Command Structure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef struct
{
    uint64_t    ICP_PB_Power_On_Off                     :1;
    uint64_t    ICP_PB_PDU_Stop                         :1;
    uint64_t    ICP_PB_Side_Select_Left                 :1;
    uint64_t    ICP_PB_Side_Select_Right                :1;
    uint64_t    ICP_PB_Zone_Select_AFT                  :1;
    uint64_t    ICP_PB_Zone_Select_FWD                  :1;
    uint64_t    ICP_PB_LCP_LH2_1_Enable                 :1;
    uint64_t    ICP_PB_LCP_LH4_3_Enable                 :1;
    uint64_t    ICP_PB_LCP_RH2_1_Enable                 :1;
    uint64_t    ICP_PB_LCP_RH4_3_Enable                 :1;
    uint64_t    ICP_PB_Dual_Operator                    :1;
    uint64_t    ICP_PB_20FT                             :1;
    uint64_t    ICP_Joystick_AFT                        :1;
    uint64_t    ICP_Joystick_FWD                        :1;
    uint64_t    ICP_Joystick_IN                         :1;
    uint64_t    ICP_Joystick_OUT                        :1;
    uint64_t    ICP_Joystick_NEUTRAL                    :1;
    uint64_t    ICP_TGLS_20FT_OUT                       :1;
    uint64_t    ICP_TGLS_20FT_IN                        :1;
    uint64_t    ICP_PB_Spin                             :1;
    uint64_t    ICP_Switch_Fault_Status                 :1;
    uint64_t    ICP_PB_Power_On_Off_Fault               :1;
    uint64_t    ICP_PB_PDU_Stop_Fault                   :1;
    uint64_t    ICP_PB_Side_Select_Left_Fault           :1;
    uint64_t    ICP_PB_Side_Select_Right_Fault          :1;
    uint64_t    ICP_PB_Zone_Select_AFT_Fault            :1;
    uint64_t    ICP_PB_Zone_Select_FWD_Fault            :1;
    uint64_t    ICP_PB_LCP_LH2_1_Enable_Fault           :1;
    uint64_t    ICP_PB_LCP_LH4_3_Enable_Fault           :1;
    uint64_t    ICP_PB_LCP_RH2_1_Enable_Fault           :1;
    uint64_t    ICP_PB_LCP_RH4_3_Enable_Fault           :1;
    uint64_t    ICP_PB_Dual_Operator_Fault              :1;
    uint64_t    ICP_PB_20FT_Fault                       :1;
    uint64_t    ICP_Joystick_Fault                      :1;
    uint64_t    ICP_TGLS_20FT_Fault                     :1;
    uint64_t    ICP_PB_Spin_Fault                       :1;
    uint64_t    ICP_PB_Lamp_Test_Fault                  :1;
    uint64_t    ICP_LED_System_Active_Fault             :1;
    uint64_t    ICP_Mux_Current_Voltage                 :2;
    CP_STATE    ICP_Panel_Status                        :4;
    uint64_t    ICP_Measured_Current_Voltage            :16;
}ICP_Panel_CMD_Signals;

typedef union{
    ICP_Panel_CMD_Signals Signal;
    uint64_t Data;
}ICP_Panel_CMD_Data;



/*-----------------------------------------------------------------------------
 *  Description : LCP Panel Command Structure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef struct
{
    uint64_t    Engineering_Data_1              :1;
    uint64_t    Engineering_Data_2              :1;
    uint64_t    LCP_PB_Zone_Stop                :1;
    uint64_t    LCP_PB_Unlock_Next              :1;
    uint64_t    LCP_PB_Dual_Lane                :1;
    uint64_t    LCP_TGLS_Drive_AFT              :1;
    uint64_t    LCP_TGLS_Drive_FWD              :1;
    uint64_t    LCP_PB_PDU_Stop                 :1;

    uint64_t    Engineering_Data_3              :1;
    uint64_t    Engineering_Data_4              :1;
    uint64_t    LCP_PB_Unlock_Next_Fault        :1;
    uint64_t    LCP_PB_Dual_Lane_Fault          :1;
    uint64_t    NVM_Integrity_Check_Fault       :1;
    uint64_t    NVM_Checksum_Fault              :1;
    uint64_t    PB_Zone_Stop_Fault              :1;
    uint64_t    OPSW_CRC_Fault                  :1;

    uint64_t    LCP_Mux_Current_Voltage         :2;
    CP_STATE    LCP_Panel_Status                :3;
    uint64_t    LCP_TGLS_Drive_Fault            :2;
    uint64_t    LCP_PB_Lamp_Test_Fault          :1;

    uint64_t    Engineering_Data_5              :8;

    uint64_t    LCP_Measured_Current_Voltage    :16;

    uint64_t    LCP_Switch_Fault_Status         :1;
    uint64_t    LCP_PB_PDU_Stop_Fault           :1;

    uint64_t    Engineering_Data_6              :16;
    //uint64_t    LCP_LED_Panel_Enabled_Fault     :1;

}LCP_Panel_CMD_Signals;

typedef union{
    LCP_Panel_CMD_Signals Signal;
    uint64_t Data;
}LCP_Panel_CMD_Data;


/*-----------------------------------------------------------------------------
 *  Description : LCP 20FT Panel Command Structure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef struct
{

    uint64_t    LCP_PB_PDU_Stop                 :1;
    uint64_t    LCP_TGLS_Drive_FWD              :1;
    uint64_t    LCP_TGLS_Drive_AFT              :1;
    uint64_t    LCP_TGLS_L_R_LEFT               :1;
    uint64_t    LCP_TGLS_L_R_RIGHT              :1;
    uint64_t    LCP_TGLS_20FT_IN                :1;
    uint64_t    LCP_TGLS_20FT_OUT               :1;
    uint64_t    LCP_PB_Dual_Lane                :1;
    uint64_t    LCP_PB_Unlock_Next              :1;
    uint64_t    LCP_Switch_Fault_Status         :1;
    uint64_t    LCP_PB_PDU_Stop_Fault           :1;
    uint64_t    LCP_TGLS_Drive_Fault            :1;
    uint64_t    LCP_TGLS_L_R_Fault              :1;
    uint64_t    LCP_TGLS_20FT_Fault             :1;
    uint64_t    LCP_PB_Dual_Lane_Fault          :1;
    uint64_t    LCP_PB_Unlock_Next_Fault        :1;
    uint64_t    LCP_PB_Lamp_Test_Fault          :1;
    uint64_t    LCP_LED_Panel_Enabled_Fault     :1;
    uint64_t    LCP_Mux_Current_Voltage         :2;
    CP_STATE    LCP_Panel_Status                :4;
    uint64_t    LCP_Measured_Current_Voltage    :16;
}LCP_20Ft_Panel_CMD_Signals;

typedef union{
    LCP_20Ft_Panel_CMD_Signals Signal;
    uint64_t Data;
}LCP_20Ft_Panel_CMD_Data;


/*-----------------------------------------------------------------------------
 *  Description : PDU Redirected Data Structure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef struct
{
    CMD_ID_CODE    Command_Identification_Code;
    DIRECTION_VELOCITY    Direction_Velocity;
    uint8_t    Group_Identifier;
    uint8_t    Expiry_Time;
    uint8_t    Bytes[4];
}PDU_Redirected_Signals;

typedef union
{
    PDU_Redirected_Signals Signal;
    uint64_t                Data;
}PDU_Redirected_Data;



/*-----------------------------------------------------------------------------
 *  Description : PDU STATUS Message 1 Structure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef struct
{
    PDU_ROLLER_POSITION    PDU_Roller_Position                             :2;
    PDU_COVER_STATUS     PDU_Cover_Status                                :2;
    PDU_HEALTH_STATUS    PDU_Health_Status                               :2;
    PDU_TYPE             PDU_Type                                        :2;


    PDU_STATE   PDU_State                                       :4;
    PDU_MODE    PDU_Mode                                        :4;

    DRIVE_MOTOR_STATE    Drive_Motor_State                               :4;
    LIFT_MOTOR_MODE    Lift_Motor_Mode                                 :2;
    DRIVE_MOTOR_MODE    Drive_Motor_Mode                                :2;

    PDU_DRIVE_COMMAND_DIR    Active_Drive_Command_Direction                  :2;
    LIFT_MOTOR_STATE    Lift_Motor_State                                :2;
    LM_CTRL_SEQ_STATE    Lift_Motor_Control_Seq_State                    :4;

    uint64_t    Lift_Motor_Hall_Sensor_State_Error              :1;
    uint64_t    Drive_Motor_Hall_Sensor_State_Error             :1;
    uint64_t    VAC115_Phase_Fault                              :1;
    uint64_t    Board_Over_Temperature_Fault                    :1;
    uint64_t    IGBT_Protection_Trip                            :1;
    uint64_t    HVDC_Under_Voltage_Fault                        :1;
    uint64_t    HVDC_Over_Voltage_Fault                         :1;
    PDU_HOLD_STATUS    Hold_Status                                     :1;

    uint64_t    NVM_Integrity_Check_Fault       :1;
    uint64_t    NVM_Checksum_Fault              :1;
    uint64_t    OPSW_CRC_Fault                  :1;
    uint64_t    Engineering_Data_1              :1;
    uint64_t    Lift_Mechanism_Fault                            :1;
    uint64_t    Lift_Motor_State_Machine_Error                  :1;
    uint64_t    Drive_Motor_State_Machine_Error                 :1;

    uint64_t    Engineering_Data_2              :1;
    uint64_t    Engineering_Data_3              :1;
    uint64_t    LM_Current_Fault_Monitoring_Status              :1;
    uint64_t    DM_Current_Fault_Monitoring_Status              :1;
    uint64_t    IGBT_Onchip_Over_Temperature_Fault              :1;
    uint64_t    Drive_Motor_Over_Temperature_Fault              :1;
    uint64_t    ATRU_Left_Coil_Over_Temperature_Fault           :1;
    uint64_t    ATRU_Right_Coil_Over_Temperature_Fault          :1;

/*        uint64_t    CAN_Address_Pin_Parity_Fault                    :1;
        uint64_t    Program_Integrity_Check_Fault                   :1;
        uint64_t    RAM_Fault                                       :1;
        uint64_t    NVM_Fault                                       :1;
        uint64_t    HVDC_Over_Current_Fault                         :1;
  */

}PDU_Status_MSG1_Signals;

typedef union{
    PDU_Status_MSG1_Signals Signal;
    uint64_t Data;
}PDU_Status_MSG1_Data;

/*-----------------------------------------------------------------------------
 *  Description : ULD Status Message
 *
 *
 *-----------------------------------------------------------------------------
 */

typedef struct{
    uint64_t    Engineering_Data                :9;
    uint64_t    ULD_LH_Lagging_Edge_PDU         :6;
    uint64_t    ULD_RH_Next_PDU                 :6;
    uint64_t    ULD_LH_Next_PDU                 :6;
    uint64_t    ULD_type                        :2;
    uint64_t    ULD_RH_Lagging_Edge_PDU       :6;
    uint64_t    ULD_RH_Trailing_Edge_PDU        :6;
    uint64_t    ULD_LH_Trailing_Edge_PDU        :6;
    uint64_t    ULD_RH_Leading_Edge_PDU        :6;
    uint64_t    ULD_LH_Leading_Edge_PDU        :6;
    uint64_t    ULD_Size                        :3;
    uint64_t    ULD_SW_Latch                    :1;
    uint64_t    ULD_Movement                    :4;
    uint64_t    ULD_ID                          :6;
}ULD_Status_Signals;


typedef union{
    ULD_Status_Signals Signal;
    uint64_t Data;
}ULD_Status;

/*-----------------------------------------------------------------------------
 *  Description : PDU STATUS Message 2 Structure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef union{
    uint64_t    Current_Mux                   :2;
    uint64_t    Voltage_Mux                   :2;
    uint64_t    Temperature_Mux               :4;
    uint64_t    Measured_Current              :16;
    uint64_t    Measured_Voltage                 :16;
    uint64_t    Measured_Temperature             :16;
}PDU_Status_MSG2_Signals;

typedef union{
    PDU_Status_MSG2_Signals Signal;
    uint64_t Data;
}PDU_Status_MSG2_Data;

/*-----------------------------------------------------------------------------
 *  Description : PDU STATUS Message 3 Structure
 *
 *
 *-----------------------------------------------------------------------------
 */
typedef union{
    uint16_t    PDU_Roller_Speed;
    uint16_t    PDU_LM_Speed;
    uint16_t    PDU_LM_Hall_Count;
}PDU_Status_MSG3_Signals;

typedef union{
    PDU_Status_MSG3_Signals Signal;
    uint64_t Data;
}PDU_Status_MSG3_Data;

/*-----------------------------------------------------------------------------
 *  Description : Access Zones Class Declaration
 *
 *
 *-----------------------------------------------------------------------------
 */

class Cargo_Zone{
    public:
    Cargo_Zone_Data CargoZoneData;

    void update();

};

/*-----------------------------------------------------------------------------
 *  Description : MCP Class Declaration
 *
 *
 *-----------------------------------------------------------------------------
 */
class MCP {

    public:
    Panel_Status_Data       Status;
    MCP_Panel_CMD_Data		Command;

    void update();
};

/*-----------------------------------------------------------------------------
 *  Description : OCP Class Declaration
 *
 *
 *-----------------------------------------------------------------------------
 */
class OCP {

    public:
    OCP_Panel_Status_Data	Status;
    OCP_Panel_CMD_Data		Command;

    void update();

};

/*-----------------------------------------------------------------------------
 *  Description : ICP Class Declaration
 *
 *
 *-----------------------------------------------------------------------------
 */
class ICP {

    public:
    Panel_Status_Data       Status;
    ICP_Panel_CMD_Data		Command;

    void update();

};

/*-----------------------------------------------------------------------------
 *  Description : LCP Class Declaration
 *
 *
 *-----------------------------------------------------------------------------
 */
class LCP {

    public:
    LCP_Panel_Status_Data	Status;
    LCP_Panel_CMD_Data		Command;

    void update();
};

class LCP20FT {
        public:
        LCP_Panel_Status_Data           Status;
        LCP_20Ft_Panel_CMD_Signals		Command;

        void update();
};

/*-----------------------------------------------------------------------------
 *  Description : PDU Class Declaration
 *
 *
 *-----------------------------------------------------------------------------
 */
class PowerDriveUnit {
    public:
    PDU_Redirected_Data		PrepareData;
    PDU_Redirected_Data	 		MoveData;
    PDU_Redirected_Data 		RetractData;
    PDU_Status_MSG1_Data	StatusMSG1;
    PDU_Status_MSG2_Data	StatusMSG2;
    PDU_Status_MSG3_Data	StatusMSG3;

    void update();

};

extern Cargo_Zone cargoZone;
extern MCP _MCP;
extern ICP _ICP;
extern OCP _OCP;
extern LCP _LCP[8];
extern LCP20FT _LCP20FT[2];
extern ULD_Status _ULD[20];
extern PowerDriveUnit _PDU[PDU_MAX_COUNT];
extern Current_Page CurrPage;
extern Current_Page PrevPage;
#endif // COMMON_H
