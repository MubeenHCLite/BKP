
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : section4page.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */#ifndef SECTION4PAGE_H
#define SECTION4PAGE_H

#include <QDialog>
#include "lcpstatuspage.h"
#include "common.h"
#include "pdustatpg.h"
#include "lcpstatuspage.h"

namespace Ui {
class Section4Page;
}

class Section4Page : public QDialog
{
    Q_OBJECT

public:
    explicit Section4Page(QWidget *parent = 0);
    ~Section4Page();


private slots:
    void on_R18_clicked();

    void on_R19_clicked();

    void on_R20_clicked();

    void on_R21_clicked();

    void on_R22_clicked();

    void on_R23_clicked();

    void on_R24_clicked();

    void on_R25_clicked();

    void on_R26_clicked();

    void on_R27_clicked();

    void on_R28_clicked();

    void on_R29_clicked();

    void on_R30_clicked();

    void on_R31_clicked();

    void on_R32_clicked();

    void on_R33_clicked();

    void on_RH3_clicked();

    void on_RH4_clicked();

private:
    Ui::Section4Page *ui;
    PDUStatPg *PduStatP;
    LCPStatusPage  *LCPStatusP;
};

#endif // SECTION4PAGE_H
