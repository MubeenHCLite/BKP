#ifndef NVMCONTENT_H
#define NVMCONTENT_H




typedef struct {
    uint8_t ConfRecordCount;
    uint8_t FaultRecordCount;
    uint8_t Spare[3];
    uint8_t NVMHeaderChecksum;
}NVM_Header;

typedef struct {
    uint8_t  RecordNumber;
    uint64_t HW_FIN;
    uint8_t  SW_FIN[12];
    uint32_t MSN;
    uint32_t CityCode;
    uint8_t  NodeId;
}Configuration_Record;

typedef struct {
    uint64_t  PowerUpTime;
    uint32_t  CityCode;
    uint8_t  NodeId;
    uint64_t  EndTime;
}Power_Time_Record;

typedef struct {
    uint8_t   RecordNumber;
    uint8_t   FSID;
    uint64_t  UTCDateTime;
    uint32_t  CityCode;
}Fault_Record;

typedef struct {
    uint8_t   DataloadRequestFlag;
    uint8_t   DLAAssignedLRUID;
}Other_Information;

typedef struct {
    NVM_Header              NVMHeader;
    Configuration_Record    Configuration;
    Power_Time_Record       PowerTime;
    Fault_Record            FaultRecord;
    Other_Information       OtherInformation;
}NVM_Record;

#endif // NVMCONTENT_H
