
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : commondata.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef COMMONDATA_H
#define COMMONDATA_H

#include <QString>

extern QString LCPAmberP[8];
extern QString LCPGreenP[8];
extern QString LCPGreyP[8];
extern QString LCPRdAmP[8];
extern QString LCPRdGnP[8];

extern QString BaseFolder;
extern QString PDUAmberAFP;
extern QString PDUAmberFWP;
extern QString PDUAmberINP;
extern QString PDUAmberOUP;
extern QString PDUGreenAFP;
extern QString PDUGreenFWP;
extern QString PDUGreenINP;
extern QString PDUGreenOUP;
extern QString ICPAmberP;
extern QString ICPGreenP;
extern QString ICPGreyP;
extern QString ICPRdAmP;
extern QString ICPRdGnP;
extern QString MCPAmberP;
extern QString MCPGreenP;
extern QString MCPGreyP;
extern QString MCPRdAmP;
extern QString MCPRdGnP;
extern QString OCPAmberP;
extern QString OCPGreenP;
extern QString OCPGreyP;
extern QString OCPRdAmP;
extern QString OCPRdGnP;
extern QString PDUAmberP;
extern QString PDUGreenP;
extern QString PDUGreyP;
extern QString PDURedP;
extern QString PDUWhAmbP;
extern QString PDUWhiteP;
extern QString PDUWhRedP;

extern int PDUXCord[116];
extern int PDUYCord[116];
#endif // COMMONDATA_H
