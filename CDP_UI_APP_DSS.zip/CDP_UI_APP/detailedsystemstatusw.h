
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : detailedsystemstatus.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef DETAILEDSYSTEMSTATUSW_H
#define DETAILEDSYSTEMSTATUSW_H

#include <QDialog>
#include <QLabel>
#include <QPushButton>
#include "common.h"
#include "commondata.h"
#include "iconmap.h"

/********************* PREPROCESSOR DIRECTIVES  *****************************/
#define DSS_BK_BTN_WT       80
#define DSS_BK_BTN_HT       80
#define DSS_BK_BTN_X        20
#define DSS_BK_BTN_Y        20

#define DSS_PDU_IND_WT      20
#define DSS_PDU_IND_HT      30

#define DSS_MCP_IND_X           310
#define DSS_MCP_IND_Y           120
#define DSS_MCP_IND_WT          105
#define DSS_MCP_IND_HT          100

#define DSS_ICP_IND_X           310
#define DSS_ICP_IND_Y           400
#define DSS_ICP_IND_WT          100
#define DSS_ICP_IND_HT          80

#define DSS_OCP_IND_X           450
#define DSS_OCP_IND_Y           120
#define DSS_OCP_IND_WT          110
#define DSS_OCP_IND_HT          50


#define DSS_LCP4_IND_X          750
#define DSS_LCP3_IND_X          970
#define DSS_LCP2_IND_X          1220
#define DSS_LCP1_IND_X          1500
#define DSS_LCPH_IND_Y          120
#define DSS_LCPR_IND_Y          400
#define DSS_LCP_IND_WT          110
#define DSS_LCP_IND_HT          50





namespace Ui {
class DetailedSystemStatusW;
}

class DetailedSystemStatusW : public QDialog
{
    Q_OBJECT

public:
    explicit DetailedSystemStatusW(QWidget *parent = 0);
    ~DetailedSystemStatusW();

private slots:
    void UpdateUI();
    void UpdateUItable();
    void HandleBackButton();
    void UpdateUItableOCP();
    void UpdateUItableLCP();

private:
    Ui::DetailedSystemStatusW *ui;
    QTimer *timer;
    QTimer *timerIsr;
    QTimer *timerIsrOCP;
    QTimer *timerIsrLCP;
    QPushButton             *BackButton;
};

#endif // DETAILEDSYSTEMSTATUSW_H
