/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : legendsmenupage.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : The CDP OPSW to show the status of all LRU display indication
 *                representations.
 *
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "legendsmenupage.h"
#include "ui_legendsmenupage.h"
#include <QPixmap>
#include "common.h"

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the Legends Menu window application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
LegendsMenuPage::LegendsMenuPage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LegendsMenuPage)
{
    ui->setupUi(this);

    QPixmap Background(BaseFolder + "LegendsMenu.png");
    Background = Background.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette Palette;
    Palette.setBrush(QPalette::Window, Background);
    this->setPalette(Palette);

    BackButton = new QPushButton("", this);
    BackButton->setGeometry(QRect(QPoint(LMI_BK_BTN_X, LMI_BK_BTN_Y), QSize(LMI_BK_BTN_WT, LMI_BK_BTN_HT)));
    QPixmap BackButtonBkg(BaseFolder + "BackButton.png");
    QIcon BackButtonIcon(BackButtonBkg.scaled(LMI_BK_BTN_WT, LMI_BK_BTN_HT,Qt::KeepAspectRatio));
    BackButton->setIcon(BackButtonIcon);
    BackButton->setIconSize(BackButtonBkg.rect().size());
    connect(BackButton, &QPushButton::released, this, &LegendsMenuPage::HandleBackButton);
}

LegendsMenuPage::~LegendsMenuPage()
{
    delete ui;
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Main screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void LegendsMenuPage::HandleBackButton(){
    hide();
}
