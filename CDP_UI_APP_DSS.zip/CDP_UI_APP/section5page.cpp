/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : section5page.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : Provides implementation of Access sections, listing all the LRUs
 *                (CPs and PDUs). Implementation of Navigation to Status page of
 *                the LRUs listed in the section.
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "section5page.h"
#include "ui_section5page.h"

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the Section Page application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
Section5Page::Section5Page(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Section5Page)
{
    ui->setupUi(this);
    qDebug() << "Section 5 Page";
    LCPStatusP = new LCPStatusPage(this);
    PduStatP = new PDUStatPg(this);
}

Section5Page::~Section5Page()
{
    delete ui;
}


/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Respective LRU Status screens
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void Section5Page::on_L01_clicked()
{
    PduStatP->PDUNum = 0;
    PduStatP->PDUName = "PDU L 01";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L02_clicked()
{
    PduStatP->PDUNum = 1;
    PduStatP->PDUName = "PDU L 02";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L03_clicked()
{
    PduStatP->PDUNum = 2;
    PduStatP->PDUName = "PDU L 03";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L04_clicked()
{
    PduStatP->PDUNum = 3;
    PduStatP->PDUName = "PDU L 04";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L05_clicked()
{
    PduStatP->PDUNum = 4;
    PduStatP->PDUName = "PDU L 05";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L06_clicked()
{
    PduStatP->PDUNum = 5;
    PduStatP->PDUName = "PDU L 06";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L07_clicked()
{
    PduStatP->PDUNum = 6;
    PduStatP->PDUName = "PDU L 07";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L08_clicked()
{
    PduStatP->PDUNum = 7;
    PduStatP->PDUName = "PDU L 08";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L09_clicked()
{
    PduStatP->PDUNum = 8;
    PduStatP->PDUName = "PDU L 09";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L10_clicked()
{
    PduStatP->PDUNum = 9;
    PduStatP->PDUName = "PDU L 10";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L11_clicked()
{
    PduStatP->PDUNum = 10;
    PduStatP->PDUName = "PDU L 12";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L12_clicked()
{
    PduStatP->PDUNum = 11;
    PduStatP->PDUName = "PDU L 13";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L13_clicked()
{
    PduStatP->PDUNum = 12;
    PduStatP->PDUName = "PDU L 13";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L14_clicked()
{
    PduStatP->PDUNum = 13;
    PduStatP->PDUName = "PDU L 14";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L15_clicked()
{
    PduStatP->PDUNum = 14;
    PduStatP->PDUName = "PDU L 15";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L16_clicked()
{
    PduStatP->PDUNum = 15;
    PduStatP->PDUName = "PDU L 16";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_L17_clicked()
{
    PduStatP->PDUNum = 17;
    PduStatP->PDUName = "PDU L 17";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section5Page::on_LH1_clicked()
{
    LCPStatusP->LCPName = "LCP 1LH";
    LCPStatusP->LCPNum = LCP1LH;
    CurrPage = OCP_STATUS;
    PrevPage = ACC_ZONE;
    LCPStatusP->show();
}

void Section5Page::on_LH4_clicked()
{
    LCPStatusP->LCPName = "LCP 2LH";
    LCPStatusP->LCPNum = LCP2LH;
    CurrPage = OCP_STATUS;
    PrevPage = ACC_ZONE;
    LCPStatusP->show();
}
