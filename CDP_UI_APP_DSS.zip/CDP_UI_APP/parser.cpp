/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : parser.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : Implementation of validating anf parsing the CAN Messages recieved
 *                All messages received are parsed and respective signals of LRUs
 *                are updated accordibgly
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "parser.h"
#include <QDebug>

/********************************* GLOBAL DATA ELEMENTS ***********************/
QQueue<CAN_DATA>     canBuffer;
extern Cargo_Zone cargoZone;
extern MCP _MCP;
extern ICP _ICP;
extern OCP _OCP;
extern LCP _LCP[8];
extern PowerDriveUnit _PDU[PDU_MAX_COUNT];
extern bool          sh;

bool ValidateNodeID(){
    return true;
}


bool ValidateFunctionID(){
    return true;
}

bool ValidateCRC(){
    return true;
}


void ParserThread(){
    uint8_t FunctionID, NodeID, PDUInd;
    CAN_DATA CANPayload;
    //Parser Thread

    if(!canBuffer.isEmpty()){
        CANPayload  = canBuffer.dequeue();
        FunctionID = 0;
        NodeID = 0;
        PDUInd = 0;
        //Validate Node ID
        if(ValidateNodeID()){
            //Validate CRC
            if(ValidateCRC()){
                //Validate Function_ID
                if(ValidateFunctionID()){
                    FunctionID = CANPayload.arbitration.Bits.FuntionIdentifier;
                    NodeID = CANPayload.arbitration.Bits.NodeIdentifier;
                    qDebug() << "Function ID " << FunctionID;
                    qDebug() << "Node ID " << NodeID;
                    switch(FunctionID){
                            case FID_CARGO_ZONE:
                                cargoZone.CargoZoneData.Data = CANPayload.Payload;
                                qDebug() << "CargoZone";
                            break;
                            case FID_PANEL_STATUS:
                                    switch(NodeID){
                                    case NID_MCP:
                                        _MCP.Status.Data = CANPayload.Payload;
                                        qDebug() << CANPayload.Payload;
                                        qDebug() << _MCP.Status.Data;
                                        qDebug() << "_MCP Status";
                                        qDebug() << "**************** MCP Status ****************";
                                        qDebug() << "PB_20FT_LED" << _MCP.Status.Signal.PB_20FT_LED;
                                        qDebug() << "PB_Dual_Operator_LED" << _MCP.Status.Signal.PB_Dual_Operator_LED;
                                        qDebug() << "PB_Side_Select_Right_LED" << _MCP.Status.Signal.PB_Side_Select_Right_LED;
                                        qDebug() << "PB_Side_Select_Left_LED" << _MCP.Status.Signal.PB_Side_Select_Left_LED;
                                        qDebug() << "PB_Zone_Select_FWD_LED" << _MCP.Status.Signal.PB_Zone_Select_FWD_LED;
                                        qDebug() << "PB_Zone_Select_AFT_LED" << _MCP.Status.Signal.PB_Zone_Select_AFT_LED;
                                        qDebug() << "PB_On_Off_LED" << _MCP.Status.Signal.PB_On_Off_LED;
                                        qDebug() << "LED_System_Active" << _MCP.Status.Signal.LED_System_Active;
                                        qDebug() << "PB_LCP_RH4_3_Enable_BOTTOM_LED" << _MCP.Status.Signal.PB_LCP_RH4_3_Enable_BOTTOM_LED;
                                        qDebug() << "PB_LCP_RH4_3_Enable_TOP_LED" << _MCP.Status.Signal.PB_LCP_RH4_3_Enable_TOP_LED;
                                        qDebug() << "PB_LCP_RH2_1_Enable_BOTTOM_LED" << _MCP.Status.Signal.PB_LCP_RH2_1_Enable_BOTTOM_LED;
                                        qDebug() << "PB_LCP_RH2_1_Enable_TOP_LED" << _MCP.Status.Signal.PB_LCP_RH2_1_Enable_TOP_LED;
                                        qDebug() << "PB_LCP_LH4_3_Enable_BOTTOM_LED" << _MCP.Status.Signal.PB_LCP_LH4_3_Enable_BOTTOM_LED;
                                        qDebug() << "PB_LCP_LH4_3_Enable_TOP_LED" << _MCP.Status.Signal.PB_LCP_LH4_3_Enable_TOP_LED;
                                        qDebug() << "PB_LCP_LH2_1_Enable_BOTTOM_LED" << _MCP.Status.Signal.PB_LCP_LH2_1_Enable_BOTTOM_LED;
                                        qDebug() << "PB_LCP_LH2_1_Enable_TOP_LED" << _MCP.Status.Signal.PB_LCP_LH2_1_Enable_TOP_LED;
                                        qDebug() << "Engineering_Data_1" << _MCP.Status.Signal.Engineering_Data_1;
                                        qDebug() << "PB_PDU_Stop" << _MCP.Status.Signal.PB_PDU_Stop;
                                        qDebug() << "PB_Spin_LED" << _MCP.Status.Signal.PB_Spin_LED;

                                    break;
                                    case NID_OCP:
                                        _OCP.Status.Data = CANPayload.Payload;
                                        qDebug() << "_OCP Status";
                                    break;
                                    case NID_ICP:
                                        _ICP.Status.Data = CANPayload.Payload;
                                        qDebug() << "_ICP Status";
                                    break;
                                    case NID_LCP1LH:
                                        _LCP[LCP1LH].Status.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Status";
                                    break;
                                    case NID_LCP2LH:
                                        _LCP[LCP2LH].Status.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Status";
                                    break;
                                    case NID_LCP3LH:
                                        _LCP[LCP3LH].Status.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Status";
                                    break;
                                    case NID_LCP4LH:
                                        _LCP[LCP4LH].Status.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Status";
                                    break;
                                    case NID_LCP1RH:
                                        _LCP[LCP1RH].Status.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Status";
                                    break;
                                    case NID_LCP2RH:
                                        _LCP[LCP2RH].Status.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Status";
                                    break;
                                    case NID_LCP3RH:
                                        _LCP[LCP3RH].Status.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Status";
                                    break;
                                    case NID_LCP4RH:
                                        _LCP[LCP4RH].Status.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Status";
                                    break;
                                }
                            break;
                            case FID_PANEL_CMD:
                                switch(NodeID){
                                    case NID_MCP:
                                        _MCP.Command.Data = CANPayload.Payload;
                                        qDebug() << CANPayload.Payload;
                                        qDebug() << _MCP.Command.Data;
                                        qDebug() << "_MCP Command";
                                        qDebug() << "**************** MCP COmmand ****************";
                                        qDebug() << "MCP_PB_LCP_LH4_3_Enable" << _MCP.Command.Signal.MCP_PB_LCP_LH4_3_Enable;
                                        qDebug() << "MCP_PB_LCP_LH2_1_Enable" << _MCP.Command.Signal.MCP_PB_LCP_LH2_1_Enable;
                                        qDebug() << "MCP_PB_Zone_Select_FWD" << _MCP.Command.Signal.MCP_PB_Zone_Select_FWD;
                                        qDebug() << "MCP_PB_Zone_Select_AFT" << _MCP.Command.Signal.MCP_PB_Zone_Select_AFT;
                                        qDebug() << "MCP_PB_Side_Select_Right" << _MCP.Command.Signal.MCP_PB_Side_Select_Right;
                                        qDebug() << "MCP_PB_Side_Select_Left" << _MCP.Command.Signal.MCP_PB_Side_Select_Left;
                                        qDebug() << "MCP_PB_PDU_Stop" << _MCP.Command.Signal.MCP_PB_PDU_Stop;
                                        qDebug() << "MCP_PB_Power_On_Off" << _MCP.Command.Signal.MCP_PB_Power_On_Off;
                                        qDebug() << "MCP_Joystick_OUT" << _MCP.Command.Signal.MCP_Joystick_OUT;
                                        qDebug() << "MCP_Joystick_IN " << _MCP.Command.Signal.MCP_Joystick_IN;
                                        qDebug() << "MCP_Joystick_FWD" << _MCP.Command.Signal.MCP_Joystick_FWD;
                                        qDebug() << "MCP_Joystick_AFT" << _MCP.Command.Signal.MCP_Joystick_AFT;
                                        qDebug() << "MCP_PB_20FT" << _MCP.Command.Signal.MCP_PB_20FT;
                                        qDebug() << "MCP_PB_Dual_Operator" << _MCP.Command.Signal.MCP_PB_Dual_Operator;
                                        qDebug() << "MCP_PB_LCP_RH4_3_Enable" << _MCP.Command.Signal.MCP_PB_LCP_RH4_3_Enable;
                                        qDebug() << "MCP_PB_LCP_RH2_1_Enable" << _MCP.Command.Signal.MCP_PB_LCP_RH2_1_Enable;
                                        qDebug() << "NVM_Integrity_Check_Fault" << _MCP.Command.Signal.NVM_Integrity_Check_Fault;
                                        qDebug() << "NVM_Checksum_Fault" << _MCP.Command.Signal.NVM_Checksum_Fault;
                                        qDebug() << "Engineering_Data_1" << _MCP.Command.Signal.Engineering_Data_1;
                                        qDebug() << "OPSW_CRC_Fault" << _MCP.Command.Signal.OPSW_CRC_Fault;
                                        qDebug() << "MCP_PB_Spin" << _MCP.Command.Signal.MCP_PB_Spin;
                                        qDebug() << "MCP_TGLS_20FT_IN" << _MCP.Command.Signal.MCP_TGLS_20FT_IN;
                                        qDebug() << "MCP_TGLS_20FT_OUT" << _MCP.Command.Signal.MCP_TGLS_20FT_OUT;
                                        qDebug() << "MCP_Joystick_NEUTRAL" << _MCP.Command.Signal.MCP_Joystick_NEUTRAL;
                                        qDebug() << "MCP_PB_LCP_RH2_1_Enable_Fault" << _MCP.Command.Signal.MCP_PB_LCP_RH2_1_Enable_Fault;
                                        qDebug() << "MCP_PB_LCP_LH4_3_Enable_Fault" << _MCP.Command.Signal.MCP_PB_LCP_LH4_3_Enable_Fault;
                                        qDebug() << "MCP_PB_LCP_LH2_1_Enable_Fault" << _MCP.Command.Signal.MCP_PB_LCP_LH2_1_Enable_Fault;
                                        qDebug() << "MCP_PB_Zone_Select_FWD_Fault" << _MCP.Command.Signal.MCP_PB_Zone_Select_FWD_Fault;
                                        qDebug() << "MCP_PB_Zone_Select_AFT_Fault" << _MCP.Command.Signal.MCP_PB_Zone_Select_AFT_Fault;
                                        qDebug() << "MCP_PB_Side_Select_Right_Fault" << _MCP.Command.Signal.MCP_PB_Side_Select_Right_Fault;
                                        qDebug() << "MCP_PB_Side_Select_Left_Fault" << _MCP.Command.Signal.MCP_PB_Side_Select_Left_Fault;
                                        qDebug() << "MCP_PB_Power_On_Off_Fault" << _MCP.Command.Signal.MCP_PB_Power_On_Off_Fault;
                                        //qDebug() << "MCP_Panel_Status" << _MCP.Command.Signal.MCP_Panel_Status;
                                        //qDebug() << "MCP_PB_Lamp_Test_Fault" << _MCP.Command.Signal.MCP_PB_Lamp_Test_Fault;
                                        qDebug() << "MCP_PB_Spin_Fault" << _MCP.Command.Signal.MCP_PB_Spin_Fault;
                                        qDebug() << "MCP_PB_20FT_Fault" << _MCP.Command.Signal.MCP_PB_20FT_Fault;
                                        qDebug() << "MCP_PB_Dual_Operator_Fault" << _MCP.Command.Signal.MCP_PB_Dual_Operator_Fault;
                                        qDebug() << "MCP_PB_LCP_RH4_3_Enable_Fault" << _MCP.Command.Signal.MCP_PB_LCP_RH4_3_Enable_Fault;
                                        qDebug() << "Engineering_Data_2" << _MCP.Command.Signal.Engineering_Data_2;
                                        qDebug() << "MCP_Mux_Current_Voltage" << _MCP.Command.Signal.MCP_Mux_Current_Voltage;
                                        qDebug() << "MCP_TGLS_20FT_Fault" << _MCP.Command.Signal.MCP_TGLS_20FT_Fault;
                                        qDebug() << "MCP_Joystick_Fault" << _MCP.Command.Signal.MCP_Joystick_Fault;
                                        qDebug() << "MCP_Measured_Current_Voltage" << _MCP.Command.Signal.MCP_Measured_Current_Voltage;


                                    break;
                                    case NID_OCP:
                                        _OCP.Command.Data = CANPayload.Payload;
                                        qDebug() << "_OCP Command";
                                    break;
                                    case NID_ICP:
                                        _ICP.Command.Data = CANPayload.Payload;
                                        qDebug() << "_ICP Command";
                                    break;
                                    case NID_LCP1LH:
                                        _LCP[LCP1LH].Command.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Command";
                                    break;
                                    case NID_LCP2LH:
                                        _LCP[LCP2LH].Command.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Command";
                                    break;
                                    case NID_LCP3LH:
                                        _LCP[LCP3LH].Command.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Command";
                                    break;
                                    case NID_LCP4LH:
                                        _LCP[LCP4LH].Command.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Command";
                                    break;
                                    case NID_LCP1RH:
                                        _LCP[LCP1RH].Command.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Command";
                                    break;
                                    case NID_LCP2RH:
                                        _LCP[LCP2RH].Command.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Command";
                                    break;
                                    case NID_LCP3RH:
                                        _LCP[LCP3RH].Command.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Command";
                                    break;
                                    case NID_LCP4RH:
                                        _LCP[LCP4RH].Command.Data = CANPayload.Payload;
                                        qDebug() << "_LCP[] Command";
                                    break;
                            }
                            break;
                            case FID_STATUS_MSG_1:
                                 if(NodeID <= PDUL_MAX_COUNT)
                                     PDUInd = NodeID;
                                 else
                                     PDUInd = NodeID-PDUR_COUNT_START;
                                _PDU[PDUInd].StatusMSG1.Data = CANPayload.Payload;
                                qDebug() << "Input Payload : " << QString("%1").arg(_PDU[PDUInd].StatusMSG1.Data,0,16);
                                qDebug() << "PDU Status1";
                            break;
                            case FID_STATUS_MSG_2:
                                    if(NodeID <= PDUL_MAX_COUNT)
                                        PDUInd = NodeID;
                                    else
                                        PDUInd = NodeID-PDUR_COUNT_START;
                                _PDU[NodeID].StatusMSG2.Data = CANPayload.Payload;
                                qDebug() << "PDU STATUS2";
                            break;
                             case FID_STATUS_MSG_3:
                                    if(NodeID <= PDUL_MAX_COUNT)
                                        PDUInd = NodeID;
                                    else
                                        PDUInd = NodeID-PDUR_COUNT_START;
                               _PDU[NodeID].StatusMSG3.Data = CANPayload.Payload;
                               qDebug() << "PDU STATUS3";
                            break;
                            case FID_PREPARE_CMD:
                                    if(NodeID <= PDUL_MAX_COUNT)
                                        PDUInd = NodeID;
                                    else
                                        PDUInd = NodeID-PDUR_COUNT_START;
                              _PDU[NodeID].PrepareData.Data = CANPayload.Payload;
                              qDebug() << "PDU Prepare Data";
                            break;
                            case FID_MOVE_CMD:
                                    if(NodeID <= PDUL_MAX_COUNT)
                                        PDUInd = NodeID;
                                    else
                                        PDUInd = NodeID-PDUR_COUNT_START;
                              _PDU[NodeID].MoveData.Data = CANPayload.Payload;
                              qDebug() << "PDU Move Data";
                            break;
                            case FID_RETRACT_CMD:
                                    if(NodeID <= PDUL_MAX_COUNT)
                                        PDUInd = NodeID;
                                    else
                                        PDUInd = NodeID-PDUR_COUNT_START;
                              _PDU[NodeID].RetractData.Data = CANPayload.Payload;
                              qDebug() << "PDU Retract Data";
                            break;
                            default:
                                qDebug() << "Invalid data";
                            break;
                    }
                }
            }
        }
    }
}


