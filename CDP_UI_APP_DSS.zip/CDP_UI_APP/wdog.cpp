#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

static char set1[50] = "/sys/class/gpio/GPIO1/direction";
static char set1_value[50] = "/sys/class/gpio/GPIO1/value";

static char wdi[50] = "/sys/class/gpio/GPIO2/direction";
static char wdi_value[50] = "/sys/class/gpio/GPIO2/value";


bool InitializeWDOG(){
    int fd = open("/sys/class/gpio/export", O_WRONLY);
    if (fd == -1) {
        perror("Unable to open /sys/class/gpio/export");
        exit(1);
    }

    if (write(fd, "1", 2) != 2) {
        perror("Error writing to /sys/class/gpio/export for SET1");
        exit(1);
    }

    if (write(fd, "2", 2) != 2) {
        perror("Error writing to /sys/class/gpio/export for WDI");
        exit(1);
    }
    close(fd);

    // Set the WDI pin to be an output by writing "out" to /sys/class/gpio/gpio24/direction
    fd = open(wdi, O_WRONLY);
    if (fd == -1) {
        perror("WDI : Unable to open /sys/class/gpio/GPIO1/direction");
        exit(1);
    }

    if (write(fd, "out", 3) != 3) {
        perror("WDI : Error writing to /sys/class/gpio/GPIO1/direction");
        exit(1);
    }

    close(fd);

     // Set the SET pin to be an output by writing "out" to /sys/class/gpio/gpio24/direction

    fd = open(set1, O_WRONLY);
    if (fd == -1) {
        perror("SET1: Unable to open /sys/class/gpio/gpioX/direction");
        exit(1);
    }

    if (write(fd, "out", 3) != 3) {
        perror("SET1: Error writing to /sys/class/gpio/gpioX/direction");
        exit(1);
    }

    close(fd);

}


