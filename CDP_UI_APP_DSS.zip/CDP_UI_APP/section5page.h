
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : section5page.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef SECTION5PAGE_H
#define SECTION5PAGE_H

#include <QDialog>
#include "common.h"
#include "pdustatpg.h"
#include "lcpstatuspage.h"

namespace Ui {
class Section5Page;
}

class Section5Page : public QDialog
{
    Q_OBJECT

public:
    explicit Section5Page(QWidget *parent = 0);
    ~Section5Page();

private slots:
    void on_L01_clicked();

    void on_L02_clicked();

    void on_L03_clicked();

    void on_L04_clicked();

    void on_L05_clicked();

    void on_L06_clicked();

    void on_L07_clicked();

    void on_L08_clicked();

    void on_L09_clicked();

    void on_L10_clicked();

    void on_L11_clicked();

    void on_L12_clicked();

    void on_L13_clicked();

    void on_L14_clicked();

    void on_L15_clicked();

    void on_L16_clicked();

    void on_L17_clicked();

    void on_LH1_clicked();

    void on_LH4_clicked();

private:
    Ui::Section5Page *ui;
    PDUStatPg *PduStatP;
    LCPStatusPage  *LCPStatusP;
};

#endif // SECTION5PAGE_H
