
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : section6page.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef SECTION6PAGE_H
#define SECTION6PAGE_H

#include <QDialog>
#include <QPushButton>
#include "common.h"
#include "pdustatpg.h"
#include "mcpstatuspage.h"
#include "lcpstatuspage.h"

namespace Ui {
class Section6Page;
}

class Section6Page : public QDialog
{
    Q_OBJECT

public:
    explicit Section6Page(QWidget *parent = 0);
    ~Section6Page();

private slots:
    void on_R01_clicked();

    void on_R02_clicked();

    void on_R03_clicked();

    void on_R04_clicked();

    void on_R05_clicked();

    void on_R06_clicked();

    void on_R07_clicked();

    void on_R08_clicked();

    void on_R09_clicked();

    void on_R10_clicked();

    void on_R11_clicked();

    void on_R12_clicked();

    void on_R13_clicked();

    void on_R14_clicked();

    void on_R15_clicked();

    void on_R16_clicked();

    void on_R17_clicked();

    void on_RH1_clicked();

    void on_RH2_clicked();

private:
    Ui::Section6Page *ui;
    PDUStatPg *PduStatP;
    LCPStatusPage  *LCPStatusP;
};

#endif // SECTION6PAGE_H
