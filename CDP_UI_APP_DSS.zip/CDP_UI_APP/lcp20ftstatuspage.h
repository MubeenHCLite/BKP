
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : lcp20ftstatuspage.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef LCP20FTSTATUSPAGE_H
#define LCP20FTSTATUSPAGE_H

#include <QDialog>

namespace Ui {
class LCP20FTStatusPage;
}

class LCP20FTStatusPage : public QDialog
{
    Q_OBJECT

public:
    explicit LCP20FTStatusPage(QWidget *parent = 0);
    ~LCP20FTStatusPage();

private:
    Ui::LCP20FTStatusPage *ui;
};

#endif // LCP20FTSTATUSPAGE_H
