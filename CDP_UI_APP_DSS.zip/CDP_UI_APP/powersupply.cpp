#include "powersupply.h"
#include <QDebug>

PowerSupply::PowerSupply(QObject *parent) : QThread(parent)
{

}


bool PowerSupply::InitPowerSupply(){
    int Result;
    PowerSupplyFileDesc = open(POWER_SUPPLY_DEV_PATH, O_RDWR);
    if (PowerSupplyFileDesc < 0){
            err(errno, "Tried to open '%s'", POWER_SUPPLY_DEV_PATH);
            return false;
    }

    Result = ioctl(PowerSupplyFileDesc, I2C_SLAVE, POWER_SUPPLY_SLAVE_ADD);
    if (Result < 0){
            err(errno, "Tried to set device address '0x%02x'", POWER_SUPPLY_SLAVE_ADD);
            return false;
    }
    return true;
}


void PowerSupply::run(){
    uint8_t Buffer[2];

    if(write(PowerSupplyFileDesc, BUS_VOLTAGE_REG_ADD, 1) != 1){
            perror("Unable to request for Bus Vol");
            exit(1);
    }

    usleep(20000);
    if(read(PowerSupplyFileDesc, Buffer, 2) != 2){
            perror("Unable to Read Bus Vol");
            exit(1);
    }
    usleep(20000);
    BusVoltage = 3.125*(Buffer[1] | (((uint16_t)Buffer[0]) << 8));
    qDebug() << "Read Bus Voltage " << BusVoltage;
}
