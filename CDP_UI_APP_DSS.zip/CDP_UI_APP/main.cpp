/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : main.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : main function of the CDP OPSW. Creates thread for CAN Message
 *                processing and Initializes the UI display.
 *
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */
#include "cdpmainw.h"
#include "canreadwrite.h"
#include <QApplication>
#include <QList>

#include "common.h"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    CDPMAINW w;
    w.show();

//    CANReadWrite canReadWrite;
//    canReadWrite.start();

    return a.exec();
}
