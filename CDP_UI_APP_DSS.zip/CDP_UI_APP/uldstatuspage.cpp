#include "uldstatuspage.h"
#include "ui_uldstatuspage.h"
#include <QDebug>
#include <QLabel>
#include <QString>
#include "common.h"


static QLabel*             PIndication[116];
static int PHt = 30;
static int PWt = 15;

ULD_Status _ULD[20];

int PXCord[116] = {1700,1668,1636,1604,1572,1540,1508,1476,
                     1444,1412,1380,1348,1316,1284,1252,1220,
                     1188,1156,1124,1092,1060,1028,996,964,932,
                     900,868,836,804,772,740,708,676,644,612,
                     580,548,516,484,452,420,388,356,324,292,260,
                     228,196,164,132,650,600,550,500,450,400,500,430,400,
                     1700,1668,1636,1604,1572,1540,1508,1476,
                      1444,1412,1380,1348,1316,1284,1252,1220,
                      1188,1156,1124,1092,1060,1028,996,964,932,
                      900,868,836,804,772,740,708,676,644,612,
                      580,548,516,484,452,420,388,356,324,292,260,
                      228,196,164,132,650,600,550,500,450,425,400};

int PYCord[116] = {190,190,190,190,190,190,190,190,190,190,190,
                     190,190,190,190,190,190,190,190,190,190,190,190,
                     190,190,190,190,190,190,190,190,190,190,190,190,
                     190,190,190,190,190,190,190,190,190,190,190,190,190,
                     190,190,230,230,230,230,230,230,150,150,150,330,330,
                     330,330,330,330,330,330,330,330,330,
                     330,330,330,330,330,330,330,330,330,330,330,330,330,
                     330,330,330,330,330,330,330,330,330,330,330,330,330,
                     330,330,330,330,330,330,330,330,330,330,330,330,330,
                     280,280,280,280,280,280,280};

ULDStatusPage::ULDStatusPage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ULDStatusPage)
{
    ui->setupUi(this);
    qDebug() << "ULD Status Page";
    //set the main page background
    QPixmap Background(BaseFolder + "ULDStatusPage.png");
    Background = Background.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette Palette;
    Palette.setBrush(QPalette::Window, Background);
    this->setPalette(Palette);

    BackButton = new QPushButton("", this);
    BackButton->setGeometry(QRect(QPoint(ULD_BK_BTN_X, ULD_BK_BTN_Y), QSize(ULD_BK_BTN_WT, ULD_BK_BTN_HT)));
    QPixmap BackButtonBkg(BaseFolder + "BackButton.png");
    QIcon BackButtonIcon(BackButtonBkg.scaled(ULD_BK_BTN_WT, ULD_BK_BTN_HT,Qt::KeepAspectRatio));
    BackButton->setIcon(BackButtonIcon);
    BackButton->setIconSize(BackButtonBkg.rect().size());
    connect(BackButton, &QPushButton::released, this, &ULDStatusPage::HandleBackButton);

    int Pos;
    for(Pos = 0; Pos < PDU_MAX_COUNT  ; Pos++){
            PIndication[Pos] = new QLabel(this);
            PIndication[Pos]->setFrameStyle(QFrame::Panel);

            PIndication[Pos]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
            PIndication[Pos]->setGeometry(QRect(PXCord[Pos],PYCord[Pos],PWt,PHt));
            PIndication[Pos]->setPixmap(QPixmap(PDUGreyP).scaled(PWt, PHt, Qt::KeepAspectRatio));
    }

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(UpdateUI()));
    timer->setInterval(ONE_MS);
    timer->start();
}

void ULDStatusPage::UpdateUI()
{
    qDebug() << "Update ULD Screen";
    int Pos,UldNo;

    for(Pos = 0; Pos < PDU_MAX_COUNT  ; Pos++){
            PIndication[Pos]->setPixmap(QPixmap(PDUGreyP).scaled(PWt, PHt, Qt::KeepAspectRatio));
    }

    for(UldNo = 0; UldNo < 19; UldNo++){
        //Update ULD Position
        //Based on the size of ULD size
        //Update tPDU covered status
        for(Pos = (int)(_ULD[UldNo].Signal.ULD_LH_Trailing_Edge_PDU); Pos < _ULD[UldNo].Signal.ULD_RH_Leading_Edge_PDU  ; Pos++){
                PIndication[Pos]->setPixmap(QPixmap(PDUGreenP).scaled(PWt, PHt, Qt::KeepAspectRatio));
        }

        for(Pos = (int)(_ULD[UldNo].Signal.ULD_LH_Trailing_Edge_PDU); Pos < _ULD[UldNo].Signal.ULD_LH_Leading_Edge_PDU  ; Pos++){
                PIndication[Pos]->setPixmap(QPixmap(PDUGreenP).scaled(PWt, PHt, Qt::KeepAspectRatio));
        }

        //Update ULD Status Table
        ui->ULDStatusTable->setItem(ROW1, UldNo+1,new QTableWidgetItem(QString::number(_ULD[UldNo].Signal.ULD_type)));
        ui->ULDStatusTable->setItem(ROW2, UldNo+1,new QTableWidgetItem(QString::number(_ULD[UldNo].Signal.ULD_SW_Latch)));
        ui->ULDStatusTable->setItem(ROW3, UldNo+1,new QTableWidgetItem(QString::number(_ULD[UldNo].Signal.ULD_Size)));
        ui->ULDStatusTable->setItem(ROW4, UldNo+1,new QTableWidgetItem(QString::number(_ULD[UldNo].Signal.ULD_LH_Lagging_Edge_PDU)));
        ui->ULDStatusTable->setItem(ROW5, UldNo+1,new QTableWidgetItem(QString::number(_ULD[UldNo].Signal.ULD_RH_Leading_Edge_PDU)));
        ui->ULDStatusTable->setItem(ROW6, UldNo+1,new QTableWidgetItem(QString::number(_ULD[UldNo].Signal.ULD_LH_Trailing_Edge_PDU)));
        ui->ULDStatusTable->setItem(ROW7, UldNo+1,new QTableWidgetItem(QString::number(_ULD[UldNo].Signal.ULD_RH_Trailing_Edge_PDU)));
        ui->ULDStatusTable->setItem(ROW8, UldNo+1,new QTableWidgetItem(QString::number(_ULD[UldNo].Signal.ULD_LH_Next_PDU)));
        ui->ULDStatusTable->setItem(ROW1, UldNo+1,new QTableWidgetItem(QString::number(_ULD[UldNo].Signal.ULD_RH_Next_PDU)));
        ui->ULDStatusTable->setItem(ROW1, UldNo+1,new QTableWidgetItem(QString::number(_ULD[UldNo].Signal.ULD_LH_Lagging_Edge_PDU)));
        ui->ULDStatusTable->setItem(ROW1, UldNo+1,new QTableWidgetItem(QString::number(_ULD[UldNo].Signal.ULD_RH_Lagging_Edge_PDU)));
        ui->ULDStatusTable->setItem(ROW1, UldNo+1,new QTableWidgetItem(QString::number(_ULD[UldNo].Signal.ULD_Movement)));

    }
    timer->setInterval(ONE_SEC);
}


void ULDStatusPage::HandleBackButton(){
    PrevPage = DSS;
    CurrPage = MAINT;
    hide();
}

ULDStatusPage::~ULDStatusPage()
{
    delete ui;
}
