#include "swversionw.h"
#include "ui_swversionw.h"

SWVersionW::SWVersionW(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SWVersionW)
{
    ui->setupUi(this);
}

SWVersionW::~SWVersionW()
{
    delete ui;
}
