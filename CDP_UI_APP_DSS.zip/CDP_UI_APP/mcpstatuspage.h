
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : mcptstatuspage.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef MCPSTATUSPAGE_H
#define MCPSTATUSPAGE_H

#include <QDialog>
#include <QTimer>
#include <QPushButton>
#include <QDebug>
#include <QString>

/********************* PREPROCESSOR DIRECTIVES  *****************************/

#define MCP_BK_BTN_WT       80
#define MCP_BK_BTN_HT       80
#define MCP_BK_BTN_X        60
#define MCP_BK_BTN_Y        40

namespace Ui {
class MCPStatusPage;
}

class MCPStatusPage : public QDialog
{
    Q_OBJECT

public:
    explicit MCPStatusPage(QWidget *parent = 0);
    ~MCPStatusPage();
    QString     CPName;

private slots:
    void UpdateUI();
    void HandleBackButton();

private:
    Ui::MCPStatusPage *ui;
    QTimer *timer;
    QPushButton             *BackButton;
};

#endif // MCPSTATUSPAGE_H
