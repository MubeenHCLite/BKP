
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : section2page.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef SECTION2PAGE_H
#define SECTION2PAGE_H

#include <QDialog>
#include <QPushButton>
#include "common.h"
#include "pdustatpg.h"
#include "mcpstatuspage.h"
#include "ocpstatuspage.h"

namespace Ui {
class Section2Page;
}

class Section2Page : public QDialog
{
    Q_OBJECT

public:
    explicit Section2Page(QWidget *parent = 0);
    ~Section2Page();

private slots:
    void on_ICP_clicked();

    void on_R50_clicked();

    void on_R49_clicked();

    void on_R48_clicked();

    void on_R47_clicked();

    void on_R46_clicked();

    void on_R45_clicked();

    void on_R44_clicked();

    void on_R43_clicked();

    void on_R42_clicked();

    void on_R41_clicked();

    void on_R40_clicked();

    void on_R39_clicked();

    void on_R38_clicked();

    void on_R37_clicked();

    void on_R36_clicked();

    void on_R35_clicked();

    void on_R34_clicked();

    void on_TR01_clicked();

    void on_TR02_clicked();

    void on_TR03_clicked();

    void on_TR04_clicked();

    void on_TR05_clicked();

    void on_TR06_clicked();

    void on_TR07_clicked();

private:
    Ui::Section2Page *ui;
    PDUStatPg *PduStatP;
    MCPStatusPage   *MCPStatP;
};

#endif // SECTION2PAGE_H
