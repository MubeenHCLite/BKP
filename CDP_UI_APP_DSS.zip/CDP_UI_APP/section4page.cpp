/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : section4page.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : Provides implementation of Access sections, listing all the LRUs
 *                (CPs and PDUs). Implementation of Navigation to Status page of
 *                the LRUs listed in the section.
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "section4page.h"
#include "ui_section4page.h"

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the Section Page application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
Section4Page::Section4Page(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Section4Page)
{
    ui->setupUi(this);
    LCPStatusP = new LCPStatusPage(this);
        PduStatP = new PDUStatPg(this);
}

Section4Page::~Section4Page()
{
    delete ui;
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Respective LRU Status screens
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void Section4Page::on_RH4_clicked()
{
    LCPStatusP->LCPName = "LCP 4RH";
    LCPStatusP->LCPNum = LCP4RH;
    CurrPage = OCP_STATUS;
    PrevPage = ACC_ZONE;
    LCPStatusP->show();

}

void Section4Page::on_R18_clicked()
{
    PduStatP->PDUNum = 92;
    PduStatP->PDUName = "PDU R 18";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R19_clicked()
{
    PduStatP->PDUNum = 91;
    PduStatP->PDUName = "PDU R 19";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R20_clicked()
{
    PduStatP->PDUNum = 90;
    PduStatP->PDUName = "PDU R 20";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R21_clicked()
{
    PduStatP->PDUNum = 89;
    PduStatP->PDUName = "PDU R 21";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R22_clicked()
{
    PduStatP->PDUNum = 88;
    PduStatP->PDUName = "PDU R 22";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R23_clicked()
{
    PduStatP->PDUNum = 87;
    PduStatP->PDUName = "PDU R 23";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R24_clicked()
{
    PduStatP->PDUNum = 86;
    PduStatP->PDUName = "PDU R 24";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R25_clicked()
{
    PduStatP->PDUNum = 85;
    PduStatP->PDUName = "PDU R 25";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R26_clicked()
{
    PduStatP->PDUNum = 84;
    PduStatP->PDUName = "PDU R 26";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R27_clicked()
{
    PduStatP->PDUNum = 83;
    PduStatP->PDUName = "PDU R 27";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R28_clicked()
{
    PduStatP->PDUNum = 82;
    PduStatP->PDUName = "PDU R 28";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R29_clicked()
{
    PduStatP->PDUNum = 81;
    PduStatP->PDUName = "PDU R 29";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R30_clicked()
{
    PduStatP->PDUNum = 80;
    PduStatP->PDUName = "PDU R 30";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R31_clicked()
{
    PduStatP->PDUNum = 79;
    PduStatP->PDUName = "PDU R 31";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R32_clicked()
{
    PduStatP->PDUNum = 78;
    PduStatP->PDUName = "PDU R 32";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_R33_clicked()
{
    PduStatP->PDUNum = 77;
    PduStatP->PDUName = "PDU R 33";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section4Page::on_RH3_clicked()
{
    LCPStatusP->LCPName = "LCP 3RH";
    LCPStatusP->LCPNum = LCP3RH;
    CurrPage = OCP_STATUS;
    PrevPage = ACC_ZONE;
    LCPStatusP->show();
}
