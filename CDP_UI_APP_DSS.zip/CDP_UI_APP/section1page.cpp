/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : section1page.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : Provides implementation of Access sections, listing all the LRUs
 *                (CPs and PDUs). Implementation of Navigation to Status page of
 *                the LRUs listed in the section.
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "section1page.h"
#include "ui_section1page.h"
#include "common.h"
#include <QDebug>

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the Section Page application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
Section1Page::Section1Page(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Section1Page)
{
    ui->setupUi(this);
    qDebug() << "Section 1 Page";
    PduStatP = new PDUStatPg(this);
    MCPStatP = new MCPStatusPage(this);
    OCPStatP = new OCPStatusPage(this);

}

Section1Page::~Section1Page()
{
    delete ui;
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Respective LRU Status screens
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void Section1Page::on_L50_clicked()
{
    PduStatP->PDUNum = 49;
    PduStatP->PDUName = "PDU L 50";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section1Page::on_L49_clicked()
{
    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;

    PduStatP->PDUNum = 48;
    PduStatP->PDUName = "PDU L 49";
    PduStatP->show();
}

void Section1Page::on_L48_clicked()
{
    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;

    PduStatP->PDUNum = 47;
    PduStatP->PDUName = "PDU L 48";
    PduStatP->show();
}

void Section1Page::on_L47_clicked()
{
    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;

    PduStatP->PDUNum = 46;
    PduStatP->PDUName = "PDU L 47";
    PduStatP->show();
}

void Section1Page::on_L46_clicked()
{
    PduStatP->PDUNum = 45;
    PduStatP->PDUName = "PDU L 46";
    PduStatP->show();
}

void Section1Page::on_L45_clicked()
{
    PduStatP->PDUNum = 44;
    PduStatP->PDUName = "PDU L 45";
    PduStatP->show();
}

void Section1Page::on_L44_clicked()
{
    PduStatP->PDUNum = 43;
    PduStatP->PDUName = "PDU L 44";
    PduStatP->show();
}

void Section1Page::on_L43_clicked()
{
    PduStatP->PDUNum = 42;
    PduStatP->PDUName = "PDU L 43";
    PduStatP->show();
}

void Section1Page::on_L42_clicked()
{
    PduStatP->PDUNum = 41;
    PduStatP->PDUName = "PDU L 42";
    PduStatP->show();
}

void Section1Page::on_L41_clicked()
{
    PduStatP->PDUNum = 40;
    PduStatP->PDUName = "PDU L 41";
    PduStatP->show();
}

void Section1Page::on_L40_clicked()
{
    PduStatP->PDUNum = 39;
    PduStatP->PDUName = "PDU L 40";
    PduStatP->show();
}

void Section1Page::on_L39_clicked()
{
    PduStatP->PDUNum = 38;
    PduStatP->PDUName = "PDU L 39";
    PduStatP->show();
}

void Section1Page::on_L38_clicked()
{
    PduStatP->PDUNum = 37;
    PduStatP->PDUName = "PDU L 38";
    PduStatP->show();
}

void Section1Page::on_L37_clicked()
{
    PduStatP->PDUNum = 36;
    PduStatP->PDUName = "PDU L 37";
    PduStatP->show();
}

void Section1Page::on_L36_clicked()
{
    PduStatP->PDUNum = 35;
    PduStatP->PDUName = "PDU L 36";
    PduStatP->show();
}

void Section1Page::on_L35_clicked()
{
    PduStatP->PDUNum = 34;
    PduStatP->PDUName = "PDU L 35";
    PduStatP->show();
}

void Section1Page::on_L34_clicked()
{
    PduStatP->PDUNum = 33;
    PduStatP->PDUName = "PDU L 34";
    PduStatP->show();
}

void Section1Page::on_TL01_clicked()
{
    PduStatP->PDUNum = 50;
    PduStatP->PDUName = "PDU T L 01";
    PduStatP->show();
}

void Section1Page::on_TL02_clicked()
{
    PduStatP->PDUNum = 51;
    PduStatP->PDUName = "PDU T L 02";
    PduStatP->show();
}

void Section1Page::on_TL03_clicked()
{
    PduStatP->PDUNum =52;
    PduStatP->PDUName = "PDU T L 03";
    PduStatP->show();
}

void Section1Page::on_TL04_clicked()
{
    PduStatP->PDUNum = 53;
    PduStatP->PDUName = "PDU T L 04";
    PduStatP->show();
}

void Section1Page::on_TL05_clicked()
{
    PduStatP->PDUNum = 54;
    PduStatP->PDUName = "PDU T L 05";
    PduStatP->show();
}

void Section1Page::on_TL07_clicked()
{
    PduStatP->PDUNum = 55;
    PduStatP->PDUName = "PDU T L 07";
    PduStatP->show();
}

void Section1Page::on_TL08_clicked()
{
    PduStatP->PDUNum = 56;
    PduStatP->PDUName = "PDU T L 08";
    PduStatP->show();
}

void Section1Page::on_TL09_clicked()
{
    PduStatP->PDUNum = 57;
    PduStatP->PDUName = "PDU T L 09";
    PduStatP->show();
}

void Section1Page::on_TL10_clicked()
{
    PduStatP->PDUNum = 58;
    PduStatP->PDUName = "PDU T L 02";
    PduStatP->show();
}

void Section1Page::on_TL10_3_clicked()
{
    MCPStatP->CPName = "MCP";
    CurrPage = MCP_STATUS;
    PrevPage = ACC_ZONE;
    MCPStatP->show();
}

void Section1Page::on_OCPB_clicked()
{
    CurrPage = OCP_STATUS;
    PrevPage = ACC_ZONE;
    OCPStatP->show();
}
