/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : ocptstatuspage.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : The CDP OPSW to manage all fields in the OCP status display
 *                Provides tabular information on the status of the CP Signals
 *
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "ocpstatuspage.h"
#include "ui_ocpstatuspage.h"
#include "common.h"

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the OCP Status application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
OCPStatusPage::OCPStatusPage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OCPStatusPage)
{
    ui->setupUi(this);

    QPixmap Background(BaseFolder + "OCPStatusPgBkg.png");
    Background = Background.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette Palette;
    Palette.setBrush(QPalette::Window, Background);
    this->setPalette(Palette);

    BackButton = new QPushButton("", this);
    BackButton->setGeometry(QRect(QPoint(OCP_BK_BTN_X, OCP_BK_BTN_Y), QSize(OCP_BK_BTN_WT, OCP_BK_BTN_HT)));
    QPixmap BackButtonBkg(BaseFolder + "BackButton.png");
    QIcon BackButtonIcon(BackButtonBkg.scaled(OCP_BK_BTN_WT, OCP_BK_BTN_HT,Qt::KeepAspectRatio));
    BackButton->setIcon(BackButtonIcon);
    BackButton->setIconSize(BackButtonBkg.rect().size());
    connect(BackButton, &QPushButton::released, this, &OCPStatusPage::HandleBackButton);


    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(UpdateUI()));
    timer->setInterval(ONE_MS);
    timer->start();
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Cont Monitoring screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void OCPStatusPage::HandleBackButton(){
    CurrPage = PrevPage;
    PrevPage = OCP_STATUS;
    hide();
}

/*-----------------------------------------------------------------------------
 *  Description : Implementation of continous indicators update on the screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void OCPStatusPage::UpdateUI()
{
    ui->OCPTable1->setItem(ROW0, COLUMN1, new QTableWidgetItem("OCP"));
    if(CurrPage == OCP_STATUS){
         //ON/OFF Indicator
        if(_OCP.Command.Signal.OCP_PB_Power_On_Off == TRUE){
            //Set to Invalid
            ui->OCPTable1->setItem(ROW1, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_OCP.Status.Signal.PB_On_Off_LED == TRUE){
            //Set to ON
            ui->OCPTable1->setItem(ROW1, COLUMN1, new QTableWidgetItem("ON"));
        }
        else if(_OCP.Status.Signal.PB_On_Off_LED == FALSE){
            //Set to OFF
            ui->OCPTable1->setItem(ROW1, COLUMN1, new QTableWidgetItem("OFF"));
        }

        //Zone Indicator
        if((_OCP.Command.Signal.OCP_PB_Zone_Select_AFT == TRUE &&
             _OCP.Command.Signal.OCP_PB_Zone_Select_AFT_Fault == TRUE) ||
            (_OCP.Command.Signal.OCP_PB_Zone_Select_FWD== TRUE &&
             _OCP.Command.Signal.OCP_PB_Zone_Select_FWD_Fault == TRUE) ||
            (_OCP.Command.Signal.OCP_PB_Zone_Select_AFT == TRUE &&
             _OCP.Command.Signal.OCP_PB_Zone_Select_FWD== TRUE )){
                //Set to Invalid
            ui->OCPTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        if(_OCP.Command.Signal.OCP_PB_Zone_Select_AFT == TRUE){
            //Set to AFT
            ui->OCPTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("AF"));
        }
        else if(_OCP.Command.Signal.OCP_PB_Zone_Select_FWD == TRUE){
            //Set to FWD
            ui->OCPTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("FWD"));
        }

        //PDU STOP indicator
/*        if(_OCP.Command.Signal.OCP_PB_PDU_Stop_Fault == TRUE){
            //Set to Invlaid
            ui->OCPTable1->setItem(ROW10, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_OCP.Command.Signal.OCP_PB_PDU_Stop == TRUE){
            //Set to ON
            ui->OCPTable1->setItem(ROW10, COLUMN1, new QTableWidgetItem("ON"));
        }
        else if(_OCP.Command.Signal.OCP_PB_PDU_Stop == FALSE){
            //Set to OFF
            ui->OCPTable1->setItem(ROW10, COLUMN1, new QTableWidgetItem("OFF"));
        }

        //System Active Indicator
        if(_OCP.Command.Signal.OCP_LED_System_Active_Fault == TRUE){
            //Set to Invalid
            ui->OCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("ON"));
        }
        else if(_OCP.Status.Signal.LED_System_Active == TRUE){
            //Set to ON
            ui->OCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Active"));
        }
        else if(_OCP.Status.Signal.LED_System_Active == FALSE){
            //Set to OFF
            ui->OCPTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Inactive"));
        }
*/
        //20Ft Indicator
        if(_OCP.Command.Signal.OCP_PB_20FT_Fault == TRUE){
                    //Set to Invlaid
            ui->OCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("ON"));
        }
        else if(_OCP.Command.Signal.OCP_PB_20FT == TRUE){
            //Set to Enabled
            ui->OCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("Enabled"));
        }
        else if(_OCP.Command.Signal.OCP_PB_20FT == FALSE){
            //Set to Disabled
            ui->OCPTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("Disabled"));
        }

        //Dual OPerator Indicator
        if(_OCP.Command.Signal.OCP_PB_Dual_Operator_Fault== TRUE){
                    //Set to Invlaid
            ui->OCPTable1->setItem(ROW6, COLUMN1, new QTableWidgetItem("ON"));
        }
        else if(_OCP.Command.Signal.OCP_PB_Dual_Operator == TRUE){
            //Set to Enabled
            ui->OCPTable1->setItem(ROW6, COLUMN1, new QTableWidgetItem("Enabled"));
        }
        else if(_OCP.Command.Signal.OCP_PB_Dual_Operator == FALSE){
            //Set to Disabled
            ui->OCPTable1->setItem(ROW6, COLUMN1, new QTableWidgetItem("Disabled"));
        }

        //20FT IN OUT Indicator
        if(_OCP.Command.Signal.OCP_TGLS_20FT_Fault== TRUE){
                    //Set to Invlaid
            ui->OCPTable1->setItem(ROW7, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_OCP.Command.Signal.OCP_TGLS_20FT_IN == TRUE){
            //Set to IN
            ui->OCPTable1->setItem(ROW7, COLUMN1, new QTableWidgetItem("IN"));
        }
        else if(_OCP.Command.Signal.OCP_TGLS_20FT_OUT == TRUE){
            //Set to Out
            ui->OCPTable1->setItem(ROW7, COLUMN1, new QTableWidgetItem("OUT"));
        }

        //TGL SW FWD/AFT Indicator
        if(_OCP.Command.Signal.OCP_TGLS_L_R_Fault== TRUE){
                    //Set to Invlaid
            ui->OCPTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("Invalid"));
        }
        else if(_OCP.Command.Signal.OCP_TGLS_L_R_AFT == TRUE){
            //Set to AFT
            ui->OCPTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("AFT"));
        }
        else if(_OCP.Command.Signal.OCP_TGLS_L_R_FWD == TRUE){
            //Set to FWD
            ui->OCPTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("FWD"));
        }

        //TGL SW IN/OUT Indicator
        if(_OCP.Command.Signal.OCP_TGLS_IN_OUT_Fault== TRUE){
                    //Set to Invlaid
            ui->OCPTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("Inavlid"));
        }
        else if(_OCP.Command.Signal.OCP_TGLS_IN_OUT_IN == TRUE){
            //Set to IN
            ui->OCPTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("IN"));
        }
        else if(_OCP.Command.Signal.OCP_TGLS_IN_OUT_OUT == TRUE){
            //Set to OUT
            ui->OCPTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("OUT"));
        }

        //SIDE Select Indicator
        if((_OCP.Command.Signal.OCP_PB_Side_Select_Left == TRUE &&
             _OCP.Command.Signal.OCP_PB_Side_Select_Left_Fault  == TRUE) ||
            (_OCP.Command.Signal.OCP_PB_Side_Select_Right == TRUE &&
             _OCP.Command.Signal.OCP_PB_Side_Select_Right_Fault  == TRUE)){
            //Set to Invalid
            ui->OCPTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("Inavlid"));
        }
        else if(_OCP.Command.Signal.OCP_PB_Side_Select_Left == TRUE &&
                _OCP.Command.Signal.OCP_PB_Side_Select_Right == TRUE){
            //Set to Both
            ui->OCPTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("Both"));
        }
        else if(_OCP.Command.Signal.OCP_PB_Side_Select_Right == TRUE){
            //Set to Right
            ui->OCPTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("Right"));
        }
        else if(_OCP.Command.Signal.OCP_PB_Side_Select_Left == TRUE ){
            //Set to Left
            ui->OCPTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("Left"));
        }

        ui->OCPTable1->setItem(ROW12, COLUMN1, new QTableWidgetItem(QString::number(_OCP.Command.Signal.OCP_Mux_Current_Voltage)));
        ui->OCPTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem(QString::number(_OCP.Command.Signal.OCP_Measured_Current_Voltage)));

        //OCP Switch Fault
/*        if(_OCP.Command.Signal.OCP_Switch_Fault_Status == TRUE){
            ui->OCPTable2->setItem(ROW0, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW0, COLUMN1, new QTableWidgetItem("False"));
        }
*/
        //Power On off Fault
        if(_OCP.Command.Signal.OCP_PB_Power_On_Off_Fault == TRUE){
            ui->OCPTable2->setItem(ROW1, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW1, COLUMN1, new QTableWidgetItem("False"));
        }

        //PDU Stop Fault
/*        if(_OCP.Command.Signal.OCP_PB_PDU_Stop_Fault == TRUE){
            ui->OCPTable2->setItem(ROW2, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW2, COLUMN1, new QTableWidgetItem("False"));
        }
*/
        //Side Select Left
        if(_OCP.Command.Signal.OCP_PB_Side_Select_Left_Fault == TRUE){
            ui->OCPTable2->setItem(ROW3, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW3, COLUMN1, new QTableWidgetItem("False"));
        }

        //Side Select Right
        if(_OCP.Command.Signal.OCP_PB_Side_Select_Right_Fault == TRUE){
            ui->OCPTable2->setItem(ROW4, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW4, COLUMN1, new QTableWidgetItem("False"));
        }

        //Zone Select AFT
        if(_OCP.Command.Signal.OCP_PB_Zone_Select_AFT_Fault == TRUE){
            ui->OCPTable2->setItem(ROW5, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW5, COLUMN1, new QTableWidgetItem("False"));
        }

        //Zone Select FWD
        if(_OCP.Command.Signal.OCP_PB_Zone_Select_FWD_Fault == TRUE){
            ui->OCPTable2->setItem(ROW6, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW6, COLUMN1, new QTableWidgetItem("False"));
        }

        //TGL 20FT Switch
        if(_OCP.Command.Signal.OCP_TGLS_20FT_Fault == TRUE){
            ui->OCPTable2->setItem(ROW7, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW7, COLUMN1, new QTableWidgetItem("False"));
        }

        //Dual Operator
        if(_OCP.Command.Signal.OCP_PB_Dual_Operator_Fault == TRUE){
            ui->OCPTable2->setItem(ROW8, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW8, COLUMN1, new QTableWidgetItem("False"));
        }

        //20FT
        if(_OCP.Command.Signal.OCP_PB_20FT_Fault == TRUE){
            ui->OCPTable2->setItem(ROW9, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW9, COLUMN1, new QTableWidgetItem("False"));
        }

        //TGL Switch IN/OUT
        if(_OCP.Command.Signal.OCP_TGLS_IN_OUT_Fault == TRUE){
            ui->OCPTable2->setItem(ROW10, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW10, COLUMN1, new QTableWidgetItem("False"));
        }

        //TGL Switch L/R
        if(_OCP.Command.Signal.OCP_TGLS_L_R_Fault == TRUE){
            ui->OCPTable2->setItem(ROW11, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW11, COLUMN1, new QTableWidgetItem("False"));
        }

        //Lamp Test
        if(_OCP.Command.Signal.OCP_PB_Lamp_Test_Fault == TRUE){
            ui->OCPTable2->setItem(ROW12, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW12, COLUMN1, new QTableWidgetItem("False"));
        }

        //LED System Active
/*        if(_OCP.Command.Signal.OCP_LED_System_Active_Fault == TRUE){
            ui->OCPTable2->setItem(ROW13, COLUMN1, new QTableWidgetItem("True"));
        }
        else {
            ui->OCPTable2->setItem(ROW13, COLUMN1, new QTableWidgetItem("False"));
        }
*/
    }

    timer->setInterval(ONE_SEC);

}

OCPStatusPage::~OCPStatusPage()
{
    delete ui;
}
