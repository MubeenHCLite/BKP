/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : section6page.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : Provides implementation of Access sections, listing all the LRUs
 *                (CPs and PDUs). Implementation of Navigation to Status page of
 *                the LRUs listed in the section.
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "section6page.h"
#include "ui_section6page.h"

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the Section Page application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
Section6Page::Section6Page(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Section6Page)
{
    ui->setupUi(this);

    qDebug() << "Section 6 Page";

    LCPStatusP = new LCPStatusPage(this);
    PduStatP = new PDUStatPg(this);
}

Section6Page::~Section6Page()
{
    delete ui;
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Respective LRU Status screens
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void Section6Page::on_R01_clicked()
{
    PduStatP->PDUNum = 60;
    PduStatP->PDUName = "PDU R 01";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R02_clicked()
{
    PduStatP->PDUNum = 61;
    PduStatP->PDUName = "PDU R 02";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R03_clicked()
{
    PduStatP->PDUNum = 62;
    PduStatP->PDUName = "PDU R 03";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R04_clicked()
{
    PduStatP->PDUNum = 63;
     PduStatP->PDUName = "PDU R 04";

     CurrPage = PDU_STATUS;
     PrevPage = ACC_ZONE;
     PduStatP->show();

}

void Section6Page::on_R05_clicked()
{
    PduStatP->PDUNum = 64;
    PduStatP->PDUName = "PDU R 05";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R06_clicked()
{
    PduStatP->PDUNum = 65;
    PduStatP->PDUName = "PDU R 06";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R07_clicked()
{
    PduStatP->PDUNum = 66;
    PduStatP->PDUName = "PDU R 07";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R08_clicked()
{
    PduStatP->PDUNum = 67;
    PduStatP->PDUName = "PDU R 08";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R09_clicked()
{
    PduStatP->PDUNum = 68;
    PduStatP->PDUName = "PDU R 09";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R10_clicked()
{
    PduStatP->PDUNum = 69;
    PduStatP->PDUName = "PDU R 10";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R11_clicked()
{
    PduStatP->PDUNum = 70;
    PduStatP->PDUName = "PDU R 11";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R12_clicked()
{
    PduStatP->PDUNum = 71;
    PduStatP->PDUName = "PDU R 12";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R13_clicked()
{
    PduStatP->PDUNum = 72;
    PduStatP->PDUName = "PDU R 13";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R14_clicked()
{
    PduStatP->PDUNum = 73;
    PduStatP->PDUName = "PDU R 14";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R15_clicked()
{
    PduStatP->PDUNum = 74;
    PduStatP->PDUName = "PDU R 15";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R16_clicked()
{
    PduStatP->PDUNum = 75;
    PduStatP->PDUName = "PDU R 16";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_R17_clicked()
{
    PduStatP->PDUNum = 76;
    PduStatP->PDUName = "PDU R 17";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section6Page::on_RH1_clicked()
{
    LCPStatusP->LCPName = "LCP 1RH";
    LCPStatusP->LCPNum = LCP1RH;
    CurrPage = OCP_STATUS;
    PrevPage = ACC_ZONE;
    LCPStatusP->show();
}

void Section6Page::on_RH2_clicked()
{
    LCPStatusP->LCPName = "LCP 2RH";
    LCPStatusP->LCPNum = LCP2RH;
    CurrPage = OCP_STATUS;
    PrevPage = ACC_ZONE;
    LCPStatusP->show();
}
