
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : section3page.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */
#ifndef SECTION3PAGE_H
#define SECTION3PAGE_H

#include <QDialog>
#include "lcpstatuspage.h"
#include "common.h"
#include "pdustatpg.h"
#include "lcpstatuspage.h"

namespace Ui {
class Section3Page;
}

class Section3Page : public QDialog
{
    Q_OBJECT

public:
    explicit Section3Page(QWidget *parent = 0);
    ~Section3Page();

private slots:
    void on_LH4_clicked();

    void on_L18_clicked();

    void on_L19_clicked();

    void on_L20_clicked();

    void on_L21_clicked();

    void on_L22_clicked();

    void on_L23_clicked();

    void on_L24_clicked();

    void on_L25_clicked();

    void on_L26_clicked();

    void on_L27_clicked();

    void on_L28_clicked();

    void on_L29_clicked();

    void on_L30_clicked();

    void on_L31_clicked();

    void on_L32_clicked();

    void on_L33_clicked();

    void on_LH3_clicked();

private:
    Ui::Section3Page *ui;
    PDUStatPg *PduStatP;
    LCPStatusPage  *LCPStatusP;
};

#endif // SECTION3PAGE_H
