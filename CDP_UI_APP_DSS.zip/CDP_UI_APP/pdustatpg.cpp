/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : pdustatuspage.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : The CDP OPSW to manage all fields in the PDU status display
 *                Provides tabular information on the status of the PDU Signals
 *
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "pdustatpg.h"
#include "ui_pdustatpg.h"
#include "common.h"
#include <QString>
#include <QDebug>

PDUStatPg::PDUStatPg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PDUStatPg)
{
    ui->setupUi(this);

    PDUNum = 0;

    qDebug() << BaseFolder + "PDUStatusPgBkg.png";

    QPixmap Background(BaseFolder + "PDUStatusPgBkg.png");
    Background = Background.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette Palette;
    Palette.setBrush(QPalette::Window, Background);
    this->setPalette(Palette);
    BackButton = new QPushButton("", this);

    BackButton->setGeometry(QRect(QPoint(PDU_BK_BTN_X, PDU_BK_BTN_Y), QSize(PDU_BK_BTN_WT, PDU_BK_BTN_HT)));
    QPixmap BackButtonBkg(BaseFolder + "BackButton.png");
    QIcon BackButtonIcon(BackButtonBkg.scaled(PDU_BK_BTN_WT, PDU_BK_BTN_HT,Qt::KeepAspectRatio));
    BackButton->setIcon(BackButtonIcon);
    BackButton->setIconSize(BackButtonBkg.rect().size());
    connect(BackButton, &QPushButton::released, this, &PDUStatPg::HandleBackButton);


    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(UpdateUI()));
    timer->setInterval(ONE_MS);
    timer->start();

}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Cont Monitoring screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void PDUStatPg::HandleBackButton(){
    CurrPage = PrevPage;
    PrevPage = PDU_STATUS;
    hide();
}

/*-----------------------------------------------------------------------------
 *  Description : Implementation of continous indicators update on the screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void PDUStatPg::UpdateUI()
{
    ui->PDUTable1->setItem(ROW0, COLUMN1, new QTableWidgetItem(PDUName));

    if(CurrPage == PDU_STATUS){
        qDebug() << "PDU Status Page";
        qDebug() << PDUNum;
        bool PDUAbnormal = FALSE;

        if(//_PDU[PDUNum].StatusMSG1.Signal.NVM_Fault == TRUE ||
            //_PDU[PDUNum].StatusMSG1.Signal.HVDC_Over_Current_Fault == TRUE ||
                _PDU[PDUNum].StatusMSG1.Signal.HVDC_Over_Voltage_Fault == TRUE ||
                _PDU[PDUNum].StatusMSG1.Signal.HVDC_Under_Voltage_Fault == TRUE ||
                _PDU[PDUNum].StatusMSG1.Signal.VAC115_Phase_Fault == TRUE ||
                _PDU[PDUNum].StatusMSG1.Signal.ATRU_Left_Coil_Over_Temperature_Fault == TRUE ||
                _PDU[PDUNum].StatusMSG1.Signal.ATRU_Right_Coil_Over_Temperature_Fault == TRUE ||
                _PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_Over_Temperature_Fault == TRUE ||
                _PDU[PDUNum].StatusMSG1.Signal.Board_Over_Temperature_Fault == TRUE ||
                _PDU[PDUNum].StatusMSG1.Signal.IGBT_Onchip_Over_Temperature_Fault == TRUE ||
                _PDU[PDUNum].StatusMSG1.Signal.IGBT_Protection_Trip == TRUE){
            //Set PDU_X Faults_Abnormal to True
           PDUAbnormal = TRUE;
        }

        //Geneal Status
        if((PDUAbnormal == FALSE && _PDU[PDUNum].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::NOT_HEALTHY) ||
                _PDU[PDUNum].StatusMSG1.Signal.PDU_State == PDU_STATE::ST_FAULTY){
            //Set General Status to Faulty
            ui->PDUTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("Faulty") );
        }
        else if(PDUAbnormal == TRUE){

            //Set General Status to Abnormal
            ui->PDUTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("Abnormal"));
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
               _PDU[PDUNum].StatusMSG3.Signal.PDU_Roller_Speed > 0 ){
            //Set General Status to Driving & Healthy
            ui->PDUTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("Driving & Healthy") );

        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY){
            //Set General Status to Healthy'
            ui->PDUTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("Healthy") );
        }
        else if(_PDU[PDUNum].StatusMSG3.Signal.PDU_Roller_Speed > 0 && PDUAbnormal == 1){
            //Set General Status toDriving and Abnormal
            ui->PDUTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("Driving & Abnormal") );
        }
        else{
             ui->PDUTable1->setItem(ROW3, COLUMN1, new QTableWidgetItem("xxxxxxx") );
        }


        //PDU Type
        if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Type == PDU_TYPE::SELF_LIFT){
            //Set to Self Lift
            ui->PDUTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Self Lift") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Type == PDU_TYPE::SPRING_LOADED){
            //Set to Spring Loaded
            ui->PDUTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("Spring Loaded") );
        }
        else {
            ui->PDUTable1->setItem(ROW2, COLUMN1, new QTableWidgetItem("xxxxxxxxx") );
        }

        //Hold/Release Indicator
        if(_PDU[PDUNum].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::HOLD_ACTIVE){
            ui->PDUTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("Hold") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE){
            ui->PDUTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("Released") );
        }
        else {
            ui->PDUTable1->setItem(ROW4, COLUMN1, new QTableWidgetItem("xxxxxxxxx") );
        }

        //Lift Status Indicator
        if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Roller_Position == PDU_ROLLER_POSITION::DEFAULT){
            ui->PDUTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("Default") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Roller_Position == PDU_ROLLER_POSITION::FULLY_LIFT){
            ui->PDUTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("Fully Lift") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Roller_Position == PDU_ROLLER_POSITION::HOME){
            ui->PDUTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("Home") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Roller_Position == PDU_ROLLER_POSITION::PARTITAL_LIFT){
            ui->PDUTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("Partial Lift") );
        }
        else {
            ui->PDUTable1->setItem(ROW5, COLUMN1, new QTableWidgetItem("xxxxxxxxx") );
        }

        //Health Status
        if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::DEFAULT){
            ui->PDUTable1->setItem(ROW6, COLUMN1, new QTableWidgetItem("Default") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::NOT_HEALTHY){
            ui->PDUTable1->setItem(ROW6, COLUMN1, new QTableWidgetItem("Not Healthy") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY){
            ui->PDUTable1->setItem(ROW6, COLUMN1, new QTableWidgetItem("Overall Healthy") );
        }
        else {
            ui->PDUTable1->setItem(ROW6, COLUMN1, new QTableWidgetItem("xxxxxxxxx") );
        }

        //Cover Status
        if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Cover_Status == PDU_COVER_STATUS::COVERED){
            ui->PDUTable1->setItem(ROW7, COLUMN1, new QTableWidgetItem("Covered") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Cover_Status == PDU_COVER_STATUS::DEFAULT){
            ui->PDUTable1->setItem(ROW7, COLUMN1, new QTableWidgetItem("Default") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Cover_Status == PDU_COVER_STATUS::NOT_COVERED){
            ui->PDUTable1->setItem(ROW7, COLUMN1, new QTableWidgetItem("Not Covered") );
        }
        else {
            ui->PDUTable1->setItem(ROW7, COLUMN1, new QTableWidgetItem("xxxxxxxxx") );
        }

        //PDU_MODE
        if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Mode == PDU_MODE::BIT_MODE){
            ui->PDUTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("BIT_MODE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Mode == PDU_MODE::DL_MODE){
            ui->PDUTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("DL_MODE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Mode == PDU_MODE::INIT_MODE){
            ui->PDUTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("INIT_MODE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Mode == PDU_MODE::OFF_MODE){
            ui->PDUTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("OFF_MODE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_Mode == PDU_MODE::OP_MODE){
            ui->PDUTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("OP_MODE") );
        }
        else {
            ui->PDUTable1->setItem(ROW8, COLUMN1, new QTableWidgetItem("xxxxxxxxx") );
        }

        //PDU State

        if(_PDU[PDUNum].StatusMSG1.Signal.PDU_State == PDU_STATE::LIFT_BRAKE){
            ui->PDUTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("PDU_ST_LIFT_BRAKE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_State == PDU_STATE::LIFT_DRIVE){
            ui->PDUTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("PDU_ST_LIFT_DRIVE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_State == PDU_STATE::LIFT_HOLD){
            ui->PDUTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("PDU_ST_LIFT_HOLD") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_State == PDU_STATE::POWERUP){
            ui->PDUTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("PDU_ST_POWER_UP") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_State == PDU_STATE::REGENERATIVE){
            ui->PDUTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("PDU_ST_REGENERATIVE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_State == PDU_STATE::RETRACT_HOLD){
            ui->PDUTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("PDU_ST_RETRACT_HOLD") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_State == PDU_STATE::STANDBY){
            ui->PDUTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("PDU_ST_STANDBY") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.PDU_State == PDU_STATE::ST_FAULTY){
            ui->PDUTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("PDU_ST_FAULTY") );
        }
        else {
            ui->PDUTable1->setItem(ROW9, COLUMN1, new QTableWidgetItem("xxxxxxxxx") );
        }

        //DMM Mode
        if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_Mode == DRIVE_MOTOR_MODE::DMM_HOLD){
            ui->PDUTable1->setItem(ROW10, COLUMN1, new QTableWidgetItem("DMM_HOLD") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_Mode == DRIVE_MOTOR_MODE::DMM_MOTOR){
            ui->PDUTable1->setItem(ROW10, COLUMN1, new QTableWidgetItem("DMM_MOTOR") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_Mode == DRIVE_MOTOR_MODE::DMM_STANDBY){
            ui->PDUTable1->setItem(ROW10, COLUMN1, new QTableWidgetItem("DMM_STANDBY") );
        }

        //LM Mode
        if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Mode == LIFT_MOTOR_MODE::LMM_IDLE){
            ui->PDUTable1->setItem(ROW11, COLUMN1, new QTableWidgetItem("LMM_IDLE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Mode == LIFT_MOTOR_MODE::LMM_MOVE){
            ui->PDUTable1->setItem(ROW11, 1, new QTableWidgetItem("LMM_MOVE") );
        }

        //DM State
        if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_State == DRIVE_MOTOR_STATE::DM_ST_CHARGE){
            ui->PDUTable1->setItem(ROW12, COLUMN1, new QTableWidgetItem("DM_ST_CHARGE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_State == DRIVE_MOTOR_STATE::DM_ST_FIX){
            ui->PDUTable1->setItem(ROW12, COLUMN1, new QTableWidgetItem("DM_ST_FIX") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_State == DRIVE_MOTOR_STATE::DM_ST_IDLE){
            ui->PDUTable1->setItem(ROW12, COLUMN1, new QTableWidgetItem("DM_ST_IDLE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_State == DRIVE_MOTOR_STATE::DM_ST_POS){
            ui->PDUTable1->setItem(ROW12, COLUMN1, new QTableWidgetItem("DM_ST_POS") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_State == DRIVE_MOTOR_STATE::DM_ST_POWERUP){
            ui->PDUTable1->setItem(ROW12, COLUMN1, new QTableWidgetItem("DM_ST_POWERUP") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_State == DRIVE_MOTOR_STATE::DM_ST_SC){
            ui->PDUTable1->setItem(ROW12, COLUMN1, new QTableWidgetItem("DM_ST_SC") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_State == DRIVE_MOTOR_STATE::DM_ST_SPEED){
            ui->PDUTable1->setItem(ROW12, COLUMN1, new QTableWidgetItem("DM_ST_SPEED") );
        }

        //LM Ctrl Seq State
        if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTLSEQ_AWAIT_CONTAINER){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTLSEQ_AWAIT_CONTAINER") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTLSEQ_BW_DRV_CTRL){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTLSEQ_BW_DRV_CTRL") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTLSEQ_BW_DRV_DONE){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTLSEQ_BW_DRV_DONE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTLSEQ_FLT_STATE){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTLSEQ_FLT_STATE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTLSEQ_HOLD_UP_HI_FORCE){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTLSEQ_HOLD_UP_HI_FORCE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTLSEQ_HOLD_UP_LOW_FORCE){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTLSEQ_HOLD_UP_LOW_FORCE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTLSEQ_HOLD_UP_MED_FORCE){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTLSEQ_HOLD_UP_MED_FORCE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTLSEQ_RAISE_FAST){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTLSEQ_RAISE_FAST") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTLSEQ_RAISE_SLOW){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTLSEQ_RAISE_SLOW") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTLSEQ_RETRACTED){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTLSEQ_RETRACTED") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTLSEQ_RETRACTING_FAST){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTLSEQ_RETRACTING_FAST") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTLSEQ_RETRACTING_SLOW){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTLSEQ_RETRACTING_SLOW") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTRL_SEQ_GOHOME){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTRL_SEQ_GOHOME") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Control_Seq_State == LM_CTRL_SEQ_STATE::CTRL_SEQ_POWERUP){
            ui->PDUTable1->setItem(ROW13, COLUMN1, new QTableWidgetItem("CTRL_SEQ_POWERUP") );
        }

        //LM State
        if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_State == LIFT_MOTOR_STATE::LMM_MOVING){
            ui->PDUTable1->setItem(ROW14, COLUMN1, new QTableWidgetItem("LMM_MOVING") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_State == LIFT_MOTOR_STATE::LMM_ST_CHARGE){
            ui->PDUTable1->setItem(ROW14, COLUMN1, new QTableWidgetItem("LMM_ST_CHARGE") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_State == LIFT_MOTOR_STATE::LMM_ST_IDLE){
            ui->PDUTable1->setItem(ROW14, COLUMN1, new QTableWidgetItem("LMM_ST_IDLE") );
        }

        //Active Direction
        if(_PDU[PDUNum].StatusMSG1.Signal.Active_Drive_Command_Direction== PDU_DRIVE_COMMAND_DIR::DEFAULT){
            ui->PDUTable1->setItem(ROW15, COLUMN1, new QTableWidgetItem("DEFAULT") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Active_Drive_Command_Direction== PDU_DRIVE_COMMAND_DIR::DIR_A){
            ui->PDUTable1->setItem(ROW15, COLUMN1, new QTableWidgetItem("DIR_A") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Active_Drive_Command_Direction== PDU_DRIVE_COMMAND_DIR::DIR_B){
            ui->PDUTable1->setItem(ROW15, COLUMN1, new QTableWidgetItem("DIR_B") );
        }

        //DM Curr Fault Mon Status
        if(_PDU[PDUNum].StatusMSG1.Signal.DM_Current_Fault_Monitoring_Status== TRUE){
            ui->PDUTable1->setItem(ROW16, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.DM_Current_Fault_Monitoring_Status== FALSE){
            ui->PDUTable1->setItem(ROW16, COLUMN1, new QTableWidgetItem("False") );
        }

        //LM Curr Fault Mon Status
        if(_PDU[PDUNum].StatusMSG1.Signal.LM_Current_Fault_Monitoring_Status == TRUE){
            ui->PDUTable1->setItem(ROW17, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.LM_Current_Fault_Monitoring_Status == FALSE){
            ui->PDUTable1->setItem(ROW17, COLUMN1, new QTableWidgetItem("False") );
        }

        //HVDC Over Voltage
        if(_PDU[PDUNum].StatusMSG1.Signal.HVDC_Over_Voltage_Fault == TRUE){
            ui->PDUTable2->setItem(ROW0, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.HVDC_Over_Voltage_Fault == FALSE){
            ui->PDUTable2->setItem(ROW0, COLUMN1, new QTableWidgetItem("False") );
        }

        //HVDC Under Voltage
        if(_PDU[PDUNum].StatusMSG1.Signal.HVDC_Under_Voltage_Fault == TRUE){
            ui->PDUTable2->setItem(ROW1, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.HVDC_Under_Voltage_Fault == FALSE){
            ui->PDUTable2->setItem(ROW1, COLUMN1, new QTableWidgetItem("False") );
        }

        //IGBT Protection Trip
        if(_PDU[PDUNum].StatusMSG1.Signal.IGBT_Protection_Trip == TRUE){
            ui->PDUTable2->setItem(ROW2, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.IGBT_Protection_Trip == FALSE){
            ui->PDUTable2->setItem(ROW2, COLUMN1, new QTableWidgetItem("False") );
        }

        //Board Over Temp
        if(_PDU[PDUNum].StatusMSG1.Signal.Board_Over_Temperature_Fault == TRUE){
            ui->PDUTable2->setItem(ROW3, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Board_Over_Temperature_Fault == FALSE){
            ui->PDUTable2->setItem(ROW3, COLUMN1, new QTableWidgetItem("False") );
        }

        //115VAC Phase
        if(_PDU[PDUNum].StatusMSG1.Signal.VAC115_Phase_Fault == TRUE){
            ui->PDUTable2->setItem(ROW4, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.VAC115_Phase_Fault == FALSE){
            ui->PDUTable2->setItem(ROW4, COLUMN1, new QTableWidgetItem("False") );
        }

        //Drive Motor Hall Sensor
        if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_Hall_Sensor_State_Error == TRUE){
            ui->PDUTable2->setItem(ROW5, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_Hall_Sensor_State_Error == FALSE){
            ui->PDUTable2->setItem(ROW5, COLUMN1, new QTableWidgetItem("False") );
        }

        //Lift Motor Hall Sensor
        if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Hall_Sensor_State_Error == TRUE){
            ui->PDUTable2->setItem(ROW6, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_Hall_Sensor_State_Error == FALSE){
            ui->PDUTable2->setItem(ROW6, COLUMN1, new QTableWidgetItem("False") );
        }

        //Drive Motor State Machine
        if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_State_Machine_Error == TRUE){
            ui->PDUTable2->setItem(ROW7, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_State_Machine_Error == FALSE){
            ui->PDUTable2->setItem(ROW7, COLUMN1, new QTableWidgetItem("False") );
        }

        //Lift Motor State Machine
        if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_State_Machine_Error == TRUE){
            ui->PDUTable2->setItem(ROW8, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Motor_State_Machine_Error == FALSE){
            ui->PDUTable2->setItem(ROW8, COLUMN1, new QTableWidgetItem("False") );
        }

        //Lift Mechanism
        if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Mechanism_Fault == TRUE){
            ui->PDUTable2->setItem(ROW9, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Lift_Mechanism_Fault == FALSE){
            ui->PDUTable2->setItem(ROW9, COLUMN1, new QTableWidgetItem("False") );
        }

        //CAN Address Pin Parity
/*        if(_PDU[PDUNum].StatusMSG1.Signal.CAN_Address_Pin_Parity_Fault == TRUE){
            ui->PDUTable2->setItem(ROW10, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.CAN_Address_Pin_Parity_Fault == FALSE){
            ui->PDUTable2->setItem(ROW10, COLUMN1, new QTableWidgetItem("False") );
        }

        //Program Integrity Check
        if(_PDU[PDUNum].StatusMSG1.Signal.Program_Integrity_Check_Fault == TRUE){
            ui->PDUTable2->setItem(ROW11, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Program_Integrity_Check_Fault == FALSE){
            ui->PDUTable2->setItem(ROW11, COLUMN1, new QTableWidgetItem("False") );
        }

        //RAM Fault
        if(_PDU[PDUNum].StatusMSG1.Signal.RAM_Fault == TRUE){
            ui->PDUTable2->setItem(ROW12, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.RAM_Fault == FALSE){
            ui->PDUTable2->setItem(ROW12, COLUMN1, new QTableWidgetItem("False") );
        }

        //NVM Fault
        if(_PDU[PDUNum].StatusMSG1.Signal.NVM_Fault == TRUE){
            ui->PDUTable2->setItem(ROW13, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.NVM_Fault == FALSE){
            ui->PDUTable2->setItem(ROW13, COLUMN1, new QTableWidgetItem("False") );
        }

        //HVDC Over Current
        if(_PDU[PDUNum].StatusMSG1.Signal.HVDC_Over_Current_Fault == TRUE){
            ui->PDUTable2->setItem(ROW14, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.HVDC_Over_Current_Fault == FALSE){
            ui->PDUTable2->setItem(ROW14, COLUMN1, new QTableWidgetItem("False") );
        }
*/
        //ATRU Right Coil Over Temp
        if(_PDU[PDUNum].StatusMSG1.Signal.ATRU_Right_Coil_Over_Temperature_Fault == TRUE){
            ui->PDUTable2->setItem(ROW15, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.ATRU_Right_Coil_Over_Temperature_Fault == FALSE){
            ui->PDUTable2->setItem(ROW15, COLUMN1, new QTableWidgetItem("False") );
        }

        //ATRU Left Coil Over Temp
        if(_PDU[PDUNum].StatusMSG1.Signal.ATRU_Left_Coil_Over_Temperature_Fault == TRUE){
            ui->PDUTable2->setItem(ROW16, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.ATRU_Left_Coil_Over_Temperature_Fault == FALSE){
            ui->PDUTable2->setItem(ROW16, COLUMN1, new QTableWidgetItem("False") );
        }

        //Drive Motor Over Temperature
        if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_Over_Temperature_Fault == TRUE){
            ui->PDUTable2->setItem(ROW17, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.Drive_Motor_Over_Temperature_Fault == FALSE){
            ui->PDUTable2->setItem(ROW17, COLUMN1, new QTableWidgetItem("False") );
        }

        //IGBT Onchip over Temperature
        if(_PDU[PDUNum].StatusMSG1.Signal.IGBT_Onchip_Over_Temperature_Fault == TRUE){
            ui->PDUTable2->setItem(ROW18, COLUMN1, new QTableWidgetItem("True") );
        }
        else if(_PDU[PDUNum].StatusMSG1.Signal.IGBT_Onchip_Over_Temperature_Fault == FALSE){
            ui->PDUTable2->setItem(ROW18, COLUMN1, new QTableWidgetItem("False") );
        }

        //Current Mux
        ui->PDUTable3->setItem(ROW0, COLUMN1, new QTableWidgetItem(QString::number(_PDU[PDUNum].StatusMSG2.Signal.Current_Mux)) );

        //Voltage Mux
        ui->PDUTable3->setItem(ROW1, COLUMN1, new QTableWidgetItem(QString::number(_PDU[PDUNum].StatusMSG2.Signal.Voltage_Mux)) );

        //Temp Mux
        ui->PDUTable3->setItem(ROW2, COLUMN1, new QTableWidgetItem(QString::number(_PDU[PDUNum].StatusMSG2.Signal.Temperature_Mux)) );

        //Measured Current
        ui->PDUTable3->setItem(ROW3, COLUMN1, new QTableWidgetItem(QString::number(_PDU[PDUNum].StatusMSG2.Signal.Measured_Current)) );

        //Measured Voltage
        ui->PDUTable3->setItem(ROW4, COLUMN1, new QTableWidgetItem(QString::number(_PDU[PDUNum].StatusMSG2.Signal.Measured_Voltage)) );

        //Measured Temp
        ui->PDUTable3->setItem(ROW5, COLUMN1, new QTableWidgetItem(QString::number(_PDU[PDUNum].StatusMSG2.Signal.Measured_Temperature)) );

        //Roller Speed
        ui->PDUTable3->setItem(ROW6, COLUMN1, new QTableWidgetItem(QString::number(_PDU[PDUNum].StatusMSG3.Signal.PDU_Roller_Speed)) );

        //LM Speed
        ui->PDUTable3->setItem(ROW7, COLUMN1, new QTableWidgetItem(QString::number(_PDU[PDUNum].StatusMSG3.Signal.PDU_LM_Speed)) );

        //LM HALL Count
        ui->PDUTable3->setItem(ROW8, COLUMN1, new QTableWidgetItem(QString::number(_PDU[PDUNum].StatusMSG3.Signal.PDU_LM_Hall_Count)) );

    }


    timer->setInterval(ONE_SEC);

}
PDUStatPg::~PDUStatPg()
{
    delete ui;
}
