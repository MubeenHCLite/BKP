/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : section2page.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : Provides implementation of Access sections, listing all the LRUs
 *                (CPs and PDUs). Implementation of Navigation to Status page of
 *                the LRUs listed in the section.
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "section2page.h"
#include "ui_section2page.h"
#include <QDebug>

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the Section Page application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
Section2Page::Section2Page(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Section2Page)
{
    ui->setupUi(this);
    qDebug() << "Section 2 Page";
    PduStatP = new PDUStatPg(this);
    MCPStatP = new MCPStatusPage(this);

}

Section2Page::~Section2Page()
{
    delete ui;
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Respective LRU Status screens
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void Section2Page::on_ICP_clicked()
{
    MCPStatP->CPName = "ICP";
    CurrPage = MCP_STATUS;
    PrevPage = ACC_ZONE;
    MCPStatP->show();
}

void Section2Page::on_R50_clicked()
{
    PduStatP->PDUNum = 109;
    PduStatP->PDUName = "PDU R 50";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R49_clicked()
{
    PduStatP->PDUNum = 108;
    PduStatP->PDUName = "PDU R 49";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R48_clicked()
{
    PduStatP->PDUNum = 107;
    PduStatP->PDUName = "PDU R 48";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R47_clicked()
{
    PduStatP->PDUNum = 106;
    PduStatP->PDUName = "PDU R 47";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R46_clicked()
{
    PduStatP->PDUNum = 105;
    PduStatP->PDUName = "PDU R 46";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R45_clicked()
{
    PduStatP->PDUNum = 104;
    PduStatP->PDUName = "PDU R 45";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R44_clicked()
{
    PduStatP->PDUNum = 103;
    PduStatP->PDUName = "PDU R 44";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R43_clicked()
{
    PduStatP->PDUNum = 102;
    PduStatP->PDUName = "PDU R 43";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R42_clicked()
{
    PduStatP->PDUNum = 101;
    PduStatP->PDUName = "PDU R 42";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R41_clicked()
{
    PduStatP->PDUNum = 100;
    PduStatP->PDUName = "PDU R 41";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R40_clicked()
{
    PduStatP->PDUNum = 99;
    PduStatP->PDUName = "PDU R 40";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R39_clicked()
{
    PduStatP->PDUNum = 98;
    PduStatP->PDUName = "PDU R 39";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R38_clicked()
{
    PduStatP->PDUNum = 97;
    PduStatP->PDUName = "PDU R 38";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R37_clicked()
{
    PduStatP->PDUNum = 96;
    PduStatP->PDUName = "PDU R 437";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R36_clicked()
{
    PduStatP->PDUNum = 95;
    PduStatP->PDUName = "PDU R 36";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R35_clicked()
{
    PduStatP->PDUNum = 94;
    PduStatP->PDUName = "PDU R 35";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_R34_clicked()
{
    PduStatP->PDUNum = 93;
    PduStatP->PDUName = "PDU R 34";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_TR01_clicked()
{
    PduStatP->PDUNum = 110;
    PduStatP->PDUName = "PDU T R 01";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_TR02_clicked()
{
    PduStatP->PDUNum = 111;
    PduStatP->PDUName = "PDU T R 02";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_TR03_clicked()
{
    PduStatP->PDUNum = 112;
    PduStatP->PDUName = "PDU T R 03";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_TR04_clicked()
{
    PduStatP->PDUNum = 113;
    PduStatP->PDUName = "PDU T R 04";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_TR05_clicked()
{
    PduStatP->PDUNum = 114;
    PduStatP->PDUName = "PDU T R 05";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_TR06_clicked()
{
    PduStatP->PDUNum = 115;
    PduStatP->PDUName = "PDU T R 06";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}

void Section2Page::on_TR07_clicked()
{
    PduStatP->PDUNum = 116;
    PduStatP->PDUName = "PDU T R 07";

    CurrPage = PDU_STATUS;
    PrevPage = ACC_ZONE;
    PduStatP->show();
}
