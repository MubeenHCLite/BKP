#ifndef SWVERSIONW_H
#define SWVERSIONW_H

#include <QDialog>

namespace Ui {
class SWVersionW;
}

class SWVersionW : public QDialog
{
    Q_OBJECT

public:
    explicit SWVersionW(QWidget *parent = 0);
    ~SWVersionW();

private:
    Ui::SWVersionW *ui;
};

#endif // SWVERSIONW_H
