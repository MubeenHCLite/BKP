/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : swmaintanancew.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : The CDP OPSW SW Maintenance page implementation. This implementation
 *                provides Naviation option to Status pages of all LRUs &
 *                other Maintanance screens.
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "swmaintenancew.h"
#include "ui_swmaintenancew.h"
#include <QDebug>

/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the SW Maintenance window application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
SWMaintenanceW::SWMaintenanceW(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SWMaintenanceW)
{
    ui->setupUi(this);
    qDebug() << "SWMaint Page";
    //set the main page background
    QPixmap Background(BaseFolder + "SWMaintenancePageBkg.png");
    Background = Background.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette Palette;
    Palette.setBrush(QPalette::Window, Background);
    this->setPalette(Palette);
    ContMonitoringScreen = new ContMonSectionOverview(this);
    DetailedStatusScreen = new DetailedSystemStatusW(this);
    ULDStatusScreen  = new ULDStatusPage(this);

    // SW Maintenance button
    ContMonButton = new QPushButton("", this);
    ContMonButton->setGeometry(QRect(QPoint(SWM_CM_BTN_X, SWM_CM_BTN_Y), QSize(SWM_CM_BTN_WT, SWM_CM_BTN_HT)));
    QPixmap ContMonButtonBkg(BaseFolder + "ContMonitoringButton.png");
    QIcon ContMonButtonIcon(ContMonButtonBkg.scaled(SWM_CM_BTN_WT, SWM_CM_BTN_HT, Qt::KeepAspectRatio));
    ContMonButton->setIcon(ContMonButtonIcon);
    ContMonButton->setIconSize(QSize(SWM_CM_BTN_WT, SWM_CM_BTN_HT));
    connect(ContMonButton, &QPushButton::released, this, &SWMaintenanceW::HandleContMonButton);

    DetailedStatButton = new QPushButton("", this);
    DetailedStatButton->setGeometry(QRect(QPoint(SWM_DS_BTN_X, SWM_DS_BTN_Y), QSize(SWM_DS_BTN_WT, SWM_DS_BTN_HT)));
    QPixmap DetailedStatButtonBkg(BaseFolder + "SysStatusButton.png");
    QIcon DetailedStatButtonIcon(DetailedStatButtonBkg.scaled(330, 330, Qt::KeepAspectRatio));
    DetailedStatButton->setIcon(DetailedStatButtonIcon);
    DetailedStatButton->setIconSize(QSize(SWM_DS_BTN_WT, SWM_DS_BTN_HT));
    connect(DetailedStatButton, &QPushButton::released, this, &SWMaintenanceW::HandleDetailedStatButton);

    ULDStatusButton = new QPushButton("", this);
    ULDStatusButton->setGeometry(QRect(QPoint(ULD_ST_BTN_X, ULD_ST_BTN_Y), QSize(ULD_ST_BTN_WT, ULD_ST_BTN_HT)));
    QPixmap ULDStatusButtonBkg(BaseFolder + "ULDStatusButton.png");
    QIcon ULDStatusButtonIcon(ULDStatusButtonBkg.scaled(330, 330, Qt::KeepAspectRatio));
    ULDStatusButton->setIcon(ULDStatusButtonIcon);
    ULDStatusButton->setIconSize(QSize(ULD_ST_BTN_WT,ULD_ST_BTN_WT));
    connect(ULDStatusButton, &QPushButton::released, this, &SWMaintenanceW::HandleULDStatusButton);

    BackButton = new QPushButton("", this);
    BackButton->setGeometry(QRect(QPoint(SWM_BK_BTN_X, SWM_BK_BTN_Y), QSize(SWM_BK_BTN_WT, SWM_BK_BTN_HT)));
    QPixmap BackButtonBkg(BaseFolder + "BackButton.png");
    QIcon BackButtonIcon(BackButtonBkg.scaled(SWM_BK_BTN_WT, SWM_BK_BTN_HT, Qt::KeepAspectRatio));
    BackButton->setIcon(BackButtonIcon);
    BackButton->setIconSize(QSize(SWM_BK_BTN_WT, SWM_BK_BTN_HT));
    connect(BackButton, &QPushButton::released, this, &SWMaintenanceW::HandleBackButton);

    qDebug() << "SW MAint End";

}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Cont Monitoring screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void SWMaintenanceW::HandleContMonButton(){
    CurrPage = CON_MON;
    PrevPage = MAINT;
    ContMonitoringScreen->show();
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to System Status screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void SWMaintenanceW::HandleDetailedStatButton(){
    CurrPage = DSS;
    PrevPage = MAINT;
    DetailedStatusScreen->show();
}

/*-----------------------------------------------------------------------------
 *  Description : Navigation implementation to Main screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void SWMaintenanceW::HandleBackButton(){
    PrevPage = MAINT;
    CurrPage = SWMAIN;
    hide();
}

void SWMaintenanceW::HandleULDStatusButton(){
    CurrPage = DSS;
    PrevPage = MAINT;
    ULDStatusScreen->show();
}

SWMaintenanceW::~SWMaintenanceW()
{
    delete ui;
}
