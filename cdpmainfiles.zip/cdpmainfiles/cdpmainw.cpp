/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : cdpmainw.cpp
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Description : The CDP OPSW main display page implementation. This implementation
 *                provides Display indications for all LRUs (Control Panels, PDUs,
 *                Access Zones ).It also provides navigation options to Maintenance window.
 *
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen
 *
 *-----------------------------------------------------------------------------
 */

/****************************** HEADER FILES *********************************/
#include "cdpmainw.h"
#include "ui_cdpmainw.h"
#include "parser.h"
#include <QString>
#include <QDebug>
#include <QTimer>
#include <QPixmap>
#include <QLabel>
#include <linux/can.h>
#include <linux/can/raw.h>

/********************************* GLOBAL DATA ELEMENTS ***********************/

extern QQueue<CAN_DATA>     canBuffer;

Cargo_Zone cargoZone;
MCP _MCP;
ICP _ICP;
OCP _OCP;
LCP _LCP[8];
LCP20FT _LCP20FT[2];
PowerDriveUnit _PDU[PDU_MAX_COUNT];

int PDUXCord[116] = {//1700,1668,1636,1604,1572,1540,1508,1476,
                       1133, 1112,1091,1069,1048,1027,1005,984,

                     //1444,1412,1380,1348,1316,1284,1252,1220,
                     963,941, 920, 899, 877, 856, 835,813,

                     //1188,1156,1124,1092,1060,1028,996,964,932,
                     792, 771, 749, 728, 707, 685, 664, 643, 621,

                     //900,868,836,804,772,740,708,676,644,612,
                     600, 579, 557, 536, 515, 493, 472, 451, 429, 408,

                     //580,548,516,484,452,420,388,356,324,292,260,
                     387, 365, 344, 323, 301, 280, 259, 237, 216, 195,173,

                     //228,196,164,132,650,600,550,500,450,400,500,430,400,
                      152, 131, 109, 88, 433, 400, 367, 333,  300, 283, 267,

                    // 1700,1668,1636,1604,1572,1540,1508,1476,
                     1133, 1112,1091,1069,1048,1027,1005,984,

                     // 1444,1412,1380,1348,1316,1284,1252,1220,
                      963,941, 920, 899, 877, 856, 835,813,

                      //1188,1156,1124,1092,1060,1028,996,964,932,
                      792, 771, 749, 728, 707, 685, 664, 643, 621,

                      //900,868,836,804,772,740,708,676,644,612,
                     600, 579, 557, 536, 515, 493, 472, 451, 429, 408,

                      //580,548,516,484,452,420,388,356,324,292,260,
                      387, 365, 344, 323, 301, 280, 259, 237, 216, 195,173,

                      //228,196,164,132,650,600,550,500,450,425,400};
                       152, 131, 109, 88, 433, 400, 367, 333,  300, 283, 267};

int PDUYCord[116] = {//190,190,190,190,190,190,190,190,190,190,190,
                      180,180, 180, 180, 180, 180, 180, 180, 180, 180,180,
                     //190,190,190,190,190,190,190,190,190,190,190,190,
                     180, 180, 180, 180, 180, 180, 180, 180, 180, 180, 180, 180,
                    // 190,190,190,190,190,190,190,190,190,190,190,190,
                     180,180,180,180,180,180,180,180,180,180,180,180,

                     //190,190,190,190,190,190,190,190,190,190,190,190,190,
                     180, 180,180,180,180,180,180,180,180,180,180,180,180,

                     //190,190,230,230,230,230,230,230,150,150,150,330,330,
                       180,180,218,218,218,218,218,218,142,142,142,313,313,
                     //330,330,330,330,330,330,330,330,330,
                      313, 313,313,313,313,313,313,313,313,

                     //330,330,330,330,330,330,330,330,330,330,330,330,330,
                       313,313,313,313,313,313,313,313,313,313,313,313,313,

                     //330,330,330,330,330,330,330,330,330,330,330,330,330,
                      313,313,313,313,313,313,313,313,313,313,313,313,313,

                     //330,330,330,330,330,330,330,330,330,330,330,330,330,
                      313,313,313,313,313,313,313,313,313,313,313,313,313,
                     //280,280,280,280,280,280,280};
                     265,265,265,265,265,265,265};

static QLabel*             PDUIndication[PDU_MAX_COUNT];
static QLabel*             MCPIndicator;
static QLabel*             ICPIndicator;
static QLabel*             OCPIndicator;
static QLabel*             LCPIndicator[8];

static int MCPHt = 95;  //100;
static int MCPWt = 47;     //70;
static int ICPHt = 95;     //100;
static int ICPWt = 47;       //70;
static int OCPHt = 66;       //70;
static int OCPWt = 47;    //70;
static int LCPHt = 38;   //40;
static int LCPWt = 50;   //75;
static int PDUHt = 28;   //30;
static int PDUWt = 10;   //15;

//static int MCPHt = 100;
//static int MCPWt = 70;
//static int ICPHt = 100;
//static int ICPWt = 70;
//static int OCPHt = 70;
//static int OCPWt = 70;
//static int LCPHt = 40;
//static int LCPWt = 75;
//static int PDUHt = 30;
//static int PDUWt = 15;

Current_Page CurrPage;
Current_Page PrevPage;

QString LCPAmberP[8];
QString LCPGreenP[8];
QString LCPGreyP[8];
QString LCPRdAmP[8];
QString LCPRdGnP[8];

QString BaseFolder= "/home/ancra/PICS/";
QString PDUAmberAFP  = BaseFolder +  "AMAF.png";
QString PDUAmberFWP  = BaseFolder +  "AMFW.png";
QString PDUAmberINP  = BaseFolder +  "AMIN.png";
QString PDUAmberOUP  = BaseFolder +  "AMOU.png";
QString PDUGreenAFP  = BaseFolder +  "GNAF.png";
QString PDUGreenFWP  = BaseFolder +  "GNFW.png";
QString PDUGreenINP  = BaseFolder +  "GNIN.png";
QString PDUGreenOUP  = BaseFolder +  "GNOU.png";
QString ICPAmberP  = BaseFolder +  "ICPAM.png";
QString ICPGreenP  = BaseFolder +  "ICPGN.png";
QString ICPGreyP  = BaseFolder +  "ICPGR.png";
QString ICPRdAmP  = BaseFolder +  "ICPRA.png";
QString ICPRdGnP  = BaseFolder +  "ICPRG.png";
QString MCPAmberP  = BaseFolder +  "MCPAM.png";
QString MCPGreenP  = BaseFolder +  "MCPGN.png";
QString MCPGreyP  = BaseFolder +  "MCPGR.png";
QString MCPRdAmP  = BaseFolder +  "MCPRA.png";
QString MCPRdGnP  = BaseFolder +  "MCPRG.png";
QString OCPAmberP  = BaseFolder +  "OCPAM.png";
QString OCPGreenP  = BaseFolder +  "OCPGN.png";
QString OCPGreyP  = BaseFolder +  "OCPGR.png";
QString OCPRdAmP  = BaseFolder +  "OCPRA.png";
QString OCPRdGnP  = BaseFolder +  "OCPRG.png";
QString PDUAmberP  = BaseFolder +  "PDUAM.png";
QString PDUGreenP  = BaseFolder +  "PDUGN.png";
QString PDUGreyP  = BaseFolder +  "PDUGR.png";
QString PDURedP  = BaseFolder +  "PDURD.png";
QString PDUWhAmbP  = BaseFolder +  "PDUWA.png";
QString PDUWhiteP  = BaseFolder +  "PDUWH.png";
QString PDUWhRedP  = BaseFolder +  "PDUWR.png";

QString SWMButtonP = BaseFolder +  "SWMButton.png";
QString LegendsShowP = BaseFolder +  "LegendsButton.png";


/*-----------------------------------------------------------------------------
 *  Description : This is the constructor for the Main window of application
 *
 *  Arguments   : Parent Class
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
*/
CDPMAINW::CDPMAINW(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::CDPMAINW)
{
    ui->setupUi(this);
    CurrPage = SWMAIN;
    PrevPage = SWMAIN;
    SWMaintenanceScreen = new SWMaintenanceW(this);
    LegendsPage = new LegendsMenuPage(this);

    //set the main page background
    QPixmap Background(BaseFolder + "MainPageBkg.png");
    Background = Background.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette Palette;
    Palette.setBrush(QPalette::Window, Background);
    this->setPalette(Palette);

    LCPAmberP[LCP1LH] = BaseFolder + "1LHAM.png";
    LCPAmberP[LCP2LH] = BaseFolder + "2LHAM.png";
    LCPAmberP[LCP3LH] = BaseFolder + "3LHAM.png";
    LCPAmberP[LCP4LH] = BaseFolder + "4LHAM.png";
    LCPGreenP[LCP1LH] = BaseFolder + "1LHGN.png";
    LCPGreenP[LCP2LH] = BaseFolder + "2LHGN.png";
    LCPGreenP[LCP3LH] = BaseFolder + "3LHGN.png";
    LCPGreenP[LCP4LH] = BaseFolder + "4LHGN.png";
    LCPGreyP[LCP1LH] = BaseFolder + "1LHGY.png";
    LCPGreyP[LCP2LH] = BaseFolder + "2LHGY.png";
    LCPGreyP[LCP3LH] = BaseFolder + "3LHGY.png";
    LCPGreyP[LCP4LH] = BaseFolder + "4LHGY.png";
    LCPRdAmP[LCP1LH] = BaseFolder + "1LHRA.png";
    LCPRdAmP[LCP2LH] = BaseFolder + "2LHRA.png";
    LCPRdAmP[LCP3LH] = BaseFolder + "3LHRA.png";
    LCPRdAmP[LCP4LH] = BaseFolder + "4LHRA.png";
    LCPRdGnP[LCP1LH] = BaseFolder + "1LHRG.png";
    LCPRdGnP[LCP2LH] = BaseFolder + "2LHRG.png";
    LCPRdGnP[LCP3LH] = BaseFolder + "3LHRG.png";
    LCPRdGnP[LCP4LH] = BaseFolder + "4LHRG.png";

    LCPAmberP[LCP1RH] = BaseFolder + "1RHAM.png";
    LCPAmberP[LCP2RH] = BaseFolder + "2RHAM.png";
    LCPAmberP[LCP3RH] = BaseFolder + "3RHAM.png";
    LCPAmberP[LCP4RH] = BaseFolder + "4RHAM.png";
    LCPGreenP[LCP1RH] = BaseFolder + "1RHGN.png";
    LCPGreenP[LCP2RH] = BaseFolder + "2RHGN.png";
    LCPGreenP[LCP3RH] = BaseFolder + "3RHGN.png";
    LCPGreenP[LCP4RH] = BaseFolder + "4RHGN.png";
    LCPGreyP[LCP1RH] = BaseFolder + "1RHGY.png";
    LCPGreyP[LCP2RH] = BaseFolder + "2RHGY.png";
    LCPGreyP[LCP3RH] = BaseFolder + "3RHGY.png";
    LCPGreyP[LCP4RH] = BaseFolder + "4RHGY.png";
    LCPRdAmP[LCP1RH] = BaseFolder + "1RHRA.png";
    LCPRdAmP[LCP2RH] = BaseFolder + "2RHRA.png";
    LCPRdAmP[LCP3RH] = BaseFolder + "3RHRA.png";
    LCPRdAmP[LCP4RH] = BaseFolder + "4RHRA.png";
    LCPRdGnP[LCP1RH] = BaseFolder + "1RHRG.png";
    LCPRdGnP[LCP2RH] = BaseFolder + "2RHRG.png";
    LCPRdGnP[LCP3RH] = BaseFolder + "3RHRG.png";
    LCPRdGnP[LCP4RH] = BaseFolder + "4RHRG.png";

    // SW Maintenance button
    SWMButton = new QPushButton("", this);
    SWMButton->setGeometry(QRect(QPoint(SWN_BTN_X, SWM_BTN_Y), QSize(SWM_BTN_WT, SWM_BTN_HT)));
    QPixmap SWMButtonBkg(SWMButtonP);
    QIcon SWMButtonIcon(SWMButtonBkg);
    SWMButton->setIcon(SWMButtonIcon);
    SWMButton->setIconSize(SWMButton->rect().size());
    connect(SWMButton, &QPushButton::released, this, &CDPMAINW::HandleSWMButton);

/*    LegendsShow = new QPushButton("", this);
    LegendsShow->setGeometry(QRect(QPoint(LEGENDS_BTN_X, LEGENDS_BTN_Y), QSize(LEGENDS_BTN_WT, LEGENDS_BTN_HT)));
    QPixmap LegendsShowBkg(LegendsShowP);
    QIcon LegendsShowIcon(LegendsShowBkg);
    LegendsShow->setIcon(LegendsShowIcon);
    LegendsShow->setIconSize(LegendsShow->rect().size());
    connect(LegendsShow, &QPushButton::released, this, &CDPMAINW::HandleLegendsShow);*/

    int Pos;
    for(Pos = 0; Pos < PDU_MAX_COUNT  ; Pos++){
            PDUIndication[Pos] = new QLabel(this);
            PDUIndication[Pos]->setFrameStyle(QFrame::Panel);

            PDUIndication[Pos]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
            PDUIndication[Pos]->setGeometry(QRect(PDUXCord[Pos],PDUYCord[Pos],PDUWt,PDUHt));
            PDUIndication[Pos]->setPixmap(PDU_GREY_PIX);
    }

    //MCP
    MCPIndicator = new QLabel(this);
    MCPIndicator->setFrameStyle(QFrame::NoFrame);
    MCPIndicator->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    MCPIndicator->setGeometry(QRect(MCP_IND_X,MCP_IND_Y,MCPWt,MCPHt));
    MCPIndicator->setPixmap(MCP_GREY_PIX);
    MCPIndicator->setScaledContents(true);

    //ICP
    ICPIndicator = new QLabel(this);
    ICPIndicator->setFrameStyle(QFrame::NoFrame);
    ICPIndicator->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    ICPIndicator->setGeometry(QRect(ICP_IND_X,ICP_IND_Y,ICPWt,ICPHt));
    ICPIndicator->setPixmap(ICP_GREY_PIX);
    ICPIndicator->setScaledContents(true);

    //OCP
    OCPIndicator = new QLabel(this);
    OCPIndicator->setFrameStyle(QFrame::NoFrame);
    OCPIndicator->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    //OCPIndicator->setStyleSheet("border-radius: 50px");
    OCPIndicator->setGeometry(QRect(OCP_IND_X,OCP_IND_Y,OCPWt,OCPHt));
    OCPIndicator->setPixmap(OCP_GREY_PIX);
    OCPIndicator->setScaledContents(true);

    //LCPs
    LCPIndicator[LCP4LH] = new QLabel(this);
    LCPIndicator[LCP4LH]->setFrameStyle(QFrame::NoFrame);
    LCPIndicator[LCP4LH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP4LH]->setGeometry(QRect(LCP4LH_IND_X,LCP4LH_IND_Y,LCPWt,LCPHt));
    LCPIndicator[LCP4LH]->setPixmap(LCP_GREY_PIX(LCP4LH));
    LCPIndicator[LCP4LH]->setScaledContents(true);

    LCPIndicator[LCP3LH] = new QLabel(this);
    LCPIndicator[LCP3LH]->setFrameStyle(QFrame::NoFrame);
    LCPIndicator[LCP3LH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP3LH]->setGeometry(QRect(LCP3LH_IND_X,LCP3LH_IND_Y,LCPWt,LCPHt));
    LCPIndicator[LCP3LH]->setPixmap(LCP_GREY_PIX(LCP3LH));
    LCPIndicator[LCP3LH]->setScaledContents(true);


    LCPIndicator[LCP2LH] = new QLabel(this);
    LCPIndicator[LCP2LH]->setFrameStyle(QFrame::NoFrame);
    LCPIndicator[LCP2LH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP2LH]->setGeometry(QRect(LCP2LH_IND_X,LCP2LH_IND_Y,LCPWt,LCPHt));
    LCPIndicator[LCP2LH]->setPixmap(LCP_GREY_PIX(LCP2LH));
    LCPIndicator[LCP3LH]->setScaledContents(true);


    LCPIndicator[LCP1LH] = new QLabel(this);
    LCPIndicator[LCP1LH]->setFrameStyle(QFrame::NoFrame);
    LCPIndicator[LCP1LH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP1LH]->setGeometry(QRect(LCP1LH_IND_X,LCP1LH_IND_Y,LCPWt,LCPHt));
    LCPIndicator[LCP1LH]->setPixmap(LCP_GREY_PIX(LCP1LH));
    LCPIndicator[LCP3LH]->setScaledContents(true);


    LCPIndicator[LCP4RH] = new QLabel(this);
    LCPIndicator[LCP4RH]->setFrameStyle(QFrame::NoFrame);
    LCPIndicator[LCP4RH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP4RH]->setGeometry(QRect(LCP4RH_IND_X,LCP4RH_IND_Y,LCPWt,LCPHt));
    LCPIndicator[LCP4RH]->setPixmap(LCP_GREY_PIX(LCP4RH));
    LCPIndicator[LCP4RH]->setScaledContents(true);

    LCPIndicator[LCP3RH] = new QLabel(this);
    LCPIndicator[LCP3RH]->setFrameStyle(QFrame::NoFrame);
    LCPIndicator[LCP3RH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP3RH]->setGeometry(QRect(LCP3RH_IND_X,LCP3RH_IND_Y,LCPWt,LCPHt));
    LCPIndicator[LCP3RH]->setPixmap(LCP_GREY_PIX(LCP3RH));
    LCPIndicator[LCP3RH]->setScaledContents(true);

    LCPIndicator[LCP2RH] = new QLabel(this);
    LCPIndicator[LCP2RH]->setFrameStyle(QFrame::NoFrame);
    LCPIndicator[LCP2RH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP2RH]->setGeometry(QRect(LCP2RH_IND_X,LCP2RH_IND_Y,LCPWt,LCPHt));
    LCPIndicator[LCP2RH]->setPixmap(LCP_GREY_PIX(LCP2RH));
    LCPIndicator[LCP2RH]->setScaledContents(true);

    LCPIndicator[LCP1RH] = new QLabel(this);
    LCPIndicator[LCP1RH]->setFrameStyle(QFrame::NoFrame);
    LCPIndicator[LCP1RH]->setAlignment(Qt::AlignCenter | Qt::AlignCenter);
    LCPIndicator[LCP1RH]->setGeometry(QRect(LCP1RH_IND_X,LCP1RH_IND_Y,LCPWt,LCPHt));
    LCPIndicator[LCP1RH]->setPixmap(LCP_GREY_PIX(LCP1RH));
    LCPIndicator[LCP1RH]->setScaledContents(true);

    timerMainP = new QTimer(this);
    connect(timerMainP, SIGNAL(timeout()), this, SLOT(UpdateUI()));
    timerMainP->setInterval(ONE_MS);
    timerMainP->start();
}

/*-----------------------------------------------------------------------------
 *  Description : This function handles the navigation to SW Maintenance Screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */

void CDPMAINW::HandleSWMButton()
{
    CurrPage = SWMAIN;
    SWMaintenanceScreen->show();
}

/*-----------------------------------------------------------------------------
 *  Description : This function handles the navigation to Legends Menu Screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void CDPMAINW::HandleLegendsShow()
{
    CurrPage = SWMAIN;
    LegendsPage->show();
}

/*-----------------------------------------------------------------------------
 *  Description : This function handles the Periodic update of CDP MAIN screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
void CDPMAINW::UpdateUI()
{
    uint8_t Pos;

    // Update Panel Statu
    if(CurrPage == SWMAIN){
        qDebug() << "updating SWMAIN Page";

     if(_MCP.Status.Signal.PB_On_Off_LED == DISABLED){
            //SET MCP To GREY
            MCPIndicator->setPixmap(MCP_GREY_PIX);

        }
        else if(_MCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _MCP.Status.Signal.LED_System_Active == TRUE &&
                _MCP.Command.Signal.MCP_Panel_Status == CP_STATE::OP){// &&
                //_MCP.Command.Signal.MCP_Switch_Fault_Status == FALSE){
            //Set Green HAT + Green ICON
            MCPIndicator->setPixmap(MCP_GREEN_PIX);
        }

        else if(_MCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _MCP.Status.Signal.LED_System_Active == TRUE &&
                _MCP.Command.Signal.MCP_Panel_Status == CP_STATE::FAIL){// &&
                //_MCP.Command.Signal.MCP_Switch_Fault_Status == TRUE){
            //Set AMber HAT + Amber ICON
            MCPIndicator->setPixmap(MCP_AMBER_PIX);
        }

        else if(_MCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _MCP.Status.Signal.LED_System_Active == TRUE &&
                _MCP.Command.Signal.MCP_Panel_Status == CP_STATE::OP &&
                //_MCP.Command.Signal.MCP_Switch_Fault_Status == FALSE &&
                _MCP.Command.Signal.MCP_PB_PDU_Stop == TRUE){
            //Set Red HAT + Green ICON
            MCPIndicator->setPixmap(MCP_RDGN_PIX);
        }

        else if(_MCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _MCP.Status.Signal.LED_System_Active == TRUE &&
                _MCP.Command.Signal.MCP_Panel_Status == CP_STATE::FAIL &&
                //_MCP.Command.Signal.MCP_Switch_Fault_Status == TRUE &&
                _MCP.Command.Signal.MCP_PB_PDU_Stop == TRUE){
            //Set Red HAT + AMBER ICON
            MCPIndicator->setPixmap(MCP_RDAM_PIX);
        }

        if(_ICP.Status.Signal.PB_On_Off_LED == DISABLED){
            //SET ICP To GREY
            ICPIndicator->setPixmap(ICP_GREY_PIX);
        }
        else if(_ICP.Status.Signal.PB_On_Off_LED == TRUE &&
                _ICP.Status.Signal.LED_System_Active == TRUE &&
                _ICP.Command.Signal.ICP_Panel_Status == CP_STATE::OP &&
                _ICP.Command.Signal.ICP_Switch_Fault_Status == FALSE){
            //Set Green HAT + Green ICON
            ICPIndicator->setPixmap(ICP_GREEN_PIX);
        }

        else if(_ICP.Status.Signal.PB_On_Off_LED == TRUE &&
                _ICP.Status.Signal.LED_System_Active == TRUE &&
                _ICP.Command.Signal.ICP_Panel_Status == CP_STATE::FAIL &&
                _ICP.Command.Signal.ICP_Switch_Fault_Status == TRUE){
            //Set AMber HAT + Amber ICON
            ICPIndicator->setPixmap(ICP_AMBER_PIX);
        }

        else if(_ICP.Status.Signal.PB_On_Off_LED == TRUE &&
                _ICP.Status.Signal.LED_System_Active == TRUE &&
                _ICP.Command.Signal.ICP_Panel_Status == CP_STATE::OP &&
                _ICP.Command.Signal.ICP_Switch_Fault_Status == FALSE &&
                _ICP.Command.Signal.ICP_PB_PDU_Stop == TRUE){
            //Set Red HAT + Green ICON
            ICPIndicator->setPixmap(ICP_RDGN_PIX);
        }

        else if(_ICP.Status.Signal.PB_On_Off_LED == TRUE &&
                _ICP.Status.Signal.LED_System_Active == TRUE &&
                _ICP.Command.Signal.ICP_Panel_Status == CP_STATE::FAIL &&
                _ICP.Command.Signal.ICP_Switch_Fault_Status == TRUE &&
                _ICP.Command.Signal.ICP_PB_PDU_Stop == TRUE){
            //Set Red HAT + AMBER ICON
            ICPIndicator->setPixmap(ICP_RDAM_PIX);
        }

        if(_OCP.Status.Signal.PB_On_Off_LED == DISABLED){
            //SET OCP To GREY
            OCPIndicator->setPixmap(OCP_GREY_PIX);
        }
        else if(_OCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _OCP.Status.Signal.LED_System_Active == TRUE &&
                _OCP.Command.Signal.OCP_Panel_Status == CP_STATE::OP){// &&
                //_OCP.Command.Signal.OCP_Switch_Fault_Status == FALSE){
            //Set Green HAT + Green ICON
            OCPIndicator->setPixmap(OCP_GREEN_PIX);
        }

        else if(_OCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _OCP.Status.Signal.LED_System_Active == TRUE &&
                _OCP.Command.Signal.OCP_Panel_Status == CP_STATE::FAIL){// &&
            //_OCP.Command.Signal.OCP_Switch_Fault_Status == FALSE){
            //Set AMber HAT + Amber ICON
            OCPIndicator->setPixmap(OCP_AMBER_PIX);
        }

        else if(_OCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _OCP.Status.Signal.LED_System_Active == TRUE &&
                _OCP.Command.Signal.OCP_Panel_Status == CP_STATE::OP &&
                //_OCP.Command.Signal.OCP_Switch_Fault_Status == FALSE &&
                _OCP.Command.Signal.OCP_PB_PDU_Stop == TRUE){
            //Set Red HAT + Green ICON
            OCPIndicator->setPixmap(OCP_RDGN_PIX);
        }

        else if(_OCP.Status.Signal.PB_On_Off_LED == TRUE &&
                _OCP.Status.Signal.LED_System_Active == TRUE &&
                _OCP.Command.Signal.OCP_Panel_Status == CP_STATE::FAIL &&
                //_OCP.Command.Signal.OCP_Switch_Fault_Status == TRUE &&
                _OCP.Command.Signal.OCP_PB_PDU_Stop == TRUE){
            //Set Red HAT + AMBER ICON
            OCPIndicator->setPixmap(OCP_RDAM_PIX);
        }

        for( Pos=LCP1LH ; Pos < 8 ; Pos++){
            if(_LCP[Pos].Status.Signal.LCP_LED_Panel_Enabled == FALSE &&
                    (_LCP[Pos].Command.Signal.LCP_Panel_Status != CP_STATE::OP ||
                     _LCP[Pos].Command.Signal.LCP_Panel_Status != CP_STATE::FAIL)){
                //SET LCP To GREY
                LCPIndicator[Pos]->setPixmap(LCP_GREY_PIX(Pos));
            }
            else if(_LCP[Pos].Status.Signal.LCP_LED_Panel_Enabled == TRUE &&
                    (_LCP[Pos].Command.Signal.LCP_Switch_Fault_Status == FALSE &&
                     _LCP[Pos].Command.Signal.LCP_Panel_Status == CP_STATE::OP)){
                //Set Green HAT + Green ICON
                LCPIndicator[Pos]->setPixmap(LCP_GREEN_PIX(Pos));
            }
            else if(_LCP[Pos].Status.Signal.LCP_LED_Panel_Enabled == TRUE &&
                    (_LCP[Pos].Command.Signal.LCP_Switch_Fault_Status == TRUE &&
                     _LCP[Pos].Command.Signal.LCP_Panel_Status == CP_STATE::FAIL)){
                //Set Amber HAT + Amber ICON
                LCPIndicator[Pos]->setPixmap(LCP_AMBER_PIX(Pos));
            }

            else if(_LCP[Pos].Status.Signal.LCP_LED_Panel_Enabled == TRUE &&
                    (_LCP[Pos].Command.Signal.LCP_Switch_Fault_Status == FALSE &&
                     _LCP[Pos].Command.Signal.LCP_Panel_Status == CP_STATE::OP) &&
                    _LCP[Pos].Command.Signal.LCP_PB_PDU_Stop == TRUE){
                //Set Red HAT + Green ICON
                LCPIndicator[Pos]->setPixmap(LCP_RDGN_PIX(Pos));
            }

            else if(_LCP[Pos].Status.Signal.LCP_LED_Panel_Enabled == TRUE &&
                    (_LCP[Pos].Command.Signal.LCP_Switch_Fault_Status == TRUE ||
                     _LCP[Pos].Command.Signal.LCP_Panel_Status == CP_STATE::FAIL) &&
                    _LCP[Pos].Command.Signal.LCP_PB_PDU_Stop == TRUE){
                //Set Red HAT + Amber ICON
                LCPIndicator[Pos]->setPixmap(LCP_RDAM_PIX(Pos));
            }
        }

        //Update the PDU Status
        bool Blink = FALSE;
        for(Pos = 0; Pos < PDU_MAX_COUNT ; Pos++){
            //Set Blink State
            if(Blink){
                Blink = FALSE;
            }
            else {
                Blink = TRUE;
            }

            if(_PDU[Pos].StatusMSG1.Signal.PDU_Mode == PDU_MODE::OFF_MODE){
                // Grey Rectangle
                PDUIndication[Pos]->setPixmap(PDU_GREY_PIX);

            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::HOLD_ACTIVE){
                // white rectangle
                PDUIndication[Pos]->setPixmap(PDU_WHITE_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE){
                // Green rectangle
                PDUIndication[Pos]->setPixmap(PDU_GREEN_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE &&
                    _PDU[Pos].StatusMSG1.Signal.Active_Drive_Command_Direction == PDU_DRIVE_COMMAND_DIR::DIR_A){
                // Green Right Triangle Blink
                if(Blink)
                    PDUIndication[Pos]->setPixmap(PDU_GRNFW_PIX);
                else
                    PDUIndication[Pos]->setPixmap(PDU_GREY_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE &&
                    _PDU[Pos].StatusMSG1.Signal.Active_Drive_Command_Direction == PDU_DRIVE_COMMAND_DIR::DIR_B){
                // GReenLEFT Triangle Blink
                if(Blink)
                    PDUIndication[Pos]->setPixmap(PDU_GRNAF_PIX);
                else
                    PDUIndication[Pos]->setPixmap(PDU_GREY_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::NOT_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::HOLD_ACTIVE){
                // WHite and amber rectangle
                    PDUIndication[Pos]->setPixmap(PDU_WHAMB_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE){
                // amber rectangle
                PDUIndication[Pos]->setPixmap(PDU_AMBER_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE &&
                    _PDU[Pos].StatusMSG1.Signal.Active_Drive_Command_Direction == PDU_DRIVE_COMMAND_DIR::DIR_A){
                // Amber Right Triangle Blink
                if(Blink)
                    PDUIndication[Pos]->setPixmap(PDU_AMBFW_PIX);
                else
                    PDUIndication[Pos]->setPixmap(PDU_GREY_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_Health_Status == PDU_HEALTH_STATUS::OVERALL_HEALTHY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE &&
                    _PDU[Pos].StatusMSG1.Signal.Active_Drive_Command_Direction == PDU_DRIVE_COMMAND_DIR::DIR_B){
                // Amber LEFT Triangle Blink
                if(Blink)
                    PDUIndication[Pos]->setPixmap(PDU_AMBAF_PIX);
                else
                    PDUIndication[Pos]->setPixmap(PDU_GREY_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_State == PDU_STATE::ST_FAULTY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::HOLD_ACTIVE){
                // WHite and Red rectangle
                PDUIndication[Pos]->setPixmap(PDU_WHRED_PIX);
            }
            else if(_PDU[Pos].StatusMSG1.Signal.PDU_State == PDU_STATE::ST_FAULTY &&
                    _PDU[Pos].StatusMSG1.Signal.Hold_Status == PDU_HOLD_STATUS::RELEASE_ACTIVE){
                // Red rectangle
                PDUIndication[Pos]->setPixmap(PDU_RED_PIX);
            }
        }
    }
    timerMainP->setInterval(ONE_SEC);
}

/*-----------------------------------------------------------------------------
 *  Description : This is the Destructor function of CDP MAIN Screen
 *
 *  Arguments   : void
 *
 *  Return Value: void
 *
 *-----------------------------------------------------------------------------
 */
CDPMAINW::~CDPMAINW()
{
    delete ui;
}
