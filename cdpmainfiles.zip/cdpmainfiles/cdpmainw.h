
/*----------------------------------------------------------------------------
*                            ANCRA PROPRIETARY
*
* The information contained herein is proprietary to the Ancra International LLC
*
* and shall not be reproduced or disclosed in whole or in part or used for
*
* any design or manufacture except when such user possesses direct written
*
* authorization from the Ancra International LLC.
*
* (c) Copyright 2023 by the Ancra International LLC. All rights reserved.
*---------------------------------------------------------------------------
*/
/*
 *-----------------------------------------------------------------------------
 *
 *  File Name       : cdpmainw.h
 *
 *  CSCI Name       : Cargo Display Panel
 *
 *  CSU Name        : Application
 *
 *  Report Number   : TBD
 *
 *-----------------------------------------------------------------------------
 *
 *  Revision History:
 *
 *  Version  Author        Date             Description
 *           Mubeen                       Header delcarations
 *
 *
 *-----------------------------------------------------------------------------
 */

#ifndef CDPMAINW_H
#define CDPMAINW_H

#include <QMainWindow>
#include <QPushButton>
#include <QLineEdit>
#include "swmaintenancew.h"
#include "common.h"
#include "iconmap.h"
#include "legendsmenupage.h"

/********************* PREPROCESSOR DIRECTIVES  *****************************/
#define SWM_BTN_WT         60 //90
#define SWM_BTN_HT         57 //60

#define SWN_BTN_X           1142 //1713
#define SWM_BTN_Y           866 //913

#define LEGENDS_BTN_WT     60 //90
#define LEGENDS_BTN_HT     57   //60

#define LEGENDS_BTN_X       47 //70
#define LEGENDS_BTN_Y       872 //920

#define MCP_IND_X            187 //280
#define MCP_IND_Y            66  //70

#define ICP_IND_X           187 //280
#define ICP_IND_Y           370 //390

#define OCP_IND_X           280 //420
#define OCP_IND_Y           66 //70

#define LCP4LH_IND_X        453 //680
#define LCP4LH_IND_Y        57 //60

#define LCP3LH_IND_X        587  //880
#define LCP3LH_IND_Y        57       //60

#define LCP2LH_IND_X        727 //1090
#define LCP2LH_IND_Y        76 //80

#define LCP1LH_IND_X        913  // 1370
#define LCP1LH_IND_Y        76  // 80

#define LCP4RH_IND_X         453 //680
#define LCP4RH_IND_Y         455 //480

#define LCP3RH_IND_X         587 // 880
#define LCP3RH_IND_Y        455 //480

#define LCP2RH_IND_X        727 //1090
#define LCP2RH_IND_Y        417 //440

#define LCP1RH_IND_X        913 //1370
#define LCP1RH_IND_Y        417 //440



namespace Ui {
class CDPMAINW;
}

class CDPMAINW : public QMainWindow
{
    Q_OBJECT

public:
    explicit CDPMAINW(QWidget *parent = 0);
    ~CDPMAINW();

private slots:
    void UpdateUI();
    void HandleSWMButton();
    void HandleLegendsShow();


private:
    Ui::CDPMAINW *ui;
    QPushButton *SWMButton;
    QPushButton *LegendsShow;
    QTimer *timerMainP;
    SWMaintenanceW *SWMaintenanceScreen;
    LegendsMenuPage *LegendsPage;
    QLineEdit *line;
};

#endif // CDPMAINW_H
